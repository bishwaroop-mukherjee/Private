﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ETLServiceLibrary
{
    public class ETLPublishServiceAttribute:System.Attribute 
    {
        public string PubType { get; private set; }
    
        public ETLPublishServiceAttribute(string pubtype)
        {
            PubType = pubtype;
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ETLServiceLibrary
{
    public class ETLPublishDataAttribute:System.Attribute 
    {
        public string PubType {get; private set; }
        public ETLPublishDataAttribute(string pubtype)
        {
            PubType = pubtype;
        }

    }
}

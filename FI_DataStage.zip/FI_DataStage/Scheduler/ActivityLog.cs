﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using log4net;
using System.Configuration;
using Scheduler.EntityModel;
using System.Net.Mail;

namespace Scheduler
{
    public class ActivityLog
    {
        // declarations
        string SessID;
        Data_Load_Item dataLoadItem;

        // properties
        public enum LogState
        {
            Success=128,
            Failure=192
        };
        public enum LogType
        {
            Extraction=0,
            Load=1,
            General=2
        };

        /// <summary>
        /// .ctor
        /// </summary>
        /// <param name="dli"></param>
        public ActivityLog(Data_Load_Item dli)
        {
            dataLoadItem = dli;
            SessID = genrateSessionID(dli);
        }

        /// <summary>
        /// sends log to log database.
        /// </summary>
        /// <param name="Message">log message</param>
        /// <param name="lgs">log state</param>
        /// <param name="lgt">log type</param>
        public  void SendToLog(string Message,LogState lgs, LogType lgt)
        {
            using (Scheduler.EntityModel.SchedulerDataEntity fid = new Scheduler.EntityModel.SchedulerDataEntity())
            {
                DataStageLog dsl = DataStageLog.CreateDataStageLog(0, 0);
                var Query = (from d in fid.DataStageLogs.AsEnumerable()
                             select d.LogID);
                if (Query == null || Query.Count() == 0)
                    dsl.LogID = 1;
                else
                    dsl.LogID = (int)Query.Max() + 1;

                dsl.Load_Item_ID = dataLoadItem.Load_Item_ID;
                
                dsl.Message = Message;
                dsl.DateTimeStamp = DateTime.Now;
                dsl.LogType = (int)lgs + (int)lgt;
                dsl.Data_Load_ItemReference.EntityKey = dataLoadItem.EntityKey;
                dsl.SessionID = SessID ;
                
                ((System.Data.Objects.DataClasses.IEntityWithChangeTracker)dsl).SetChangeTracker(null);
                System.Data.EntityKey eKey= fid.DataStageLogs.Context.CreateEntityKey("DataStageLogs", dsl);
                System.Data.Objects.ObjectStateEntry entry;
                bool Exists= fid.ObjectStateManager.TryGetObjectStateEntry(eKey,out entry);
                
                if (!Exists )
                {
                    fid.DataStageLogs.AddObject (dsl);
                    fid.SaveChanges(); 
                }
            }
        }

        /// <summary>
        /// Sends dataload success/ failure mails .
        /// </summary>
        /// <param name="di"></param>
        /// <param name="lgs"></param>
        public void sendMail(Data_Load_Item di, LogState lgs)
        {
            string MessageDetails;
            string sMaxSessID;
            int iCnt;
            using (Scheduler.EntityModel.SchedulerDataEntity fid = new Scheduler.EntityModel.SchedulerDataEntity())
            {
                List<string> MaxSessID = new List<string>(from Log in fid.DataStageLogs 
                                where Log.Load_Item_ID==di.Load_Item_ID 
                                select Log.SessionID);
                sMaxSessID = MaxSessID.Max();
                List<string> schItems = new List<string >(from Log in fid.DataStageLogs
                       where Log.SessionID == sMaxSessID 
                       select Log.Message   );
                MessageDetails = "";
                iCnt = 1;
                foreach (string s in schItems)
                {
                    MessageDetails = MessageDetails + iCnt.ToString() + ". " + s + "\n\n";
                    iCnt++;
                }
            }
            string Message;
            if (lgs == LogState.Failure)
                Message = "Data Load for " + di.Load_Item_Name + " Failed\n\nDetailed Report:-\n\n";
            else 
                Message="Data Load for " + di.Load_Item_Name + " Succeeded\n\nDetailed Report:-\n\n";
            MailMessage mail = new MailMessage();
            SmtpClient SmtpServer = new SmtpClient("smtp.bnymellon.net");

            mail.From = new MailAddress("o017127@bnymellon.com");

            using (Scheduler.EntityModel.SchedulerDataEntity fid = new Scheduler.EntityModel.SchedulerDataEntity())
            {
                List<string> schItems = new List<string>(from EmailID in fid.Mailing_List
                                                         where EmailID.TraderEmailID.Contains("@")
                                                         select EmailID.TraderEmailID);
                foreach (string s in schItems)
                {
                    mail.To.Add(s);
                }
            }

            mail.Subject = "Data Load Status Mail :" + di.Load_Item_Name + " " + (lgs==LogState.Failure?"Failed":"Successful"); 
            mail.Body = generateUserFriendlyMessage(Message + MessageDetails) ;

            SmtpServer.Send(mail);
        }

        /// <summary>
        /// Generates session ID
        /// </summary>
        /// <param name="di"></param>
        /// <returns></returns>
        public string genrateSessionID(Data_Load_Item di)
        {
            string  sessionID;

            sessionID = DateTime.Now.ToString("yyyyMMddhhmmss")+di.Load_Item_ID.ToString("000") ;

            return sessionID;
        }

        public string generateUserFriendlyMessage(string systemMessage)
        {
            string str = "";
            List<Message_Conversion> MC;
            using (Scheduler.EntityModel.SchedulerDataEntity fid = new Scheduler.EntityModel.SchedulerDataEntity())
            {
                MC = new List<Message_Conversion>(from m in fid.Message_Conversion 
                     select m);
                str = systemMessage;
                foreach(Message_Conversion m in MC)
                {
                    str = str.ToLower().Replace(m.System_Message.ToLower(), m.User_Friendly_Message);
                }
            }
            
            return str;
        }

        public void SendToStatistics(int NumRead, int NumUpd)
        {
            using (Scheduler.EntityModel.SchedulerDataEntity fid = new Scheduler.EntityModel.SchedulerDataEntity())
            {
                Statistic s=new Statistic();

                s.SessionID = SessID;
                s.Tolerance_Min_Row_Nums = dataLoadItem.Tolerance_Min_Row_Nums;
                s.Min_Num_Rows = dataLoadItem.Min_Num_Rows;
                s.Num_Rows_Read = NumRead;
                s.Num_Rows_Written = NumUpd;
                s.Load_Item_ID  = dataLoadItem.Load_Item_ID;
                s.Data_Load_ItemReference.EntityKey = dataLoadItem.EntityKey;
                s.Load_DateTime = DateTime.Now;
                ((System.Data.Objects.DataClasses.IEntityWithChangeTracker)s).SetChangeTracker(null);
                System.Data.EntityKey eKey = fid.Statistics.Context.CreateEntityKey("Statistics", s);
                System.Data.Objects.ObjectStateEntry entry;
                bool Exists = fid.ObjectStateManager.TryGetObjectStateEntry(eKey, out entry);

                if (!Exists)
                {
                    fid.Statistics.AddObject(s);
                    fid.SaveChanges();
                }
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;
using FI_DataStage;

namespace Scheduler
{
    class FI_SQLHelper
    {
        public string GetCreateFromDataTableSQL(string tableName, DataTable table)
        {
            string sql = "CREATE TABLE [" + tableName + "] (\n";
            // columns
            foreach (DataColumn column in table.Columns)
            {
                sql += "[" + column.ColumnName + "] " + SQLGetType(column) + ",\n";
            }
            
            sql = sql.TrimEnd(new char[] { ',', '\n' }) + "\n";
            // primary keys
            if (table.PrimaryKey.Length > 0)
            {
                sql += "CONSTRAINT [PK_" + tableName + "] PRIMARY KEY CLUSTERED (";
                foreach (DataColumn column in table.PrimaryKey)
                {
                    sql += "[" + column.ColumnName + "],";
                }
                sql = sql.TrimEnd(new char[] { ',' }) + "))\n";
            }

            sql = sql + ")";
            return sql;
        }
        public string SQLGetType(object type, int columnSize, int numericPrecision, int numericScale)
        {

            switch (type.ToString())
            {
                case "System.String":
                    return "VARCHAR(" + ((columnSize == -1) ? 255 : columnSize) + ")";

                case "System.Decimal":
                    if (numericScale > 0)
                        return "REAL";
                    else if (numericPrecision > 10)
                        return "BIGINT";
                    else
                        return "INT";

                case "System.Double":
                case "System.Single":
                    return "REAL";

                case "System.Int64":
                    return "BIGINT";

                case "System.Int16":
                case "System.Int32":
                    return "INT";

                case "System.DateTime":
                    return "DATETIME";

                case "System.object":
                case "System.Object":
                    return "sql_variant";

                default:
                    throw new Exception(type.ToString() + " not implemented.");
            }
        }

        // Overload based on row from schema table
        public string SQLGetType(DataRow schemaRow)
        {
            return SQLGetType(schemaRow["DataType"],
                                int.Parse(schemaRow["ColumnSize"].ToString()),
                                int.Parse(schemaRow["NumericPrecision"].ToString()),
                                int.Parse(schemaRow["NumericScale"].ToString()));
        }
        // Overload based on DataColumn from DataTable type
        public string SQLGetType(DataColumn column)
        {
            return SQLGetType(column.DataType, column.MaxLength, 10, 2);
        }

        public void CreateTable(string tableName, System.Data.SqlClient.SqlConnection sqlCon, DataTable dt)
        {
            try
            {
                string cmd=  GetCreateFromDataTableSQL(tableName, dt);
                SqlHelper.ExecuteNonQuery(sqlCon, CommandType.Text, cmd);
            }
            catch(SqlException ex)
            {
                if (ex.Message.ToUpper().Contains("ALREADY EXISTS"))
                {
                    DataStageException dex = DataLoaderException.ConvertExceptionToDataStageException(ex);
                    dex.CreateLog();
                }
                else
                {
                    DataStageException dex = DataLoaderException.ConvertExceptionToDataStageException(ex);
                    throw dex;
                }
            }
            catch (Exception e)
            {
                DataStageException dex = DataLoaderException.ConvertExceptionToDataStageException(e);
                throw dex;
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Scheduler.CalendarService;

namespace Scheduler.EntityModel
{
    partial class Data_Load_Item
    {
        /// <summary>
        /// Retrieves formatted string from given input string
        /// </summary>
        /// <param name="Value"></param>
        /// <returns></returns>
        public static string GetFormattedString(string Value, string FlDtVal)
        {
            string originalValue;
            string repValue;
            string[] DTToken;
            string DTRepString = "";
            string[] DTOps = new string[] {"|", "[", "]" };
            string[] DTRepOps = new string[] {"[", "]" };
            string[] TVToken;
            string TVRepString = "";
            string[] TVOps = new string[] { "{", "}" };
            string[] TVRepOps = new string[] { "{", "}" };
            string[] QuotesSplit = new string[] {"'","'" };
            DateTime RepDate=DateTime.Now ;
            int OffSet;
            //string dt;
            string[] arr = new string[] {};
            originalValue = Value;

            //"CC", CStr(FormatDateTime(Now, DateFormat.ShortDate)), "US", "US", "National", "3"
            CalendarWebServiceSoapClient CalService = new CalendarWebServiceSoapClient();
            CalendarWebServiceSoap Cal=CalService.ChannelFactory.CreateChannel();
            
            repValue = originalValue;
            if (originalValue.Contains("[") && originalValue.Contains("]"))
            {
                DTRepString = "[" + originalValue.Split(DTRepOps, StringSplitOptions.None)[1] + "]";
            }

            if (originalValue.Contains("{") && originalValue.Contains("}"))
            {
                TVRepString = "{" + originalValue.Split(TVRepOps, StringSplitOptions.None)[1] + "}";
            }
            repValue = originalValue;
            repValue = repValue.Replace("[", "['");
            repValue = repValue.Replace("]", "']");
            repValue = repValue.Replace("{", "{'");
            repValue = repValue.Replace("}", "'}");
            repValue = repValue.Replace("|", "'|'");
            DTToken = repValue.Split(DTOps, StringSplitOptions.RemoveEmptyEntries);
            TVToken = repValue.Split(TVOps, StringSplitOptions.RemoveEmptyEntries);
            foreach (string tk in DTToken)
            {
                if (tk.StartsWith ( "'"))
                {
                    Array.Resize<string>(ref arr, arr.Length + 1);
                    arr[arr.Length - 1] = tk;
                }
            }
            if (arr.Length > 0)
            {
                if (int.TryParse(arr[0].Split(QuotesSplit,StringSplitOptions.RemoveEmptyEntries)[0], out OffSet))
                {
                    RepDate = DateTime.Parse(CalService.GetBusinessDateOffsetOnValidDays("CC", DateTime.Now.ToShortDateString(), "US", "US", "National",OffSet.ToString() ));
                }
                repValue = originalValue.Replace(DTRepString, RepDate.ToString(arr[1].Split(QuotesSplit,StringSplitOptions.RemoveEmptyEntries)[0]));

            }
            if (FlDtVal != null)
            { 
                string[] FlDtRep;
                DateTime refFlDate = DateTime.Now; ;
                DateTime CompDt;
            
                System.IO.FileInfo finf = new System.IO.FileInfo(repValue);
                FlDtRep = FlDtVal.Split(new string[] { "|" },StringSplitOptions.RemoveEmptyEntries );
                if (FlDtRep[0] == "C")
                    refFlDate = finf.CreationTime;
                else if (FlDtRep[0] == "M")
                    refFlDate = finf.LastWriteTime;
                int.TryParse(FlDtRep[1], out OffSet);
                CompDt= DateTime.Parse(CalService.GetBusinessDateOffsetOnValidDays("CC", DateTime.Now.ToShortDateString(), "US", "US", "National", OffSet.ToString()));
                if (refFlDate.Date  < CompDt.Date )
                    throw new Exception("The Source File is Stale. Please ensure that the latest file is available");
            }
            return repValue;
        }
    }
}

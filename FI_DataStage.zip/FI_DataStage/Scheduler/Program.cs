﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using FI_DataStage;
namespace Scheduler
{
    static class Program
    {
        static Timer tmr;
        static TaskScheduler tasks;
        /// <summary>
        /// The main entry point for the application.
        /// </summary>

        [STAThread]
        public static void Main(string[] args)
        {
            tasks = new TaskScheduler();
            if (args.Length > 0)
            {
                //MessageBox.Show("Test1 " + args.Length.ToString());
                if (args[0] == "\\SCHED")
                {
                    //MessageBox.Show("Test1 " + args.Length.ToString());
                    Application.EnableVisualStyles();
                    Application.SetCompatibleTextRenderingDefault(false);
                    tmr = new Timer();
                    tmr.Interval = 1000;
                    tmr.Tick += Timer_Tick;
                    tmr.Start();
                    Application.Run(new frmScheduler());
                }
                else if (args[0].Substring(0, 4) == "\\DL:")
                {
                    //MessageBox.Show("Test1 " + args.Length.ToString());
                    string dataLoadName;
                    dataLoadName = args[0].Replace("\\DL:", "").Trim();
                    //MessageBox.Show(dataLoadName);
                    tasks.StaticLoad(dataLoadName);
                }
            }
            else
            {
                //Load Tasks Form
                Application.Run(new frmScheduler());
            }
        }

        //[STAThread]
        //public static void Main(string[] args)
        //{
        //    //Char[] s;
        //    //string.Concat(
        //    Application.Run(new frmScheduler());
        //}


        private static void Timer_Tick(object sender, EventArgs e)
        {
            try
            {
                tasks.schedule(DateTime.Now);
            }
            catch (Exception)
            {

            }
        }
    }
}

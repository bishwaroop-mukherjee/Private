﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.ServiceModel.Description;

namespace DataStageETLService
{
    public class ServiceController
    {
        Uri baseAddress;

        List<ServiceHost> Hosts;

        private Dictionary<string, Type> _dataContracts;
        private Dictionary<string, Type> _serviceContractInterfaces;
        private Dictionary<string, Type> _serviceContractClasses;

        public ServiceController()
        {
            baseAddress = new Uri("http://localhost:8000/DataStageETLService/");
            Hosts = new List<ServiceHost>();
            _dataContracts = new Dictionary<string, Type>();
            _serviceContractClasses = new Dictionary<string, Type>();
            _serviceContractInterfaces = new Dictionary<string, Type>();
        }
        public void HostAll()
        {
            try
            {
                if(_serviceContractInterfaces==null)
                    throw new Exception("No service interface to host");
                if(_serviceContractClasses==null)
                    throw new Exception("No services to host");
                _serviceContractClasses.ToList().ForEach(s =>
                    {
                        Uri specificUri = new Uri(baseAddress.AbsoluteUri +s.Value.Name);
                        ServiceHost x = new ServiceHost(s.Value, specificUri);
                        Hosts.Add(x);
                        _serviceContractInterfaces.Where(st =>
                            {
                                Type[] ints = s.Value.GetInterfaces();
                                if(ints==null) return false;
                                if(ints.Length ==0) return false;
                                return ints.AsEnumerable().Contains(st.Value);
                            }).ToList().ForEach(I=>
                            {
                                x.AddServiceEndpoint(I.Value, new WSHttpBinding(),I.Value.Name);
                            });
                    });
                Hosts.ToList().ForEach(h =>
                    {
                        ServiceMetadataBehavior smb = new ServiceMetadataBehavior(){HttpGetEnabled=true};
                        
                        h.Description.Behaviors.Add(smb);

                        // Step 5 Start the service.
                        h.Open();
                    });
            }
            catch(Exception ex)
            {
            }
        }
        public void StopServices()
        {
            Hosts.ToList().ForEach(h => h.Close());
        }
        public bool RegisterContract(string Name, Type dataType)
        {
            object[] attrs = dataType.GetCustomAttributes(typeof(ETLServiceLibrary.ETLPublishServiceAttribute), false);
            if (attrs == null) return false;
            if (attrs.Length == 0)
                return false;
            else
            {
                ETLServiceLibrary.ETLPublishServiceAttribute[] attrData;
                attrData = dataType.GetCustomAttributesData().Where(at => at.GetType().Equals(typeof(ETLServiceLibrary.ETLPublishServiceAttribute))).Cast<ETLServiceLibrary.ETLPublishServiceAttribute>().ToArray();
                if (attrData.AsEnumerable().Where(t => t.PubType == "ServiceClass").Count() > 0)
                    _serviceContractClasses.Add(dataType.FullName, dataType);
                if (attrData.AsEnumerable().Where(t => t.PubType == "ServiceInterface").Count() > 0)
                    _serviceContractInterfaces.Add(dataType.FullName, dataType);
                return true;
            }
        }

        public void RegisterAuto(System.Reflection.Assembly ass)
        {
            Type[] typesinAssembly;
            typesinAssembly = ass.GetTypes();
            typesinAssembly.AsEnumerable().Where(t =>
                {
                    object[] attrs = t.GetCustomAttributes(typeof(ETLServiceLibrary.ETLPublishServiceAttribute), false);
                    if (attrs == null) return false;
                    if (attrs.Length == 0)
                        return false;
                    else
                    {
                        //int cnt = attrs.AsEnumerable().Count(a=>((ETLServiceLibrary.ETLPublishServiceAttribute)a).PubType =="ServiceClass"||(ETLServiceLibrary.ETLPublishServiceAttribute)a).PubType =="ServiceInterface"
                        return true;
                    }
                }).ToList().ForEach(vt =>
                {
                    //ETLServiceLibrary.ETLPublishServiceAttribute [] attrData;
                    //List<System.Reflection.CustomAttributeData> attrData = vt.GetCustomAttributes().ToList();
                    //attrData = atData.Where(at=>at.Equals(typeof(ETLServiceLibrary.ETLPublishServiceAttribute))).Cast<ETLServiceLibrary.ETLPublishServiceAttribute>().ToArray();
                    
                    if (vt.IsClass)
                        _serviceContractClasses.Add(vt.FullName, vt);
                    if (vt.IsInterface)
                        _serviceContractInterfaces.Add(vt.FullName, vt);
                });
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Reflection;
using ServiceExposureLayer.ServiceBusinessProxyLayer;
using ServiceExposureLayer.ServiceImplementationLayer;
namespace DataStageETLService
{
    public partial class ETLApiService : ServiceBase
    {
        ServiceController s;
        public ETLApiService()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            s  = new ServiceController();
            Assembly DataStageAssemblyService = Assembly.GetAssembly(typeof(IDataStageETLService));
            //System.Diagnostics.Debugger.Launch();
            s.RegisterAuto(DataStageAssemblyService);
            //Assembly DataStageAssemblyServiceImpl = Assembly.GetAssembly(typeof(ServiceExposureLayer.ServiceImplementationLayer.DataStageETLService));
            //System.Diagnostics.Debugger.Launch();
            //s.RegisterAuto(DataStageAssemblyServiceImpl);
            s.HostAll();
        }

        protected override void OnStop()
        {
            s.StopServices();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using ETLServiceLibrary;
namespace FI_DataStage
{
    public abstract class ProgrammableDataSource : DataSourceClass
    {
        #region "Internal"

        // Global variables
        string sourceType;
        string sourceNameValue;
        string delim;
        bool header_present;
        bool merge_delim;
        System.IO.StreamReader txtRdr;
        List<List<string>> Data;
        List<string> Header;
        int tailSkipRows;
        int headSkipRows;
        private string sourceName;
        bool treatLeadingBlankAsData;
        string replaceLeadingBlank;

        #endregion

        #region IDataSource Members

         
        public override string TableName
        {
            get;
            set;
        }

         
        public override List<IDType> ID
        {
            get;
            set;
        }

         
        public override bool TreatLeadingBlankAsData
        {
            get;
            set;
        }

         
        public override string ReplaceLeadingBlank
        {
            get;
            set;
        }

         
        public override string SourceSpecification
        {
            get;
            set;
        }

         
        public string SourceName
        {
            get
            {
                return sourceName;
            }
            set
            {
                sourceName = value;
            }
        }

        /// <summary>
        /// gets/ sets source name
        /// </summary>

         
        public override string SourceNameValue
        {
            get
            {
                return sourceNameValue;
            }
            set
            {
                sourceNameValue = value;
            }
        }

        /// <summary>
        /// gets/sets source type name
        /// </summary>

         
        public override string SourceType
        {
            get
            {
                return sourceType;
            }
            set
            {
                sourceType = value;
            }
        }

         
        public override string SheetName
        {
            get;
            set;
        }

        /// <summary>
        /// gets/sets whether to merge delimiter
        /// </summary>

         
        public override bool Merge_Delim
        {
            get
            {
                return merge_delim;
            }
            set
            {
                merge_delim = value;
            }
        }

        /// <summary>
        /// gets/ sets value of head rows to be skipped
        /// </summary>

         
        public override int HeadSkipRows
        {
            get
            {
                return headSkipRows;
            }
            set
            {
                headSkipRows = value;
            }
        }

        /// <summary>
        /// gets/sets value of tail rows to be skipped.
        /// </summary>

         
        public override int TailSkipRows
        {
            get
            {
                return tailSkipRows;
            }
            set
            {
                tailSkipRows = value;
            }
        }

        /// <summary>
        /// gets/sets delim
        /// </summary>

         
        public override string Delim
        {
            get
            {
                if (delim == " ")
                    return "SPACE";
                else if (delim == "\t")
                    return "TAB";
                else
                    return delim;
            }
            set
            {
                if (value == "SPACE")
                    delim = " ";
                else if (value == "TAB")
                    delim = "\t";
                else
                    delim = value;
            }
        }

        /// <summary>
        /// gets/sets whether header present or not.
        /// </summary>

         
        public override bool Header_Present
        {
            get
            {
                return header_present;
            }
            set
            {
                header_present = value;
            }
        }


        #endregion

        #region "Programmable Datasource specific elements"
        protected ICollection<object> _inputs;
        public ProgrammableDataSource()
        {
            _inputs = null;
        }
        public ProgrammableDataSource(params object[] values)
        {
            _inputs = values;
        }
        public virtual void setinput(params object[] values)
        {
            _inputs = values;
        }
        public abstract void LoadInputs(IDataSource ds);
        #endregion
    }
}

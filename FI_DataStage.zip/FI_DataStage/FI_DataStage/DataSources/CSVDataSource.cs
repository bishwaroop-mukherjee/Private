﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.IO;
using System.Data.OleDb;
using log4net;
using log4net.Config;

namespace FI_DataStage
{
    public class CSVDataSource:IDataSource
    {
        #region IDataSource Members

        public string SourceType
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }
       
        #endregion

        #region "Internal"

        // Global variables 
        string sourceName;
        string delim;
        bool header_present;
        System.IO.StreamReader txtRdr;
        List<List<string>> Data;
        List<string> Header;

        int headSkipRows;
        int tailSkipRows;

        #endregion

        #region "Properties"

        public string SourceName
        {
            get
            {
                return sourceName;
            }
            set
            {
                sourceName = value;
            }
        }

        public int HeadSkipRows
        {
            get
            {
                return headSkipRows;
            }
            set
            {
                headSkipRows = value;
            }
        }

        public int TailSkipRows
        {
            get
            {
                return tailSkipRows;
            }
            set
            {
                tailSkipRows = value;
            }
        }

        public string Delim
        {
            get
            {
                return delim;
            }
            set
            {
                delim = value;
            }
        }
        public bool Header_Present
        {
            get
            {
                return header_present;
            }
            set
            {
                header_present = value;
            }
        }
        #endregion

        #region "Constructors"

        public CSVDataSource()
        {
            delim = ",";
            header_present = true;
            sourceName = "";
        }

        public CSVDataSource(string sourceName)
        {
            delim = ",";
            header_present = true;
            SourceName = sourceName;
        }

        public CSVDataSource(string fileName, string separator)
        {
            sourceName = fileName;
            delim = separator;
            header_present = true;
        }

         public CSVDataSource(string fileName, string separator, bool Hdr_Present)
        {
            sourceName = fileName;
            delim = separator;
            header_present = Hdr_Present;
        }

         public CSVDataSource(string fileName, string separator, bool Hdr_Present, int headerRows, int footerRows)
         {
             sourceName = fileName;
             delim = separator;
             header_present = Hdr_Present;
             headSkipRows = headerRows;
             tailSkipRows = footerRows;
         }
      
        #endregion

        #region Public Methods


        /// <summary>
        /// Gets data table 
        /// </summary>
        /// <returns>data table</returns>
        public System.Data.DataTable getDataTable()
        {
            try
            {
                DataTable dt = new DataTable();
            
                FileInfo fInf = new FileInfo(sourceName);
                string connString = "Provider=Microsoft.Jet.OLEDB.4.0;"
                                    + "Data Source=\"" + fInf.DirectoryName + "\\\";"  
                                    + "Extended Properties=\"text;HDR="+(header_present && headSkipRows==0?"Yes":"No") +";FMT=Delimited\"";

                string cmdString = string.Format("SELECT * FROM {0}", fInf.Name );
                try
                {
                    OleDbDataAdapter dataAdapter = new OleDbDataAdapter(cmdString, connString);
                    dataAdapter.Fill(dt);
                }
                catch (Exception ex)
                {
                    DataLoaderException DLex = new DataLoaderException(ex.Message,this );
                    throw DLex;
                }
                
                int hsr;
                int tsr;
                hsr = HeadSkipRows + (header_present && headSkipRows>0?1:0);
                for (int hCnt =0;hCnt<hsr ; hCnt++)
                    dt.Rows.RemoveAt(0);

                tsr = tailSkipRows ;
                for (; tsr > 0; tsr--)
                    dt.Rows.RemoveAt(dt.Rows.Count-1);

                return dt;
            }
            catch (DataLoaderException DLEx)
            {
                throw DLEx;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

      #endregion     
        
        public override string ToString()
        {
            return ("CSV File: " + sourceName );
        }

    }
}

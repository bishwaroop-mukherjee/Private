﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Data.OleDb;

namespace FI_DataStage
{
    public class TextDataSource:IDataSource
    {
        #region IDataSource Members

        public string SourceName
        {
            get
            {
                return textsource;
            }
            set
            {
                textsource = value;
            }
        }

        public string SourceType
        {
            get
            {
                return sourceType;
            }
            set
            {
                sourceType = value;
            }
        }

        #endregion

        #region "Internal"

        // Global variables
        string sourceType;
        string textsource;
        string delim;
        bool header_present;
        bool merge_delim;
        System.IO.StreamReader txtRdr;
        List<List<string>> Data;
        List<string> Header;
        int tailSkipRows;
        int headSkipRows;

        #endregion

        #region "Properties"
        public int TailSkipRows
        {
            get { return tailSkipRows; }
            set { tailSkipRows = value; }
        }

        public int HeadSkipRows
        {
            get { return headSkipRows; }
            set { headSkipRows = value; }
        }
        public string textSource
        {
            get
            {
                return textsource;
            }
            set
            {
                textsource = value;
            }
        }

        public string Delim
        {
            get
            {
                return delim;
            }
            set
            {
                delim = value;
            }
        }
        public bool Header_Present
        {
            get
            {
                return header_present;
            }
            set
            {
                header_present = value;
            }
        }
        public bool Merge_Delim
        {
            get
            {
                return merge_delim;
            }
            set
            {
                merge_delim = value;
            }
        }
        #endregion

        #region "Constructors"
        public TextDataSource()
        {
            delim = ",";
            header_present = true;
            merge_delim = false;
            textsource = "";
            TailSkipRows = 0;
            HeadSkipRows = 0;
        }

        public TextDataSource(string TextSource)
        {
            delim = ",";
            header_present = true;
            merge_delim = false;
            textsource = TextSource;
            TailSkipRows = 0;
            HeadSkipRows = 0;
        }
        public TextDataSource(string TxtSource, string delimiter)
        {
            delim = delimiter;
            header_present = true ;
            merge_delim = false;
            textsource = TxtSource;
            TailSkipRows = 0;
            HeadSkipRows = 0;
        }
        public TextDataSource(string TxtSource,string delimiter, bool Hdr_Present)
        {
            delim = delimiter;
            header_present = Hdr_Present;
            merge_delim = false;
            textsource = TxtSource;
            TailSkipRows = 0;
            HeadSkipRows = 0;
        }
        public TextDataSource(string TxtSource, string delimiter, bool Hdr_Present, bool mrg_delim)
        {
            delim = delimiter;
            header_present = Hdr_Present;
            merge_delim = mrg_delim;
            textsource = TxtSource;
            TailSkipRows = 0;
            HeadSkipRows = 0;
        }
        public TextDataSource(string TxtSource, string delimiter, bool Hdr_Present, bool mrg_delim, int tailSkip, int headSkip)
        {
            delim = delimiter;
            header_present = Hdr_Present;
            merge_delim = mrg_delim;
            textsource = TxtSource;
            TailSkipRows = tailSkip;
            HeadSkipRows = headSkip;
        }
        #endregion

        /// <summary>
        /// Reads data to array
        /// </summary>
        protected void ReadtoArray()
        {
            txtRdr = System.IO.File.OpenText(textsource);
            Data = new List<List<string>>();
            string[] adelim = new string[] { delim };
            List<string> line;
            string[] lineArr;
            string Line;
            if (headSkipRows > 0)
            {
                for (int hsr = headSkipRows; hsr > 0; hsr--)
                {
                    txtRdr.ReadLine();
                }
            }
            if (header_present)
            {
                Line = txtRdr.ReadLine();
                lineArr = Line.Split(adelim, StringSplitOptions.RemoveEmptyEntries);
                Header = new List<string>();
                Header.AddRange(lineArr);
            }

            while ((Line = txtRdr.ReadLine()) != null)
            {
                lineArr = Line.Split(adelim, (merge_delim ? StringSplitOptions.RemoveEmptyEntries : StringSplitOptions.None ));
                line = new List<string>();
                line.AddRange(lineArr);
                Data.Add(line);
            }

            if (!header_present)
            {
                Header = new List<string>();
                for (int cCnt = 0; cCnt < Data[0].Count; cCnt++)
                {
                    Header.Add("Column" + cCnt.ToString());
                }
            }
            txtRdr.Close();
        }

        /// <summary>
        /// Gets data table
        /// </summary>
        /// <returns>data table</returns>
        public System.Data.DataTable getDataTable()
        {
            System.Data.DataTable dt= new System.Data.DataTable();
            ReadtoArray();
            foreach (string s in Header)
                dt.Columns.Add(s);
            foreach (List<string> ln in Data)
            {
                dt.Rows.Add(ln.ToArray());
            }
            return dt;  
        }
        public override string ToString()
        {
            return ("Text File: " + SourceName);
        }
    }
}

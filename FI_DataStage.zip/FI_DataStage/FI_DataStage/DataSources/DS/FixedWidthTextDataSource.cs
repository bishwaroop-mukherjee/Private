﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Data.OleDb;
using System.Data;
using System.Xml.Serialization;
using System.Runtime.InteropServices;
using StringHelper;
using System.Runtime.Serialization;
using ETLServiceLibrary;
namespace FI_DataStage
{
    [Serializable]
    public class FixedWidthTextDataSource:DataSourceClass 
    {

        #region "Internal"

        // Global variables
        string sourceType;
        string sourceNameValue;
        string delim;
        bool header_present;
        bool merge_delim;
        System.IO.StreamReader txtRdr;
        List<List<string>> Data;
        List<string> Header;
        int tailSkipRows;
        int headSkipRows;
        private string sourceName;
        bool treatLeadingBlankAsData;
        string replaceLeadingBlank;

        #endregion

        #region IDataSource Members
        public override string TableName
        {
            get;
            set;
        }
        public override List<IDType> ID
        {
            get;
            set;
        }

        public override bool TreatLeadingBlankAsData
        {
            get
            {
                return treatLeadingBlankAsData;
            }
            set
            {
                treatLeadingBlankAsData = value;
            }
        }

        public override string ReplaceLeadingBlank
        {
            get
            {
                return replaceLeadingBlank;
            }
            set
            {
                replaceLeadingBlank = value;
            }
        }

        public override string SourceSpecification
        {
            get;
            set;
        }

        public string SourceName
        {
            get
            {
                return sourceName;
            }
            set
            {
                sourceName = value;
            }
        }

        /// <summary>
        /// gets/ sets source name
        /// </summary>
        public override string SourceNameValue
        {
            get
            {
                return sourceNameValue;
            }
            set
            {
                sourceNameValue = value;
            }
        }

        /// <summary>
        /// gets/sets source type name
        /// </summary>
        public override string SourceType
        {
            get
            {
                return sourceType;
            }
            set
            {
                sourceType = value;
            }
        }

        public override string SheetName
        {
            get;
            set;
        }

        /// <summary>
        /// gets/sets whether to merge delimiter
        /// </summary>
        public override bool Merge_Delim
        {
            get
            {
                return merge_delim;
            }
            set
            {
                merge_delim = value;
            }
        }

        /// <summary>
        /// gets/ sets value of head rows to be skipped
        /// </summary>
        [DataMember]
        public override int HeadSkipRows
        {
            get
            {
                return headSkipRows;
            }
            set
            {
                headSkipRows = value;
            }
        }

        /// <summary>
        /// gets/sets value of tail rows to be skipped.
        /// </summary>
        public override int TailSkipRows
        {
            get
            {
                return tailSkipRows;
            }
            set
            {
                tailSkipRows = value;
            }
        }

        /// <summary>
        /// gets/sets delim
        /// </summary>
        public override string Delim
        {
            get
            {
                if (delim == " ")
                    return "SPACE";
                else if (delim =="\t")
                    return "TAB";
                else
                    return delim;
            }
            set
            {
                if (value == "SPACE")
                    delim = " ";
                else if (value == "TAB")
                    delim = "\t";
                else
                    delim = value;
            }
        }

        /// <summary>
        /// gets/sets whether header present or not.
        /// </summary>
        public override bool Header_Present
        {
            get
            {
                return header_present;
            }
            set
            {
                header_present = value;
            }
        }

        #endregion


        #region "Constructors"
        /// .ctor
        /// </summary>
        public FixedWidthTextDataSource()
        {
            delim = ",";
            header_present = true;
            merge_delim = false;
            sourceNameValue = "";
            TailSkipRows = 0;
            HeadSkipRows = 0;
        }

        /// <summary>
        /// Parameterised .ctor
        /// </summary>
        /// <param name="sourceFilePath">Source path</param>
        public FixedWidthTextDataSource(string sourceFilePath)
        {
            delim = ",";
            header_present = true;
            merge_delim = false;
            sourceNameValue = sourceFilePath;
            TailSkipRows = 0;
            HeadSkipRows = 0;
        }

        /// <summary>
        /// Parameterised .ctor
        /// </summary>
        /// <param name="sourceFilePath">Source path</param>
        /// <param name="delimiter">Delimeter value</param>
        public FixedWidthTextDataSource(string sourceFilePath, string delimiter)
        {
            Delim = delimiter;
            header_present = true ;
            merge_delim = false;
            sourceNameValue = sourceFilePath;
            TailSkipRows = 0;
            HeadSkipRows = 0;
        }

        /// <summary>
        /// Parameterised .ctor
        /// </summary>
        /// <param name="sourceFilePath">Source path</param>
        /// <param name="delimiter">Delimeter value</param>
        /// <param name="Hdr_Present">Header present or not</param>
        public FixedWidthTextDataSource(string sourceFilePath, string delimiter, bool Hdr_Present)
        {
            Delim = delimiter;
            header_present = Hdr_Present;
            merge_delim = false;
            sourceNameValue = sourceFilePath;
            TailSkipRows = 0;
            HeadSkipRows = 0;
        }

        /// <summary>
        /// Parameterised .ctor
        /// </summary>
        /// <param name="sourceFilePath">Source path</param>
        /// <param name="delimiter">Delimeter value</param>
        /// <param name="Hdr_Present">Header present or not</param>
        /// <param name="mrg_delim">Whether to merge columns separated by delim</param>
        public FixedWidthTextDataSource(string sourceFilePath, string delimiter, bool Hdr_Present, bool mrg_delim)
        {
            Delim = delimiter;
            header_present = Hdr_Present;
            merge_delim = mrg_delim;
            sourceNameValue = sourceFilePath;
            TailSkipRows = 0;
            HeadSkipRows = 0;
        }

        /// <summary>
        /// Parameterised .ctor
        /// </summary>
        /// <param name="sourceFilePath">Source path</param>
        /// <param name="delimiter">Delimeter value</param>
        /// <param name="Hdr_Present">Header present or not</param>
        /// <param name="mrg_delim">Whether to merge columns separated by delim</param>
        /// <param name="tailSkip">Tail rows to be skipped</param>
        /// <param name="headSkip">Head rows to be skipped</param>
        public FixedWidthTextDataSource(string sourceFilePath, string delimiter, bool Hdr_Present, bool mrg_delim, int tailSkip, int headSkip)
        {
            Delim = delimiter;
            header_present = Hdr_Present;
            merge_delim = mrg_delim;
            sourceNameValue = sourceFilePath;
            TailSkipRows = tailSkip;
            HeadSkipRows = headSkip;
        }
        public FixedWidthTextDataSource(string sourceFilePath, string delimiter, bool Hdr_Present, bool mrg_delim, int tailSkip, int headSkip, bool treatLeadingBlnkAsData, string replaceLeadingBlnk)
        {
            Delim = delimiter;
            header_present = Hdr_Present;
            merge_delim = mrg_delim;
            sourceNameValue = sourceFilePath;
            TailSkipRows = tailSkip;
            HeadSkipRows = headSkip;
            TreatLeadingBlankAsData = treatLeadingBlnkAsData;
            ReplaceLeadingBlank = replaceLeadingBlnk;
        }
        #endregion

        /// <summary>
        /// Reads data to array
        /// </summary>
        protected void ReadtoArray()
        {

            try
            {
                txtRdr = System.IO.File.OpenText(sourceNameValue);
            }
            catch (Exception ex)
            {
                
                throw ex;
            } 
            Data = new List<List<string>>();
            string[] adelim = new string[] { delim, ". ",".\t",".\r",".\n" };
            List<string> line;
            string[] lineArr;
            string Line;
            if (headSkipRows > 0)
            {
                for (int hsr = headSkipRows; hsr > 0; hsr--)
                {
                    txtRdr.ReadLine();
                }
            }
            if (header_present)
            {
                Line = txtRdr.ReadLine();
                lineArr = Line.Split(adelim, StringSplitOptions.RemoveEmptyEntries);
                lineArr = Line.SplitDelim(delim, true, true);
                Header = new List<string>();
                Header.AddRange(lineArr.Select(t => (TableName == null ? "" : TableName + "_") + t).ToArray());
            }

            while ((Line = txtRdr.ReadLine()) != null)
            {
                if (TreatLeadingBlankAsData==true)
                {
                    Line = Line.Insert(Line.IndexOf("", 0), "(.)");
                    Line = Line.Replace("(.)" + delim, ReplaceLeadingBlank);
                    Line = Line.Replace("(.)", "");
                }
                
                lineArr = Line.Split(adelim, (merge_delim ? StringSplitOptions.RemoveEmptyEntries : StringSplitOptions.None ));
                lineArr = Line.SplitFixedWidth(new int[]{11});
                
                //lineArr = 
                //[DllImport("")];
                line = new List<string>();
                line.AddRange(lineArr);
                Data.Add(line);
            }

            if (!header_present)
            {
                Header = new List<string>();
                for (int cCnt = 0; cCnt < Data[0].Count; cCnt++)
                {
                    Header.Add((TableName==null?"":TableName + "_" ) + "Column" + cCnt.ToString());
                }
            }
            txtRdr.Close();
        }

        /// <summary>
        /// Gets data table
        /// </summary>
        /// <returns>data table</returns>
        public override System.Data.DataTable getDataTable()
        {
            System.Data.DataTable dt= new System.Data.DataTable();
            ReadtoArray();
            foreach (string s in Header)
                dt.Columns.Add(s);
            try
            {
                foreach (List<string> ln in Data)
                {
                    dt.Rows.Add(ln.ToArray());
                }
            }
            catch (Exception E)
            {
                E = E;
            }
            if (tailSkipRows > 0)
            {
                int tsr = tailSkipRows;
                for (; tsr > 0; tsr--)
                    dt.Rows.RemoveAt(dt.Rows.Count - 1);
            }
            return dt;  
        }
        public override string ToString()
        {
            return ("Text File: " + SourceNameValue);
        }

        public override List<string> getDataSchema()
        {
            DataTable dtTab = new DataTable();

            dtTab = getDataTable();
                                  
            IEnumerable <string> ColumnNames = from DataColumn d in dtTab.Columns 
                                       select d.ColumnName;
            return ColumnNames.ToList();
        }
    }
}

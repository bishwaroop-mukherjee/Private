﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Threading;

namespace FI_DataStage
{
    class BatchDataSource:ProgrammableDataSource
    {
        private Thread LoadThread;
        private DataTable ResultTable;
        private Dictionary<string,Thread> ThrInExec;
        public BatchDataSource():base()
        {
            _inputs = null;
        }

        public BatchDataSource(params object[] values)
        {
            _inputs = values;
        }

        public override void setinput(params object[] values)
        {
            _inputs = values;
        }

        private static void GetInputs(string FilePath)
        {
            DataTable dt = new DataTable();
            TextDataSource txt = new TextDataSource(FilePath);
            dt = txt.getDataTable();
        }

        List<WaitHandle> waitHandles;

        public override System.Data.DataTable getDataTable()
        {
            DataTable retTable=null;

            if (base._inputs == null)
                return null;

            if(base._inputs.Count==0)
                return null;
            
            try
            {
                ResultTable = new DataTable();
                waitHandles = new List<WaitHandle>();
                List<DataRow> SourceInputRows = new List<DataRow>(_inputs.AsEnumerable().Cast<DataRow>());
                List<DataRow> CurrChunk= new List<DataRow>();
                //int i = 0;
                //ThrInExec = new Dictionary<string,Thread>();
                //ThrInExec.Clear();
                while (SourceInputRows.Count > 0)
                {
                    CurrChunk.AddRange(SourceInputRows.GetRange(0, SourceInputRows.Count>=32?32:SourceInputRows.Count));
                    SourceInputRows.RemoveRange(0, SourceInputRows.Count >= 32 ? 32 : SourceInputRows.Count);
                    foreach (DataRow row in CurrChunk)
                    {
                        //LoadThread = new Thread(new ParameterizedThreadStart(LoadDataSource));
                        DataSourceFactory dsFactory = new DataSourceFactory(this.TableName, this.UnderlyingDS, row[this.SourceName + "_" + "FPath"].ToString(),
                                                                            this.SheetName, null, this.TailSkipRows, this.HeadSkipRows,
                                                                            this.Delim, this.Merge_Delim, this.Header_Present, this.ID.Cast<ComplexTempType>().ToList(), null, null, this.SourceSpecification, this.TreatLeadingBlankAsData, this.ReplaceLeadingBlank,
                                                                            this.UnderlyingDS);
                        DataSourceClass dsc = dsFactory.GetDataSourceInstance();
                        waitHandles.Add(new AutoResetEvent(false));
                        //ThreadPool.QueueUserWorkItem(new WaitCallback(LoadDataSource), new { Data = dsc, Inp = row, state = waitHandles[63] });
                        ThreadPool.QueueUserWorkItem(new WaitCallback(LoadDataSource), new { Data = dsc, Inp = row, state = waitHandles[waitHandles.Count - 1] });

                        //LoadThread.Start(new { Data = dsc, Inp = row });
                        //lock (ThrInExec)
                        //{
                        //    ThrInExec.Add(row[this.SourceName + "_" + "FPath"].ToString(), LoadThread);
                        //}
                        //i++;

                    }
                    WaitHandle.WaitAll(waitHandles.ToArray());
                    waitHandles.Clear();
                    CurrChunk.Clear();
                }
                //Thread
                //while (ThrInExec.Count > 0)
                //{
                //    lock (ThrInExec)
                //    {
                //        for (int iTC = 0; iTC < ThrInExec.Count; iTC++)
                //        {
                //            string k;
                //            k = ThrInExec.ElementAt(iTC).Key;
                //            if (ThrInExec[k].ThreadState == ThreadState.Stopped || ThrInExec[k].ThreadState == ThreadState.Aborted)
                //            {
                //                ThrInExec.Remove(k);
                //            }
                //        }
                //    }
                //}
                lock (ResultTable)
                {
                    retTable = ResultTable;
                }
                return retTable;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public override void LoadInputs(IDataSource ds)
        {
            if (ds == null)
                throw new DataLoaderException("Inputs not furnished properly", this);
            
            DataTable dt = new DataTable();
            dt =  ds.getDataTable();
            this.SourceName = ds.TableName;
            base.setinput(dt.AsEnumerable().ToArray());
            dt.Dispose();
        }
        private void LoadDataSource(dynamic dsInp)
        {
            try
            {
                AutoResetEvent are = (AutoResetEvent)dsInp.state;

                DataTable dt;
                dynamic data= dsInp;
                DataSourceClass ds = data.Data;
                DataRow dr = data.Inp;
                if (ds.GetType().IsSubclassOf(typeof(ProgrammableDataSource)))
                {
                    ProgrammableDataSource pds = (ProgrammableDataSource)ds;
                    dt = pds.getDataTable();
                    lock (ResultTable)
                    {
                        if (ResultTable.Columns.Count == 0)
                        {
                            dt.Columns.Cast<DataColumn>().Concat(dr.Table.Columns.Cast<DataColumn>()).ToList().ForEach(c => ResultTable.Columns.Add(c.ColumnName));
                        }
                        dt.AsEnumerable().ToList().ForEach(r => ResultTable.Rows.Add(r.ItemArray.Concat(dr.ItemArray)));

                        dt.Dispose();
                    }
                    //lock (ThrInExec)
                    //{
                        are.Set();
                        //ThrInExec.Remove(ds.SourceNameValue);
                    //}

                }
                else
                {
                    DataSourceClass ids = (DataSourceClass)ds;
                    if(ids.SourceNameValue != null && ids.SourceNameValue != "")
                    {
                        dt = ids.getDataTable();
                        lock (ResultTable)
                        {
                            if (ResultTable.Columns.Count  == 0)
                            {
                                dt.Columns.Cast<DataColumn>().Concat(dr.Table.Columns.Cast<DataColumn>()).ToList().ForEach(c => ResultTable.Columns.Add(c.ColumnName));
                            }
                            dt.AsEnumerable().ToList().ForEach(r => ResultTable.Rows.Add(r.ItemArray.Concat(dr.ItemArray).ToArray()));
                            dt.Dispose();
                        }
                        //lock (ThrInExec)
                        //{
                            are.Set();
                            //ThrInExec.Remove(ds.SourceNameValue);
                        //}
                    }
                }
            }
            catch (Exception ex)
            {
                ex = ex;
            }
        }

        public override List<string> getDataSchema()
        {
            return null;
        }
    }

}

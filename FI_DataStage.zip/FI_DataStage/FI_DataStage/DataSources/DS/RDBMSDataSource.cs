﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using System.Data.SqlClient;
//using Microsoft.ApplicationBlocks.Data;
using System.Data;
using System.IO;

namespace FI_DataStage
{
    [Serializable]
    public class RDBMSDataSource : DataSourceClass
    {
        // variable declarations
        string sConStr = "";
        private string sourceNameValue;
        private string srcTable;
        private string sourceType;
        private string sourceName;
        private string sourceSpecification;

        # region "Constructors"

        public RDBMSDataSource()
        {
            sourceNameValue = "";
        }

        public RDBMSDataSource(string sFilePath)
        {
            sourceNameValue = sFilePath;
        }

        public RDBMSDataSource(string sFilePath, string srcSpec)
        {
            sourceNameValue = sFilePath;
            sourceSpecification = srcSpec;
        }
        #endregion

        #region IDataSource Members

        public override string TableName
        {
            get;
            set;
        }
        public override List<IDType> ID
        {
            get;
            set;
        }
        public override bool TreatLeadingBlankAsData
        {
            get;
            set;
        }

        public override string ReplaceLeadingBlank
        {
            get;
            set;
        }

        public string SourceName
        {
            get
            {
                return sourceName;
            }
            set
            {
                sourceName = value;
            }
        }

        public override string SourceNameValue
        {
            get
            {
                return sourceNameValue;
            }
            set
            {
                sourceNameValue = value;
            }
        }

        public override string SourceType
        {
            get
            {
                return sourceType;
            }
            set
            {
                sourceType = value;
            }
        }

        public override int TailSkipRows
        {
            get;
            set;
        }

        public override int HeadSkipRows
        {
            get;
            set;
        }

        public string TextSource
        {
            get;
            set;
        }

        public override string Delim
        {
            get;
            set;
        }

        public override bool Header_Present
        {
            get;
            set;
        }

        public override bool Merge_Delim
        {
            get;
            set;
        }

        public override string SheetName
        {
            get;
            set;
        }

        public override string SourceSpecification
        {
            get
            {
                return sourceSpecification;
            }
            set
            {
                sourceSpecification = value;
            }
        }

        /// <summary>
        /// Gets data table from source
        /// </summary>
        /// <returns></returns>
        public override System.Data.DataTable getDataTable()
        {
            string sSourceTable = "";

            return importRDBMS();
        }

        public override List<string> getDataSchema()
        {
           
            DataTable dtTab = new DataTable();

            dtTab = getDataTable();

            IEnumerable<string> ColumnNames = from DataColumn d in dtTab.Columns
                                              select d.ColumnName;


            return ColumnNames.ToList();
        }

        /// <summary>
        /// Import data from Access database to data table.
        /// </summary>
        /// <param name="sFolderName">Source folder name</param>
        /// <param name="sFileName">Source file name</param>
        /// <param name="sSourceTable">Source data table</param>
        /// <returns></returns>
        private DataTable importRDBMS()
        {
            try
            {
                string query ="";
                string[] sSpecSubStr = sourceSpecification.Split(new char[] { ':' }, 2);
                if(sSpecSubStr.Contains<string>("Table"))
                {
                    query = "Select * from " + sSpecSubStr[1];
                }
                else if (sSpecSubStr.Contains<string>("Query"))
                {
                    query = sSpecSubStr[1];
                }
                DataTable results = new DataTable();
                SqlConnection conn = new SqlConnection(sourceNameValue);
                    
                conn.Open();
                SqlCommand cmd = new SqlCommand(query, conn);

                SqlDataAdapter da = new SqlDataAdapter()
                    {
                        SelectCommand = cmd
                    };
                da.Fill(results);
                results.Columns.Cast<DataColumn>().ToList().ForEach(Col =>
                    {
                        Col.ColumnName = (TableName == null ? "" : TableName + "_") + Col.ColumnName;
                    });
                return results;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion

        public override string ToString()
        {
            return ("RDBMS File: " + sourceNameValue + " ....... Table Name:" + srcTable);
        }
    }
}
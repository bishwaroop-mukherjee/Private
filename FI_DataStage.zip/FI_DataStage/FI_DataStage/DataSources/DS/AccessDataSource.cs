﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using System.Data.SqlClient;
//using Microsoft.ApplicationBlocks.Data;
using System.Data;
using System.IO;

namespace FI_DataStage
{
    [Serializable]
    public class AccessDataSource : DataSourceClass 
    {
        // variable declarations
        string sConStr = "";
        private string sourceNameValue;
        private string srcTable;
        private string sourceType;
        private string sourceName;
        private string sourceSpecification;

        # region "Constructors"

        public AccessDataSource()
        {
            sourceNameValue = "";
        }

        public AccessDataSource(string sFilePath)
        {
            sourceNameValue = sFilePath;
        }

        public AccessDataSource(string sFilePath, string srcSpec)
        {
            sourceNameValue = sFilePath;
            sourceSpecification = srcSpec;
        }

        #endregion

        #region IDataSource Members
        public override string TableName
        {
            get;
            set;
        }
        public override List<IDType> ID
        {
            get;
            set;
        }

        public string SourceName
        {
            get
            {
                return sourceName;
            }
            set
            {
                sourceName= value;
            }
        }

        public override bool TreatLeadingBlankAsData
        {
            get;
            set;
        }

        public override string ReplaceLeadingBlank
        {
            get;
            set;
        }

        public override string SourceNameValue
        {
            get
            {
                return sourceNameValue;
            }
            set
            {
                sourceNameValue = value;
            }
        }

        public override string SourceType
        {
            get
            {
                return sourceType;
            }
            set
            {
                sourceType = value;
            }
        }

        public override int TailSkipRows
        {
            get;
            set;
        }

        public override int HeadSkipRows
        {
            get;
            set;
        }

        public string TextSource
        {
            get;
            set;
        }

        public override string Delim
        {
            get;
            set;
        }

        public override bool Header_Present
        {
            get;
            set;
        }

        public override bool Merge_Delim
        {
            get;
            set;
        }

        public override string SheetName
        {
            get;
            set;
        }

        public override string SourceSpecification
        {
            get
            {
                return sourceSpecification;
            }
            set
            {
                sourceSpecification = value;
            }
        }

        /// <summary>
        /// Gets data table from source
        /// </summary>
        /// <returns></returns>
        public override System.Data.DataTable getDataTable()
        {
            //string sSourceTable = "Option_Tables";

            FileInfo fInf = new FileInfo(sourceNameValue);

            string sFolderName = fInf.DirectoryName;

            string sFileName = fInf.Name;

            return importAccess(sFolderName, sFileName, sourceSpecification);
        }

        public override List<string> getDataSchema()
        {
            DataTable dtTab = new DataTable();

            dtTab = getDataTable();

            IEnumerable<string> ColumnNames = from DataColumn d in dtTab.Columns
                                              select d.ColumnName;

            return ColumnNames.ToList();
        }

        /// <summary>
        /// Import data from Access database to data table.
        /// </summary>
        /// <param name="sFolderName">Source folder name</param>
        /// <param name="sFileName">Source file name</param>
        /// <param name="sSourceTable">Source data table</param>
        /// <returns></returns>
        private DataTable importAccess(string sFolderName, string sFileName, string sSourceTable)
        {
            try
            {
                string query = "";
                string[] sSpecSubStr = sourceSpecification.Split(new char[] { ':' }, 2);
                if (sSpecSubStr.Contains<string>("Table"))
                {
                    query = "Select * from " + sSpecSubStr[1];
                }
                else if (sSpecSubStr.Contains<string>("Query"))
                {
                    query = sSpecSubStr[1];
                }

                string connString = "PROVIDER=Microsoft.Jet.OLEDB.4.0; Data Source=" + sourceNameValue;

                DataTable results = new DataTable();
                using (OleDbConnection conn = new OleDbConnection(connString))
                {
                    OleDbCommand cmd = new OleDbCommand(query, conn);
                    conn.Open();
                    OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
                    adapter.Fill(results);
                    results.Columns.Cast<DataColumn>().ToList().ForEach(Col =>
                    {
                        Col.ColumnName = (TableName == null ? "" : TableName + "_") + Col.ColumnName;
                    });

                }
                return results;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion

        public override string ToString()
        {
            return ("Access File: " + sourceNameValue + " ....... Table Name:" + srcTable);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Runtime.Serialization;
using ETLServiceLibrary;
namespace FI_DataStage
{
    class BloombergDataSource:ProgrammableDataSource 
    {
        private BloombergExternalDataAccess.clsBbgData AlienContact;
        public BloombergDataSource(ICollection<string> Securities,ICollection<string> Fields):base(Securities,Fields)
        {
            try
            {
                AlienContact = BloombergExternalDataAccess.clsBbgData.Instance();
                AlienContact.SessionStart(5);
            }
            catch(BloombergExternalDataAccess.LoginException Le)
            {
                AlienContact = null;
                throw Le;
            }
        }
        public BloombergDataSource():base()
        {
            try
            {
                AlienContact = BloombergExternalDataAccess.clsBbgData.Instance();
                AlienContact.SessionStart(5);
            }
            catch (BloombergExternalDataAccess.LoginException Le)
            {
                AlienContact = null;
                throw Le;
            }
        }

        public override string SourceSpecification
        {
            get;
            set;
        }
        public override bool TreatLeadingBlankAsData
        {
            get;
            set;
        }
        public override string ReplaceLeadingBlank
        {
            get;
            set;
        }

        private static void GetInputs(string FilePath)
        {
            DataTable dt = new DataTable();
            CSVDataSource csv = new CSVDataSource(FilePath);
            dt = csv.getDataTable();
        }

        public override System.Data.DataTable getDataTable()
        {
            if (base._inputs == null)
                return null;

            if(AlienContact==null)
                return null;
            
            if(base._inputs.Count!=2)
                return null;

            try
            {
                return AlienContact.GetData(((ICollection<string>)base._inputs.ToArray()[0]).ToArray(),((ICollection<string>)base._inputs.ToArray()[1]).ToArray());
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public override void LoadInputs(IDataSource ds)
        {
            DataTable dt = ds.getDataTable();
            string[] Sec = (from r in dt.AsEnumerable()
                                   where r[1].ToString().ToUpper() == "S"
                                   select r[0].ToString()).ToArray();
            string[] Fld = (from r in dt.AsEnumerable()
                                   where r[1].ToString().ToUpper() == "F"
                                   select r[0].ToString()).ToArray();
            if (Sec.Length > 0 && Fld.Length > 0)
                base.setinput(Sec, Fld);
        }

       // public override void LoadInputs() { }
        //~BloombergDataSource()
        //{
        //    AlienContact.SessionStop();
        //}

        public override List<string> getDataSchema()
        {
            return null;
        }
    }
}

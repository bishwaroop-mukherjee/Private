﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Sql;
using System.IO;
//using Microsoft.ApplicationBlocks.Data;
using System.Data.SqlClient;
using System.Xml;
namespace FI_DataStage
{
    [Serializable]
    public class XMLDirectDataSource:DataSourceClass 
    {

        string sourceNameValue;
        string sourceType;

        #region Constructors

        public XMLDirectDataSource()
        {
            SourceNameValue = "";
        }

        public XMLDirectDataSource(string filePath)
        {
            sourceNameValue = filePath;
        }

        #endregion

        #region IDataSource Members

        public override string TableName
        {
            get;
            set;
        }
        public override List<IDType> ID
        {
            get;
            set;
        }

        public override string SourceSpecification
        {
            get;
            set;
        }

        public override System.Data.DataTable getDataTable()
        {
            DataTable dt = new DataTable();

            //DirectoryInfo dir = new DirectoryInfo(sourceNameValue);

            ImportGenericXML(sourceNameValue, ref dt,"report");
            return dt;
        }

        public override List<string> getDataSchema()
        {
            DataTable dtTab = new DataTable();

            dtTab = getDataTable();

            IEnumerable<string> ColumnNames = from DataColumn d in dtTab.Columns
                                              select d.ColumnName;


            return ColumnNames.ToList();
        }

        public string SourceName
        {
            get
            {
                return sourceName;
            }
            set
            {
                sourceName= value;
            }
        }
        public override bool TreatLeadingBlankAsData
        {
            get;
            set;
        }

        public override string ReplaceLeadingBlank
        {
            get;
            set;
        }

        public override string SourceNameValue
        {
            get
            {
                return sourceNameValue;
            }
            set
            {
                sourceNameValue = value;
            }
        }

        public override string SourceType
        {
            get
            {
                return sourceType;
            }
            set
            {
                sourceType = value;
            }
        }

        public override int TailSkipRows
        {
            get;
            set;
        }

        public override int HeadSkipRows
        {
            get;
            set;
        }

        public string TextSource
        {
            get;
            set;
        }

        public override string Delim
        {
            get;
            set;
        }


        public override bool Header_Present
        {
            get;
            set;
        }

        public override bool Merge_Delim
        {
            get;
            set;
        }

        public override string SheetName
        {
            get;
            set;
        }

        #endregion

        /// <summary>
        /// Declarations
        /// </summary>
        public static string sConStr = "";
        private string sourceName;

        #region Public Methods

        /// <summary>
        /// Load destination xml file into a table on sql server. by vishalm on 03-01-2012
        /// </summary>
        /// <param name="sFilePath">file to be imported</param>
        /// <param name="sTableName">destination table name</param>
        /// <param name="bTruncateTable">whether to truncate table before import</param>
        public void ImportGenericXML(string sFilePath, ref DataTable dt,string NodeName)
        {
            try
            {
                DataSet dsXML = new DataSet();
                XmlDocument xld = new XmlDocument();

                //dsXML.ReadXmlSchema(sFilePath);
                //dsXML.ReadXml(sFilePath, XmlReadMode.Auto);
                //dt = dsXML.Tables[1];

                ////DataSet ds = new DataSet();
                FileStream fs = File.Open(sourceNameValue,FileMode.Open);
                xld.Load(fs);
                dynamic Nodes = xld.GetElementsByTagName(NodeName);
                //////File.open
                XmlNodeList x;
                Nodes.Item(0).Attributes.RemoveAll();
                StringReader txtr = new StringReader(Nodes.Item(0).OuterXml);
                dsXML.ReadXml(txtr);
                dt = dsXML.Tables[0];
                //////dt.ReadXmlSchema(xrd);
                //////dt.ReadXml(xrd);
                ////fs.Close();
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
        }

        /// <summary>
        /// Gets deepest xml node 
        /// </summary>
        /// <param name="node">xml node</param>
        /// <param name="tbls">datatable</param>
        public void GetDeepestNodeTable(XmlNode node, ref System.Data.DataTable[] tbls)
        {
            if (!node.FirstChild.FirstChild.HasChildNodes)
            {
                DataSet dt = new DataSet();
                Array.Resize<System.Data.DataTable>(ref tbls, tbls.Length + 1);
                dt.Clear();
                dt.Relations.Clear();
                XmlNode nd = node.ParentNode;
                nd.Attributes.RemoveAll();
                System.IO.StringReader str = new System.IO.StringReader(nd.OuterXml);
                dt.ReadXml(str);
                dt.Tables[0].TableName = nd.Name;
                tbls[0] = dt.Tables[0];
                //tbls[tbls.Length - 1] = dt.Tables[0];
            }
            else
            {
                foreach (XmlNode nd in node.ChildNodes)
                {
                    GetDeepestNodeTable(nd, ref tbls);
                }
            }
        }
        
        #endregion

        public override string ToString()
        {
            return ("XML File: " + SourceNameValue );
        }
    }
}

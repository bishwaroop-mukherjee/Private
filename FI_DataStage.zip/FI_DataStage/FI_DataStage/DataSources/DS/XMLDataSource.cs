﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Sql;
//using Microsoft.ApplicationBlocks.Data;
using System.Data.SqlClient;
using System.Xml;
namespace FI_DataStage
{
    [Serializable]
    public class XMLDataSource:DataSourceClass 
    {

        string sourceNameValue;
        string sourceType;

        #region Constructors

        public XMLDataSource()
        {
            SourceNameValue = "";
        }

        public XMLDataSource(string filePath)
        {
            sourceNameValue = filePath;
        }

        #endregion

        #region IDataSource Members

        public override string TableName
        {
            get;
            set;
        }
        public override List<IDType> ID
        {
            get;
            set;
        }

        public override string SourceSpecification
        {
            get;
            set;
        }

        public override System.Data.DataTable getDataTable()
        {
            DataTable dt = new DataTable();
            ImportGenericXML(sourceNameValue, ref dt);
            return dt;
        }

        public override List<string> getDataSchema()
        {
            DataTable dtTab = new DataTable();

            dtTab = getDataTable();

            IEnumerable<string> ColumnNames = from DataColumn d in dtTab.Columns
                                              select d.ColumnName;


            return ColumnNames.ToList();
        }

        public string SourceName
        {
            get
            {
                return sourceName;
            }
            set
            {
                sourceName= value;
            }
        }
        public override bool TreatLeadingBlankAsData
        {
            get;
            set;
        }

        public override string ReplaceLeadingBlank
        {
            get;
            set;
        }

        public override string SourceNameValue
        {
            get
            {
                return sourceNameValue;
            }
            set
            {
                sourceNameValue = value;
            }
        }

        public override string SourceType
        {
            get
            {
                return sourceType;
            }
            set
            {
                sourceType = value;
            }
        }

        public override int TailSkipRows
        {
            get;
            set;
        }

        public override int HeadSkipRows
        {
            get;
            set;
        }

        public string TextSource
        {
            get;
            set;
        }

        public override string Delim
        {
            get;
            set;
        }


        public override bool Header_Present
        {
            get;
            set;
        }

        public override bool Merge_Delim
        {
            get;
            set;
        }

        public override string SheetName
        {
            get;
            set;
        }

        #endregion

        /// <summary>
        /// Declarations
        /// </summary>
        public static string sConStr = "";
        private string sourceName;

        #region Public Methods

        /// <summary>
        /// Load destination xml file into a table on sql server. by vishalm on 03-01-2012
        /// </summary>
        /// <param name="sFilePath">file to be imported</param>
        /// <param name="sTableName">destination table name</param>
        /// <param name="bTruncateTable">whether to truncate table before import</param>
        public void ImportGenericXML(string sFilePath, ref DataTable dt)
        {
            try
            {
                XmlDocument xld = xld = new XmlDocument();
                System.Data.DataTable[] dtTables = new System.Data.DataTable[0];
                xld.Load(sFilePath);

                XmlNode nd;
                nd = xld.CloneNode(true);
                GetDeepestNodeTable(nd.ChildNodes[1], ref dtTables);
                dt = dtTables[0];
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
        }

        /// <summary>
        /// Gets deepest xml node 
        /// </summary>
        /// <param name="node">xml node</param>
        /// <param name="tbls">datatable</param>
        public void GetDeepestNodeTable(XmlNode node, ref System.Data.DataTable[] tbls)
        {
            if (!node.FirstChild.FirstChild.HasChildNodes)
            {
                DataSet dt = new DataSet();
                Array.Resize<System.Data.DataTable>(ref tbls, tbls.Length + 1);
                dt.Clear();
                dt.Relations.Clear();
                XmlNode nd = node.ParentNode;
                nd.Attributes.RemoveAll();
                System.IO.StringReader str = new System.IO.StringReader(nd.OuterXml);
                dt.ReadXml(str);
                dt.Tables[0].TableName = nd.Name;
                tbls[tbls.Length - 1] = dt.Tables[0];
            }
            else
            {
                foreach (XmlNode nd in node.ChildNodes)
                {
                    GetDeepestNodeTable(nd, ref tbls);
                }
            }
        }
        
        #endregion

        public override string ToString()
        {
            return ("XML File: " + SourceNameValue );
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.IO;
using System.Data.OleDb;


namespace FI_DataStage
{
    [Serializable]
    public class CSVDataSource_Old : DataSourceClass
    {

        // Global variables 
        string sourceNameValue;
        string delim;
        bool header_present;
        System.IO.StreamReader txtRdr;
        List<List<string>> Data;
        List<string> Header;
        string sourceType;
        bool merge_delim;

        int headSkipRows;
        int tailSkipRows;
        private string sourceName;

        #region IDataSource Members
        public override string TableName
        {
            get;
            set;
        }
        public override List<IDType> ID
        {
            get;
            set;
        }
        public override bool TreatLeadingBlankAsData
        {
            get;
            set;
        }

        public override string ReplaceLeadingBlank
        {
            get;
            set;
        }

        public override string SourceSpecification
        {
            get;
            set;
        }

        public override string SourceType
        {
            get
            {
                return sourceType;
            }
            set
            {
                sourceType = value;
            }
        }

        public override string SheetName
        {
            get;
            set;
        }

        public override bool Merge_Delim
        {
            get
            {
                return merge_delim;
            }
            set
            {
                merge_delim = value;
            }
        }

        public string SourceName
        {
            get
            {
                return sourceName;
            }
            set
            {
                sourceName = value;
            }
        }

        public override string SourceNameValue
        {
            get
            {
                return sourceNameValue;
            }
            set
            {
                sourceNameValue = value;
            }
        }

        public override int HeadSkipRows
        {
            get
            {
                return headSkipRows;
            }
            set
            {
                headSkipRows = value;
            }
        }

        public override int TailSkipRows
        {
            get
            {
                return tailSkipRows;
            }
            set
            {
                tailSkipRows = value;
            }
        }

        public override string Delim
        {
            get
            {
                return delim;
            }
            set
            {
                delim = value;
            }
        }
        public override bool Header_Present
        {
            get
            {
                return header_present;
            }
            set
            {
                header_present = value;
            }
        }
        #endregion

        #region "Constructors"

        public CSVDataSource_Old()
        {
            delim = ",";
            header_present = true;
            sourceNameValue = "";
        }

        public CSVDataSource_Old(string sourceFilePath)
        {
            delim = ",";
            header_present = true;
            SourceNameValue = sourceFilePath;
        }

        public CSVDataSource_Old(string sourceFilePath, string separator)
        {
            sourceNameValue = sourceFilePath;
            delim = separator;
            header_present = true;
        }

        public CSVDataSource_Old(string sourceFilePath, string separator, bool Hdr_Present)
        {
            sourceNameValue = sourceFilePath;
            delim = separator;
            header_present = Hdr_Present;
        }

        public CSVDataSource_Old(string sourceFilePath, string separator, bool Hdr_Present, int headerRows, int footerRows)
        {
            sourceNameValue = sourceFilePath;
            delim = separator;
            header_present = Hdr_Present;
            headSkipRows = headerRows;
            tailSkipRows = footerRows;
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Gets data table 
        /// </summary>
        /// <returns>data table</returns>
        public override System.Data.DataTable getDataTable()
        {
            try
            {
                DataTable dt = new DataTable();
                ReadtoArray();
                foreach (string s in Header)
                    dt.Columns.Add(s);
                foreach (List<string> ln in Data)
                {
                    dt.Rows.Add(ln.ToArray());
                }

                int hsr;
                int tsr;
                hsr = HeadSkipRows + (header_present && headSkipRows > 0 ? 1 : 0);
                for (int hCnt = 0; hCnt < hsr; hCnt++)
                    dt.Rows.RemoveAt(0);

                tsr = tailSkipRows;
                for (; tsr > 0; tsr--)
                    dt.Rows.RemoveAt(dt.Rows.Count - 1);

                // Old CSV Approach

                //FileInfo fInf = new FileInfo(sourceNameValue);
                //string connString = "Provider=Microsoft.Jet.OLEDB.4.0;"
                //                    + "Data Source=\"" + fInf.DirectoryName + "\\\";"
                //                    + "Extended Properties=\"text;HDR=" + (header_present && headSkipRows == 0 ? "Yes" : "No") + ";FMT=Delimited\"";

                //string cmdString = string.Format("SELECT * FROM {0}", fInf.Name);
                //try
                //{
                //    OleDbDataAdapter dataAdapter = new OleDbDataAdapter(cmdString, connString);
                //    dataAdapter.Fill(dt);
                //}
                //catch (Exception ex)
                //{
                //    DataLoaderException DLex = new DataLoaderException(ex.Message, this);
                //    throw DLex;
                //}

                return dt;
            }
            catch (DataLoaderException DLEx)
            {
                throw DLEx;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Reads data to array
        /// </summary>
        protected void ReadtoArray()
        {
            txtRdr = System.IO.File.OpenText(sourceNameValue);
            Data = new List<List<string>>();
            string[] adelim = new string[] { delim, "," };
            List<string> line;
            string[] lineArr;
            string Line;
            if (headSkipRows > 0)
            {
                for (int hsr = headSkipRows; hsr > 0; hsr--)
                {
                    txtRdr.ReadLine();
                }
            }
            if (header_present)
            {
                Line = txtRdr.ReadLine();
                lineArr = Line.Split(adelim, StringSplitOptions.RemoveEmptyEntries);
                Header = new List<string>();
                Header.AddRange(lineArr.Select(t => (TableName == null ? "" : TableName + "_") + t).ToArray());
            }

            while ((Line = txtRdr.ReadLine()) != null)
            {
                lineArr = Line.Split(adelim, (merge_delim ? StringSplitOptions.RemoveEmptyEntries : StringSplitOptions.None));
                line = new List<string>();
                line.AddRange(lineArr);
                Data.Add(line);
            }

            if (!header_present)
            {
                Header = new List<string>();
                for (int cCnt = 0; cCnt < Data[0].Count; cCnt++)
                {
                    Header.Add((TableName == null ? "" : TableName + "_") + "Column" + cCnt.ToString());
                }
            }
            txtRdr.Close();
        }

        #endregion

        public override string ToString()
        {
            return ("CSV File: " + sourceNameValue);
        }

        public override List<string> getDataSchema()
        {
            DataTable dtTab = new DataTable();

            dtTab = getDataTable();
            
            
            IEnumerable<string> ColumnNames = from DataColumn d in dtTab.Columns
                                              select d.ColumnName;

            return ColumnNames.ToList();
        }
    }
}


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using System.Data.SqlClient;
//using Microsoft.ApplicationBlocks.Data;
using System.Data;
using System.IO;
using Excel = Microsoft.Office.Interop.Excel;

namespace FI_DataStage
{
    [Serializable]
    public class ExcelDataSource:DataSourceClass 
    {
        // declarations
        public static string sConStr = "";
        private string sourceNameValue;
        private string sheetName;
        private string sourceRange;
        private string sourceType;
        private string sourceName;
        private bool header_present = true;
        private bool dynamicRow_Present = true;
        private bool dynamicCol_Present = true;
        private int tailSkipRows;
        private int headSkipRows;

        /// <summary>
        /// .ctor
        /// </summary>
        public ExcelDataSource()
        {
            sourceNameValue = "";

            sheetName = "";

            sourceRange = "";
        } 

        public ExcelDataSource(string sFilePath, string sSheetName, string range, bool HeaderPresent)
        {
            sourceNameValue = sFilePath;

            sheetName = sSheetName;

            sourceRange = range;

            header_present = HeaderPresent;
        }

        public ExcelDataSource(string sFilePath, string sSheetName, string range, bool HeaderPresent, bool dynamicRow, bool dynamicCol, int headSkip, int tailSkip)
        {
            sourceNameValue = sFilePath;

            sheetName = sSheetName;

            sourceRange = range;

            header_present = HeaderPresent;

            dynamicRow_Present = dynamicRow;

            dynamicCol_Present = dynamicCol;

            headSkipRows = headSkip;

            tailSkipRows = tailSkip;
        } 

        #region IDataSource Members

        public override string TableName
        {
            get;
            set;
        }
        public override List<IDType> ID
        {
            get;
            set;
        }

        public override string SourceSpecification
        {
            get;
            set;
        }

        public override bool TreatLeadingBlankAsData
        {
            get;
            set;
        }

        public override string ReplaceLeadingBlank
        {
            get;
            set;
        }

        public string SourceName
        {
            get
            {
                return sourceName;
            }
            set
            {
                sourceName= value;
            }
        }

        public override string SourceNameValue
        {
            get
            {
                return sourceNameValue;
            }
            set
            {
                sourceNameValue = value;
            }
        }

        public override string SheetName
        {
            get
            {
                return sheetName;
            }
            set
            {
                sheetName = value;
            }
        }

        public override string SourceType
        {
            get
            {
                return sourceType;
            }
            set
            {
                sourceType = value;
            }
        }

        public override int TailSkipRows
        {
            get
            {
                return tailSkipRows;
            }
            set
            {
                tailSkipRows = value;
            }
        }

        public override int HeadSkipRows
        {
            get
            {
                return headSkipRows;
            }
            set
            {
                headSkipRows = value;
            }
        }

        public string TextSource
        {
            get;
            set;
        }

        public override string Delim
        {
            get;
            set;
        }

        public override bool Header_Present
        {
            get
            {
                return header_present;
            }
            set
            {
                header_present = value;
            }
        }

        public override bool Merge_Delim
        {
            get;
            set;
        }

        public string SourceRange
        {
            get
            {
                return sourceRange;
            }
            set
            {
                value = sourceRange;
            }
        }

        public bool DynamicRow_Present
        {
            get
            {
                return dynamicRow_Present;
            }
            set
            {
                value = dynamicRow_Present;
            }
        }

        public bool DynamicCol_Present
        {
            get
            {
                return dynamicCol_Present;
            }
            set
            {
                value = dynamicCol_Present;
            }
        }

        /// <summary>
        /// Gets data table from source file
        /// </summary>
        /// <returns>Data table</returns>
        public override DataTable getDataTable()
        {
            FileInfo fInf = new FileInfo(sourceNameValue);

            string sFolderName = fInf.DirectoryName;

            string sFileName = fInf.Name;

            return importExcel(sFolderName, sFileName, sheetName);
        }

        public override List<string> getDataSchema()
        {
            DataTable dtTab = new DataTable();

            dtTab = getDataTable();

            IEnumerable<string> ColumnNames = from DataColumn d in dtTab.Columns
                                              select d.ColumnName;

            return ColumnNames.ToList();
        }

        #endregion

        /// <summary>
        /// Import Excel file into the sql server table
        /// </summary>
        /// <param name="sFolderName">Directory path containing xls file to be imported</param>
        /// <param name="sFileName">Excel file name to be imported</param>
        /// <param name="sSheetName">Sheet name to be imported</param>
        /// <param name="sTableName">Sql server table name</param>
        /// <param name="bTruncateTable">Truncate destination table before loading data? Boolean value</param>
        public DataTable importExcel(string sFolderName, string sFileName, string sSheetName)
        {
            try
            {
                object[][] values={};
                int L1, L2;
                DataTable dt = new DataTable();
                Excel.Application  xlApp = new Excel.Application();
                Excel.Workbook xlWb;
                Excel.Worksheet xlWs;
                xlWb = xlApp.Workbooks.Add(sourceNameValue);
                xlWs= (Excel.Worksheet) xlWb.Worksheets[1];

                Excel.Range rng;
                if ((dynamicCol_Present == false) && (dynamicRow_Present == false))
                {
                   rng = xlWs.get_Range(sourceRange );
                }
                 else
                {
                    Excel.Range last = xlWs.Cells.SpecialCells(Excel.XlCellType.xlCellTypeLastCell, Type.Missing);
                    rng = xlWs.get_Range("A5", last);
                }

                L1 = ((object[,])rng.Cells.Value).GetLength(0);
                    L2 = ((object[,])rng.Cells.Value).GetLength(1);
                    Array.Resize<object[]>(ref values, L1);
                    int iCnt = 0;
                    foreach (object c in (object[,])rng.Cells.Value)
                    {
                        Array.Resize<object>(ref values[iCnt / L2], L2);
                        values[iCnt / L2][iCnt % L2] = c;
                        iCnt++;
                    }

                    if (Header_Present)
                    {
                        for (long i = 0; i < L2; i++)
                        {
                            dt.Columns.Add((TableName!=null?TableName + "_":"") +  values[0][i].ToString());
                        }
                    }
                    else
                    {
                        for (long i = 0; i < L2; i++)
                        {
                            dt.Columns.Add((TableName != null ? TableName + "_" : "") + "Column" + i.ToString());
                        }
                    }

                    for (long i = (Header_Present ? 1 : 0); i < L1; i++)
                    {
                        dt.Rows.Add(values[i]);
                    }

                    int hsr;
                    int tsr;
                    //hsr = HeadSkipRows;
                    //for (int hCnt = 0; hCnt < hsr; hCnt++)
                    //    dt.Rows.RemoveAt(0);

                    tsr = TailSkipRows;
                    for (; tsr > 0; tsr--)
                        dt.Rows.RemoveAt(dt.Rows.Count - 1);

                    foreach (DataRow row in dt.Rows)
                    {
                        foreach (var item in row.ItemArray.ToString())
                        {
                            item.ToString().TrimEnd();
                        }
                    }

                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public override string ToString()
        {
            return ("Excel File: " + sourceNameValue  + " ....... Sheet:" + sheetName + " ....... Range:" + sourceRange );
        }
    }
}

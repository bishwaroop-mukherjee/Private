﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;
using System.Data;
using System.IO;

namespace FI_DataStage
{
    public class AccessDataSource : IDataSource
    {
        string sConStr = "";
        private string sourceName;
        private string srcTable;
        public AccessDataSource()
        {
            sourceName = "";
        }

        public AccessDataSource(string sFilePath)
        {
            sourceName = sFilePath;
        }
         
        #region IDataSource Members

        public System.Data.DataTable getDataTable()
        {
            string sSourceTable = "GFI_industries";

            FileInfo fInf = new FileInfo(sourceName);

            string sFolderName = fInf.DirectoryName;

            string sFileName = fInf.Name;

            return importAccess(sFolderName, sFileName, sSourceTable);
        }

        private DataTable importAccess(string sFolderName, string sFileName, string sSourceTable)
        {
            OleDbConnection oleCon;
            string sAccessConString = "";

            sAccessConString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + sFolderName + "\\" + sFileName;
                
            string sSql = "select * from "+ sSourceTable;

            try
            {
                oleCon = new OleDbConnection(sAccessConString);
                oleCon.Open();

                OleDbCommand cmd = new OleDbCommand(sSql,oleCon);
                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);

                oleCon.Close();
                oleCon.Dispose();
                da.Dispose();
                cmd.Dispose();
                return ds.Tables[0];
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string SourceName
        {
            get
            {
                return sourceName;
            }
            set
            {
                sourceName = value;
            }
        }

        public string SourceType
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        #endregion

        public override string ToString()
        {
            return ("Access File: " + sourceName + " ....... Table Name:" + srcTable);
        }
    }
}

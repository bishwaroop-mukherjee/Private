﻿using System;
using System.Runtime.Serialization;
namespace FI_DataStage
{
    public abstract class ComplexTempType
    {
        [DataMember]
        public Object ID
        {
            get;
            set;
        }
        [DataMember]
        public Type DataType
        {
            get;
            set;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FI_DataStage;
using System.ServiceModel;
using System.ServiceModel.Web;
namespace FI_DataStage
{
    [ServiceBehavior(IncludeExceptionDetailInFaults=true)]
    public partial class DataSourceFactory : FI_DataStage.DataSources.IDataSourceFactory
    {
        
        public string TableName;
        public String SourceType="XXX";
        public List<ComplexTempType> ID;
        public String SourceNameValue;
        public string SheetName;
        public int TailSkipRows;
        public int HeadSkipRows;
        public string Delim;
        public bool Header_Present;
        public bool Merge_Delim;
        public string Range;
        public string InputType;
        public IDataSource InpDLI;
        public string SourceSpecification;
        bool TreatLeadingBlankAsData;
        string ReplaceLeadingBlank;
        string UnderlyingDS;
        
        public DataSourceFactory (){}
        public DataSourceFactory(string tableName, String sourceType, string sourcePath, string sheetName, 
                                 string range, int tailSkipRows, int headSkipRows, string delim,
                                 bool mergeDelim, bool headerPresent, List<ComplexTempType> IDs, string underlyingDS)
        {
            TableName = tableName;
            SourceType = sourceType;
            SourceNameValue = sourcePath;
            SheetName = sheetName;
            TailSkipRows = tailSkipRows;
            HeadSkipRows = headSkipRows;
            Merge_Delim = mergeDelim;
            Header_Present = headerPresent;
            Delim = delim;
            ID = IDs;
            Range = range;
            UnderlyingDS = (underlyingDS ?? ""); 
        }
        public DataSourceFactory(string tableName, String sourceType, string sourcePath, string sheetName, 
                                 string range, int tailSkipRows, int headSkipRows, string delim,
                                 bool mergeDelim, bool headerPresent, List<ComplexTempType> IDs, string inpType, IDataSource inpDLI, string underlyingDS)
        {
            TableName = tableName;
            SourceType = sourceType;
            SourceNameValue = sourcePath;
            SheetName = sheetName;
            TailSkipRows = tailSkipRows;
            HeadSkipRows = headSkipRows;
            Merge_Delim = mergeDelim;
            Header_Present = headerPresent;
            Delim = delim;
            ID = IDs;
            Range = range;
            InputType = inpType;
            InpDLI = inpDLI;
            UnderlyingDS = underlyingDS ?? ""; 
        }

        public DataSourceFactory(string tableName, String sourceType, string sourcePath, string sheetName,
                                string range, int tailSkipRows, int headSkipRows, string delim,
                                bool mergeDelim, bool headerPresent, List<ComplexTempType> IDs, string inpType, IDataSource inpDLI, string srcSpec, string underlyingDS)
        {
            TableName = tableName;
            SourceType = sourceType;
            SourceNameValue = sourcePath;
            SheetName = sheetName;
            TailSkipRows = tailSkipRows;
            HeadSkipRows = headSkipRows;
            Merge_Delim = mergeDelim;
            Header_Present = headerPresent;
            Delim = delim;
            ID = IDs;
            Range = range;
            InputType = inpType;
            InpDLI = inpDLI;
            SourceSpecification = srcSpec;
            UnderlyingDS = underlyingDS ?? ""; 
        }

        public DataSourceFactory(string tableName, String sourceType, string sourcePath, string sheetName,
                               string range, int tailSkipRows, int headSkipRows, string delim,
                               bool mergeDelim, bool headerPresent, List<ComplexTempType> IDs, string inpType, IDataSource inpDLI,
                               string srcSpec, bool treatLeadingBlankAsData, string replaceLeadingBlank, string underlyingDS)
        {
            TableName = tableName;
            SourceType = sourceType;
            SourceNameValue = sourcePath;
            SheetName = sheetName;
            TailSkipRows = tailSkipRows;
            HeadSkipRows = headSkipRows;
            Merge_Delim = mergeDelim;
            Header_Present = headerPresent;
            Delim = delim;
            ID = IDs;
            Range = range;
            InputType = inpType;
            InpDLI = inpDLI;
            SourceSpecification = srcSpec;
            TreatLeadingBlankAsData = treatLeadingBlankAsData;
            ReplaceLeadingBlank = replaceLeadingBlank;
            UnderlyingDS = underlyingDS ?? ""; 
        }

        public  DataSourceClass  GetDataSourceInstance()
        {
            DataSourceClass d=null;
            if (InputType == null)
            {
                if (SourceType == "TEXT")
                {
                    d = new FI_DataStage.TextDataSource(SourceNameValue, Delim, Header_Present, Merge_Delim, TailSkipRows, HeadSkipRows, TreatLeadingBlankAsData, ReplaceLeadingBlank );
                }
                else if (SourceType == "FWTEXT")
                {
                    d = new FI_DataStage.FixedWidthTextDataSource(SourceNameValue, Delim, Header_Present, Merge_Delim, TailSkipRows, HeadSkipRows, TreatLeadingBlankAsData, ReplaceLeadingBlank);
                }
                else if (SourceType == "CSV")
                {
                    d = new FI_DataStage.CSVDataSource(SourceNameValue, Header_Present,Merge_Delim, TailSkipRows, HeadSkipRows);
                }
                else if (SourceType == "XML")
                {
                    d = new FI_DataStage.XMLDataSource(SourceNameValue);
                }
                else if (SourceType == "EXCEL")
                {
                    d = new FI_DataStage.ExcelDataSource(SourceNameValue, SheetName, Range, Header_Present);
                }
                else if (SourceType == "ACCESS")
                {
                    d = new FI_DataStage.AccessDataSource(SourceNameValue, SourceSpecification);
                }
                else if (SourceType == "RDBMS")
                {
                    d = new FI_DataStage.RDBMSDataSource(SourceNameValue, SourceSpecification);
                }
                else if (SourceType == "XMLDIRECT")
                {
                    d = new FI_DataStage.XMLDirectDataSource(SourceNameValue);//, SourceSpecification);
                }
                else
                {
                    throw new DataLoaderException("Source Type unidentified", null);
                }
            }
            else
            {
                ProgrammableDataSource pd;
                if (SourceType == "BBG")
                {
                    pd = new FI_DataStage.BloombergDataSource();
                    pd.LoadInputs(InpDLI);
                    d = pd;
                }
                if (SourceType == "BATCH")
                {
                    pd = new FI_DataStage.BatchDataSource()
                        {
                            Delim = this.Delim,
                            Header_Present = this.Header_Present,
                            HeadSkipRows = this.HeadSkipRows,
                            ID = this.ID.Cast<IDType>().ToList(),
                            Merge_Delim = this.Merge_Delim,
                            ReplaceLeadingBlank = this.ReplaceLeadingBlank,
                            SourceNameValue = this.SourceNameValue,
                            SheetName = this.SheetName,
                            SourceType = this.SourceType,
                            TableName = this.TableName,
                            TreatLeadingBlankAsData = this.TreatLeadingBlankAsData,
                            TailSkipRows = this.TailSkipRows,
                            UnderlyingDS = this.UnderlyingDS,
                            SourceSpecification = this.SourceSpecification
                        };
                    
                    pd.LoadInputs(InpDLI);
                    d = pd;
                }
            }
            d.ID = ID != null ? new List<IDType>(ID.Cast<IDType>().ToList()) : null;
            d.TableName = TableName;

            d.UnderlyingDS = UnderlyingDS;

            return d;
        }
    }
}

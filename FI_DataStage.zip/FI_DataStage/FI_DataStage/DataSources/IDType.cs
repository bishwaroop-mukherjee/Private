﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using System.Runtime.Serialization;
using System.Security.Permissions;
namespace FI_DataStage
{
    public class IDType: FI_DataStage.ComplexTempType //,ISerializable
    {
        Object _id;
        Type _type;

        public Object ID
        {
            get { return _id; }
            set { _id=value; }
        }

        [XmlIgnore ()]
        public Type DataType
        {
            get { return _type; }
            set { _type=value; }
        }

        public IDType()
        {
            DataType = typeof(System.String);
        }
        protected IDType(SerializationInfo info, StreamingContext context)
        {
            if (info == null)
                throw new System.ArgumentNullException("info");
            ID = (string)info.GetValue("ColName", typeof(string));
            DataType = Type.GetType((string)info.GetValue("IDType", typeof(int)));
        }
        public IDType(Object oID, string TypeName)
        {
            ID = oID;
            DataType = Type.GetType(TypeName);
        }

        public IDType(Object oID, Type oType)
        {
            ID = oID;
            DataType = oType;
        }

        [SecurityPermission(SecurityAction.LinkDemand,Flags = SecurityPermissionFlag.SerializationFormatter)]
        public virtual void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            if (info == null)
                throw new System.ArgumentNullException("info");
            info.AddValue("ColName", ID.ToString());
            info.AddValue("IDType", DataType.FullName );
        }
    }
}

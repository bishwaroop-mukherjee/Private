﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Xml.Serialization;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using ETLServiceLibrary;
namespace FI_DataStage
{
    [Serializable ]
    [XmlInclude(typeof(TextDataSource))]
    [XmlInclude(typeof(CSVDataSource ))]
    [XmlInclude(typeof(AccessDataSource))]
    [XmlInclude(typeof(ExcelDataSource))]
    [XmlInclude(typeof(TempDataSource))]
    [XmlInclude(typeof(XMLDataSource))]
    public abstract class DataSourceClass : IDataSource
    {
        protected string _underlyingDSType;
        public DataSourceClass()
        { 
        }
        
        public abstract DataTable getDataTable();

        public abstract List<string> getDataSchema();

         
        public abstract string TableName
        {
            get;
            set;
        }

         
        public abstract string SourceSpecification
        {
            get;
            set;
        }

         
        public abstract String SourceType
        {
            get;
            set;
        }


        public abstract bool TreatLeadingBlankAsData
        {
            get;
            set;
        }

         
        public abstract string ReplaceLeadingBlank
        {
            get;
            set;
        }

         
        public abstract List<IDType> ID
        {
            get;
            set;
        }

         
        public abstract String SourceNameValue
        {
            get;

            set;
        }

         
        public abstract string SheetName
        {
            get;
            set;
        }

         
        public abstract int TailSkipRows
        {
            get;
            set;
        }

         
        public abstract int HeadSkipRows
        {
            get;
            set;
        }
         
        public abstract string Delim
        {
            get;
            set;
        }

         
        public abstract bool Header_Present
        {
            get;
            set;
        }

         
        public abstract bool Merge_Delim
        {
            get;
            set;
        }

         
        public virtual string UnderlyingDS
        {
            get { return _underlyingDSType; }
            set { _underlyingDSType = value; }
        }
    }

}

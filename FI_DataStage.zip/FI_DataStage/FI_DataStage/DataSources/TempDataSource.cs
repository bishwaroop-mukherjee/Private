﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace FI_DataStage
{
    public class TempDataSource: DataSourceClass 
    {
        DataTable dtTemp;
        public override DataTable getDataTable()
        {
            return dtTemp;
        }

        public TempDataSource() { }

        public TempDataSource(DataTable dt, string name)
        {
            dtTemp = dt;
            TableName = name;
        }

        public override List<string> getDataSchema()
        {
            IEnumerable<string> ColumnNames = from DataColumn d in dtTemp.Columns
                                              select d.ColumnName;


            return ColumnNames.ToList();
        }

        public override string TableName
        {
            get;
            set;
        }

        public override bool TreatLeadingBlankAsData
        {
            get;
            set;
        }

        public override string ReplaceLeadingBlank
        {
            get;
            set;
        }

        public override string SourceSpecification
        {
            get;
            set;
        }

        public override String SourceType
        {
            get;
            set;
        }

        public override List<IDType> ID
        {
            get;
            set;
        }

        public override String SourceNameValue
        {
            get;

            set;
        }

        public override string SheetName
        {
            get;
            set;
        }

        public override int TailSkipRows
        {
            get;
            set;
        }

        public override int HeadSkipRows
        {
            get;
            set;
        }

        public override string Delim
        {
            get;
            set;
        }

        public override bool Header_Present
        {
            get;
            set;
        }

        public override bool Merge_Delim
        {
            get;
            set;
        }

    }
}

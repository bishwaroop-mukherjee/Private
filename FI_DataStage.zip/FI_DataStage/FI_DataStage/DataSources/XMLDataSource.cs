﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Sql;
using Microsoft.ApplicationBlocks.Data;
using System.Data.SqlClient;
using System.Xml;
namespace FI_DataStage
{
    public class XMLDataSource:IDataSource
    {

        string sourceName;

        #region Constructors

        public XMLDataSource()
        {
            SourceName = "";
        }

        public XMLDataSource(string fileName)
        {
            sourceName = fileName;
        }

        #endregion

        #region IDataSource Members

        public System.Data.DataTable getDataTable()
        {
            DataTable dt = new DataTable();
            ImportGenericXML(sourceName, ref dt);
            //loadGainLossFromXML(ref dt);
            return dt;
        }

        public string SourceName
        {
            get
            {
                return sourceName;
            }
            set
            {
                sourceName = value;
            }
        }

        public string SourceType
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        #endregion

        /// <summary>
        /// Declarations
        /// </summary>
        public static string sConStr = "";

        #region Public Methods


        /// <summary>
        /// Load destination xml file into a table on sql server. by vishalm on 03-01-2012
        /// </summary>
        /// <param name="sFilePath">file to be imported</param>
        /// <param name="sTableName">destination table name</param>
        /// <param name="bTruncateTable">whether to truncate table before import</param>
        public void ImportGenericXML(string sFilePath, ref DataTable dt)
        {
            try
            {
                //XmlDocument xld = xld = new XmlDocument();
                //System.Data.DataTable[] dtTables = new System.Data.DataTable[0];
                //xld.Load(sFilePath);
              
                //XmlNode nd;
                //nd = xld.CloneNode(true);
                //GetDeepestNode(nd.ChildNodes[1], ref dtTables);
                //System.Data.DataTable dt = dtTables[0];
                //dTable = dt;

                XmlDocument xld = xld = new XmlDocument();
                System.Data.DataTable[] dtTables = new System.Data.DataTable[0];
                xld.Load(sFilePath);

                XmlNode nd;
                nd = xld.CloneNode(true);
                GetDeepestNodeTable(nd.ChildNodes[1], ref dtTables);
                dt = dtTables[0];
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
        }

        public void GetDeepestNodeTable(XmlNode node, ref System.Data.DataTable[] tbls)
        {
            if (!node.FirstChild.FirstChild.HasChildNodes)
            {
                DataSet dt = new DataSet();
                Array.Resize<System.Data.DataTable>(ref tbls, tbls.Length + 1);
                dt.Clear();
                dt.Relations.Clear();
                XmlNode nd = node.ParentNode;
                //XmlAttribute xla = nd.Attributes[0];
                nd.Attributes.RemoveAll();
                System.IO.StringReader str = new System.IO.StringReader(nd.OuterXml);
                //XmlReader xlr = XmlReader.Create(str.
                dt.ReadXml(str);
                dt.Tables[0].TableName = nd.Name;
                tbls[tbls.Length - 1] = dt.Tables[0];
            }
            else
            {
                foreach (XmlNode nd in node.ChildNodes)
                {
                    GetDeepestNodeTable(nd, ref tbls);
                }

            }
        }


        #endregion
        public override string ToString()
        {
            return ("XML File: " + SourceName );
        }
    }
}

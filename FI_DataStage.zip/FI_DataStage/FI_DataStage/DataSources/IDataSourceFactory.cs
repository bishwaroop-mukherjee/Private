﻿using System;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Runtime.Serialization;
using ETLServiceLibrary;

namespace FI_DataStage.DataSources
{
    public interface IDataSourceFactory
    {
        
        global::FI_DataStage.DataSourceClass GetDataSourceInstance();
    }
}

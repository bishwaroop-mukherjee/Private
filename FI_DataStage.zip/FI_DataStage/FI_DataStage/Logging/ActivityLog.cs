﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using System.Configuration;
namespace FI_DataStage.Logging
{
    public class ActivityLog
    {
         

        public static void SendToLog(object Sender, string Message)
        {
            //Sender.GetType()
            string sFileName;
            log4net.Appender.FileAppender dsLog;
            //System.IO.FileStream fTemp;
            sFileName = System.Configuration.ConfigurationManager.ConnectionStrings["LogPath"].ConnectionString;
            if (!System.IO.File.Exists(sFileName)) System.IO.File.Create(sFileName).Close();

            dsLog = new log4net.Appender.FileAppender();
            dsLog.File = sFileName;
            
            dsLog.Layout = new log4net.Layout.SimpleLayout();
            //dsLog.
            dsLog.AppendToFile = true;
            dsLog.ActivateOptions();
            
            log4net.Core.LoggingEventData lgData= new log4net.Core.LoggingEventData();
            lgData.LoggerName = "FI Data Stage Loader:";
            lgData.TimeStamp = DateTime.Now;
            lgData.Message=Sender.ToString()+ ":"+ Message;
            log4net.Core.LoggingEvent lgEvent = new log4net.Core.LoggingEvent(lgData);
            dsLog.LockingModel.AcquireLock();
            dsLog.DoAppend(lgEvent);
            dsLog.LockingModel.ReleaseLock();
            //dsLog.DoAppend(new log4net.Core.LoggingEvent(lgData));
            //dsLog.Writer.Close();
            dsLog.Close();

        }
        
    }
}

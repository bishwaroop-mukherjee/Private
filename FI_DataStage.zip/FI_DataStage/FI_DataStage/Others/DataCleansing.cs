﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Data;
namespace FI_DataStage
{
    /// <summary>
    /// Represents data cleaning mechanism.
    /// </summary>
    public class DataCleansing
    {
        DataSet dtData;

        /// <summary>
        /// Cleans raw data from source datatable
        /// </summary>
        /// <param name="dtDataSource">source datatable</param>
        /// <param name="dtRefData"></param>
        /// <returns></returns>
        public System.Data.DataTable cleanseData( DataTable dtDataSource, DataTable dtRefData, string IDColName)
        {
            dtData = new DataSet();
            var SelectedRows = (from a in dtDataSource.AsEnumerable()
                                select a); 
            if (IDColName != null)
            {
                SelectedRows = (from a in dtDataSource.AsEnumerable()
                                    where a.Field<Object>(IDColName) != null
                                    select a);
            }
            
            dtData.Merge(SelectedRows.ToArray());
            cleanNULLs();
            return cleanDuplicates(dtRefData,IDColName  );
            //return dtData.Tables[0];
        }

        /// <summary>
        /// Clears all null values from the datatable.
        /// </summary>
        private void cleanNULLs()
        {
            DataTable dtTemp = dtData.Tables[0].Clone();

            foreach (DataRow row in dtData.Tables[0].Rows)
            {
                int iCnt;
                for (iCnt = 0;iCnt<row.ItemArray.Length;iCnt++)
                {
                    if (!DBNull.Value.Equals(row.ItemArray[iCnt]) )
                    {
                        if (row.ItemArray[iCnt].ToString() == "NULL" || row.ItemArray[iCnt].ToString() == "NA" || row.ItemArray[iCnt].ToString() == "N/A" || row.ItemArray[iCnt].ToString().Trim() == "")
                        {
                            row.SetField<Object>(iCnt, DBNull.Value );
                            dtTemp.Columns[iCnt].MaxLength = -1;
                            dtTemp.Columns[iCnt].DataType = typeof(object);

                        }
                    }
                }
            }
            dtData.Tables[0].AsEnumerable().ToList().ForEach(r => dtTemp.ImportRow(r));
            dtData.Tables.RemoveAt(0);
            dtData.Tables.Add(dtTemp);
        }

        private DataTable  cleanDuplicates(DataTable ReferenceTable, string IDColName)
        {
            IEqualityComparer<DataRow> e;
            IEnumerable<DataRow> R;
            if(IDColName == null || IDColName=="")
                e= new DataRowEqualityComp(true );
            else
                e= new DataRowEqualityComp(IDColName);
            IEnumerable<DataRow> R1 = (from DataRow dr in dtData.Tables[0].AsEnumerable()
                                       select dr);
            IEnumerable<DataRow> R2 = (from DataRow dr1 in ReferenceTable.AsEnumerable()
                                       select dr1);
            if(IDColName == null||IDColName=="")
                R= R1.Union<DataRow>(R2);
            else
                R = R1.Union<DataRow>(R2, e);
            //ds = dtData.GetChanges();
            //dtData.Tables[0]
            DataTable dt = new DataTable();
            dt = ReferenceTable.Clone();
            for(int iCCnt = 0;iCCnt<dt.Columns.Count;iCCnt ++)
            {
                try
                {
                    dt.Columns[iCCnt].ColumnName = ReferenceTable.Columns[iCCnt].ColumnName;
                    if(dt.Columns[iCCnt].DataType == typeof(string))
                        dt.Columns[iCCnt].MaxLength = dtData.Tables[0].Columns[iCCnt].MaxLength;

                    dt.Columns[iCCnt].DataType = dtData.Tables[0].Columns[iCCnt].DataType;
                }
                catch (Exception ex)
                {
                    ex = ex;
                }
            }
            //R.ToList().ForEach(r => dt.ImportRow(r));
            foreach (DataRow dr in R)
            {
                try
                {
                    dt.Rows.Add(dr.ItemArray);
                }
                catch (Exception ex)
                {
                    ex = ex;
                }
            }
            return dt;
        }
    }
    public class DataRowEqualityComp : EqualityComparer<DataRow>
    {
        string ID;
        int IDN;
        bool Pass;
        public DataRowEqualityComp()
        {
            ID = null;
            IDN = -1;
            Pass = false;
        }
        public DataRowEqualityComp(bool pass)
        {
            ID = null;
            IDN = -1;
            Pass = pass;
        }
        public DataRowEqualityComp(string idColName)
        {
            ID = idColName;
            IDN = -1;
        }
        public DataRowEqualityComp(int idColName)
        {
            ID = null;
            IDN = idColName;
        }
        public override bool Equals(DataRow x, DataRow y)
        {
            if (ID != null )
            {
                if (x.Field<Object>(ID) == null && y.Field<Object>(ID) == null)
                    return true;
                if (x.Field<Object>(ID) == null || y.Field<Object>(ID) == null)
                    return false;

                return (x.Field<Object>(ID).ToString() == y.Field<Object>(ID).ToString());
            }
            else if (IDN >= 0)
            {
                if (x.Field<Object>(IDN) == null && y.Field<Object>(IDN) == null)
                    return true;
                if (x.Field<Object>(IDN) == null || y.Field<Object>(IDN) == null)
                    return false ;
                return (x.Field<Object>(IDN).ToString() == y.Field<Object>(IDN).ToString());
            }
            else
            {
                if (!Pass)
                    return CompareWholeRow(x, y);
                else
                    return false;
            }
        }
        private bool CompareWholeRow(DataRow x, DataRow y)
        {
            if (x.ItemArray.Length != y.ItemArray.Length)
                return false;

            for (int i=0;i<x.ItemArray.Length ;i++)
            {
                if (x.ItemArray[i] != y.ItemArray[i])
                    return false;
            }
            return true;
        }
        public override int GetHashCode(DataRow obj)
        {
            return 0;
        }
    }
}

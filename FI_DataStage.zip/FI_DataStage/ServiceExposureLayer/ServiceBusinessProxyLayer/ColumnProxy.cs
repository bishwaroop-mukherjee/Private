﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace ServiceExposureLayer.ServiceBusinessProxyLayer
{
    [DataContract]
    public class ColumnProxy
    {
        string columnName;
        [DataMember(IsRequired=true)]
        public string ColumnName
        {
            get { return columnName; }
            set { columnName = value; }
        }
        string colExpr;
        [DataMember]
        public string ColExpr
        {
            get { return colExpr; }
            set { colExpr = value; }
        }
        string mapCol;
        [DataMember]
        public string MapCol
        {
            get { return mapCol; }
            set { mapCol = value; }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using FI_DataTranformations.Transformations;

namespace ServiceExposureLayer.ServiceBusinessProxyLayer
{
    [DataContract]
    public class TransformationProxy
    {
        private ParameterProxyBase _parameters;
        [DataMember]
        public ParameterProxyBase Parameters
        {
            get { return _parameters; }
            set { _parameters = value; }
        }

        private string _name;
        [DataMember]
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        private string _category;
        [DataMember]
        public string Category
        {
            get { return _category; }
            set { _category = value; }
        }
        //public FI_DataTranformations.Transformations.AggregateParameter//
        public FI_DataTranformations.Transformations.Transformation GetTransformationObject()
        {
            Random r = new Random();
            _name = _name ?? _category + Convert.ToString( r.Next(100));
            if (_category == null) return null;
            TransformationFactory transfact = new TransformationFactory();
            return transfact.GetTransformationInstance(_category, _parameters.GetParamObject());
            //return new FI_DataTranformations.Transformations.Transformation();
        }
    }
}

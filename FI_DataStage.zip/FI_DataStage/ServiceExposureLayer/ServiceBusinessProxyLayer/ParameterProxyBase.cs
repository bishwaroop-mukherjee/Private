﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace ServiceExposureLayer.ServiceBusinessProxyLayer
{
    [DataContract]
    public class ParameterProxyBase
    {
        private string _Command;
        [DataMember]
        public virtual string Command
        {
            get
            {
                return _Command;
            }
            set
            {
                _Command = value;
            }
        }

        private List<FI_DataTranformations.Column> _OnColumns;
        [DataMember]
        public virtual List<FI_DataTranformations.Column> OnColumns
        {
            get
            {
                return _OnColumns;
            }
            set
            {
                _OnColumns = value;
            }
        }

        private List<FI_DataTranformations.Column> _RetColumns;
        [DataMember]
        public virtual List<FI_DataTranformations.Column> RetColumns
        {
            get
            {
                return _RetColumns;
            }
            set
            {
                _RetColumns = value;
            }
        }

        public virtual FI_DataTranformations.Transformations.Parameter GetParamObject()
        {
            FI_DataTranformations.Transformations.Parameter p;
            if (_Command.Contains("GROUP"))
                p = new FI_DataTranformations.Transformations.AggregateParameter() { Command = _Command, OnColumns = _OnColumns, RetColumns = _RetColumns };
            else
                p = new FI_DataTranformations.Transformations.Parameter() { Command = _Command, OnColumns = _OnColumns, RetColumns = _RetColumns };

            return p;
        }

    }
}

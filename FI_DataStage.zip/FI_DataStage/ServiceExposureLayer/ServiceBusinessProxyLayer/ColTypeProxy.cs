﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FI_DataTranformations;
using System.Runtime.Serialization;

namespace ServiceExposureLayer.ServiceBusinessProxyLayer
{
    [DataContract]
    public class ColTypeProxy
    {
        string _colname;
        System.Type _type;

        public ColTypeProxy()
        {
            _colname = null;
            _type = null;
        }
        public ColTypeProxy(string colName, Type colType)
        {
            _colname = colName;
            _type = colType;
        }
        [DataMember]
        public string ColName
        {
            get
            {
                return _colname;
            }
            set
            {
                _colname = value; ;
            }
        }
        [DataMember]
        public string ColumnType
        {
            get
            {
                return _type.FullName;
            }
            set
            {
                _type = Type.GetType(value);
            }
        }

        public ColType GetColType()
        {
            return new ColType(this._colname, this._type);

        }
    }
}

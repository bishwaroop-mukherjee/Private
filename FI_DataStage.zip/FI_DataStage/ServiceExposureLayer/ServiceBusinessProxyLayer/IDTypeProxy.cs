﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace ServiceExposureLayer.ServiceBusinessProxyLayer
{
    [DataContract]
    public class IDTypeProxy
    {
        FI_DataStage.IDType _internalData;

        Object _id;
        Type _type;

        [DataMember]
        public Object ID
        {
            get { return _id; }
            set { _id = value; }
        }

        [DataMember]
        public Type DataType
        {
            get { return _type; }
            set { _type = value; }
        }

        public FI_DataStage.IDType GetIDType()
        {
            _internalData = new FI_DataStage.IDType(_id, _type);
            return _internalData;
        }

    }
}

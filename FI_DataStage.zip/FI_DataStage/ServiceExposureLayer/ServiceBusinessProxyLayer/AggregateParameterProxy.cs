﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using FI_DataTranformations.Transformations;
using FI_DataTranformations;

namespace ServiceExposureLayer.ServiceBusinessProxyLayer
{
    [DataContract]
    public class AggregateParameterProxy:ParameterProxyBase 
    {
        [DataMember]
        public override string Command
        {
            get;
            set;
        }

        [DataMember]
        public override List<Column> OnColumns
        {
            get;
            set;
        }

        [DataMember]
        public override List<Column> RetColumns
        {
            get;
            set;
        }

        public override Parameter GetParamObject()
        {
            return new AggregateParameter() ;
        }
    }
}

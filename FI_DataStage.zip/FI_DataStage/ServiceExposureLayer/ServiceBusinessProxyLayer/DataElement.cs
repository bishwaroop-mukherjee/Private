﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Runtime.Serialization;

namespace ServiceExposureLayer.ServiceBusinessProxyLayer
{
    [DataContract]
    public class DataElement
    {
        private DataTable _data;
        [DataMember]
        public DataTable Data
        {
            get { return _data; }
            set { _data = value;; }
        }
       
        
    }
}

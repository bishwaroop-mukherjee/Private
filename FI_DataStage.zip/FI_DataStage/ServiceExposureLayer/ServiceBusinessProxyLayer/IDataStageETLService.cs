﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.ServiceProcess;
using System.ServiceModel;
using System.ServiceModel.Web;
using ETLServiceLibrary;
using System.Data;
using System.Collections;

namespace ServiceExposureLayer.ServiceBusinessProxyLayer
{
    [ETLPublishService("ServiceInterFace")]
    [ServiceContract]
    public interface IDataStageETLService
    {
        [OperationContract]
        DataTable GetDataFromSource(DataSourceProxy ds);

        [OperationContract]
        List<string> GetDataSchemaFromSource(DataSourceProxy ds);

        [OperationContract]
        DataTable JoinTables(string dseName);

        [OperationContract]
        void AddData(ServiceBusinessProxyLayer.DataSourceEnvelopeProxy dataJoin, string name);

        [OperationContract]
        void AddTransformation(ServiceBusinessProxyLayer.TransformationContainerProxy transwithinput, string name);

        [OperationContract]
        System.Data.DataTable GetTransformationData();

        [OperationContract]
        void AddDataSourcetoEnvelope(DataSourceProxy datasource, string envelopeName, string connecttodatasourcename, IDTypeProxy pid, IDTypeProxy cid, FI_DataTranformations.JoinType jn);

        [OperationContract]
        void AddFirstDataSourcetoEnvelope(DataSourceProxy datasource, string envelopeName);

        [OperationContract]
        IDictionary GetData();

        [OperationContract]
        void AddDestinationColumntoEnvelope(ColumnSetProxy dest, string dsename);

        [OperationContract]
        void AddColTypetoEnvelope(ColTypeSetProxy coltypes, string dsename);

        [OperationContract]
        void ModifyJoin(DataSourceProxy datasource, string envelopeName, string connecttodatasourcename, IDTypeProxy pid, IDTypeProxy cid, FI_DataTranformations.JoinType jn);

        [OperationContract]
        void AddDataSourceSequence(List<DataNode> sequence, string envelopeName);

        [OperationContract]
        List<string> GetTransFormationCategories();

        [OperationContract]
        void AddTransformationCollection(List<TransformationContainerProxy> coll);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FI_DataTranformations;
using System.Runtime.Serialization;

namespace ServiceExposureLayer.ServiceBusinessProxyLayer
{
    [DataContract]
    public class DataNode
    {
        [DataMember]
        public DataSourceProxy DataSource
        {
            get;
            set;
        }
        [DataMember]
        public IDTypeProxy Pid
        {
            get;
            set;
        }
        [DataMember]
        public IDTypeProxy Cid
        {
            get;
            set;
        }
        [DataMember]
        public JoinType jointype
        {
            get;
            set;
        }
    }
}

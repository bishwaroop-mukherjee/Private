﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using FI_DataTranformations;
using FI_DataTranformations.Transformations;

namespace ServiceExposureLayer.ServiceBusinessProxyLayer
{
    [DataContract]
    public class ParameterProxy:ParameterProxyBase
    {
        [DataMember]
        public override string Command
        {
            get;
            set;
        }

        [DataMember]
        public override List<Column> OnColumns
        {
            get;
            set;
        }


       
        public override Parameter GetParamObject()
        {
            return new Parameter();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FI_DataTranformations;
using System.Runtime.Serialization;

namespace ServiceExposureLayer.ServiceBusinessProxyLayer
{
    [DataContract]
    public class ColumnSetProxy
    {
        ColumnSet modelColumnSetObj;

        List<ColumnProxy> columns;
        [DataMember]
        public List<ColumnProxy> Columns
        {
            get { return columns; }
            set { columns = value; }
        }

        public ColumnSetProxy()
        {
            columns = new List<ColumnProxy>();
            modelColumnSetObj = new ColumnSet();
        }

        public void Add(ColumnProxy col)
        {
            Column xCol = new Column() { ColumnName = col.ColumnName, ColumnExpression = col.ColExpr, MappingColumn = col.MapCol };
            modelColumnSetObj.AddNew(xCol);
        }

        public ColumnSet GetColumnSetObject()
        {
            if (modelColumnSetObj == null)
            {
                modelColumnSetObj = new ColumnSet();
                columns.
                    ForEach(c =>
                        {
                            Column col = new Column()
                                              {
                                                  ColumnName = c.ColumnName,
                                                  ColumnExpression = c.ColExpr,
                                                  MappingColumn = c.MapCol
                                              };
                            modelColumnSetObj.Add(c.ColumnName, col);
                        });
            }
            return modelColumnSetObj;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace ServiceExposureLayer.ServiceBusinessProxyLayer
{
    [DataContract]
    public class TransformationContainerProxy
    {
        private FI_DataTranformations.Transformations.TransformationContainer _internalTransformation;

        private TransformationProxy _transActor;
        [DataMember]
        public ServiceExposureLayer.ServiceBusinessProxyLayer.TransformationProxy TransActor
        {
            get { return _transActor; }
            set { _transActor = value; }
        }

        private List<string> inputs;
        [DataMember]
        public List<string> Inputs
        {
            get { return inputs; }
            set { inputs = value; }
        }

        public FI_DataTranformations.Transformations.TransformationContainer GenerateTransformationContainer()
        {
            
            _internalTransformation = new FI_DataTranformations.Transformations.TransformationContainer(
                _transActor.GetTransformationObject(),
                inputs.ToArray()
                );
            return _internalTransformation;
        }
    }
}

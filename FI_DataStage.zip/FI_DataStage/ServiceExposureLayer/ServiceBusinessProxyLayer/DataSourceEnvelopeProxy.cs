﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using FI_DataTranformations;

namespace ServiceExposureLayer.ServiceBusinessProxyLayer
{
    [DataContract]
    public class DataSourceEnvelopeProxy
    {
        DataSourceEnvelope internalDataSourceEnvelope;

        private List<Tuple<DataSourceProxy, JoinSpec>> dataSourceSequence;
        public List<Tuple<DataSourceProxy, JoinSpec>> DataSourceSequence
        {
            get { return dataSourceSequence; }
            set { dataSourceSequence = value; }
        }
        private ColumnSetProxy destination;
        [DataMember]
        public ColumnSetProxy Destination
        {
            get { return destination; }
            set { destination = value; }
        }

        private List<ColTypeProxy> columnTypes;
        [DataMember]
        public List<ColTypeProxy> ColumnTypes
        {
            get { return columnTypes; }
            set { columnTypes = value; }
        }

        public void Add(DataSourceProxy data, string ConnectToName, IDTypeProxy pid, IDTypeProxy cid, JoinType jn)
        {
            if (dataSourceSequence == null)
                dataSourceSequence = new List<Tuple<DataSourceProxy, JoinSpec>>();

            //int ConnectedTo = dataSourceSequence.FindIndex(t => t.Item1.TableName == ConnectToName);
            //if (ConnectedTo < 0) ConnectedTo = int.MaxValue;
            dataSourceSequence.Add(new Tuple<DataSourceProxy, JoinSpec>(data, new JoinSpec() { ConnectedtoIndex = int.MaxValue, PID = pid, CID = cid, JnType = jn }));
            //if (ConnectedTo < int.MaxValue)
            //    dataSourceSequence[ConnectedTo].Item2.ConnectTo(dataSourceSequence.Count - 1, null, null, JoinType.Cross);
        }

        public void ModifyJoin(DataSourceProxy data, string ConnectToName, IDTypeProxy pid, IDTypeProxy cid, JoinType jn)
        {
            int DataIdx = dataSourceSequence.FindIndex(t => t.Item1.TableName == data.TableName);
            if (DataIdx < 0) return;

            int ConnectedTo = dataSourceSequence.FindIndex(t => t.Item1.TableName == ConnectToName);
            if (ConnectedTo < 0) ConnectedTo = int.MaxValue;

            dataSourceSequence[DataIdx].Item2.ConnectedtoIndex = ConnectedTo;
            dataSourceSequence[DataIdx].Item2.PID = pid;
            dataSourceSequence[DataIdx].Item2.CID = cid;
            dataSourceSequence[DataIdx].Item2.JnType = jn;
        }

        //    public DataSourceEnvelope GenerateDSE()
        //    {
        //        internalDataSourceEnvelope = new DataSourceEnvelope();
        //        List<Tuple<DataSourceProxy, JoinSpec>> SortedList = new List<Tuple<DataSourceProxy, JoinSpec>>();
        //        SortedList.AddRange(dataSourceSequence);
        //        SortedList.Sort(new Comparison<Tuple<DataSourceProxy, JoinSpec>>((td1, td2) => td1.Item2.ConnectedtoIndex - td2.Item2.ConnectedtoIndex));
        //        Tuple<DataSourceProxy, JoinSpec> Temp = null;
        //        int AddedCount = 0;
        //        do
        //        {
        //            if (AddedCount == 0)
        //                Temp = SortedList[0];
        //            else
        //                if (Temp.Item2.ConnectedtoIndex < int.MaxValue)
        //                    Temp = dataSourceSequence[Temp.Item2.ConnectedtoIndex];

        //            if (AddedCount == 0)
        //                internalDataSourceEnvelope.Add(Temp.Item1.GetDataSource(), null, null, JoinType.Cross);
        //            else
        //            {
        //                if (Temp.Item2.JnType == JoinType.Cross)
        //                    internalDataSourceEnvelope.Add(Temp.Item1.GetDataSource(), null, null, Temp.Item2.JnType);
        //                else
        //                    internalDataSourceEnvelope.Add(Temp.Item1.GetDataSource(), Temp.Item2.PID.GetIDType(), Temp.Item2.CID.GetIDType(), Temp.Item2.JnType);
        //            }

        //            AddedCount++;
        //        } while (Temp.Item2.ConnectedtoIndex < int.MaxValue);

        //        if (destination == null)
        //            return null;
        //        else
        //            internalDataSourceEnvelope.SetDestinationColumnSet(destination.GetColumnSetObject());

        //        if (columnTypes == null)
        //            return null;
        //        else
        //        {
        //            columnTypes.ForEach(ct => internalDataSourceEnvelope.SetColType(ct.ColName, Type.GetType(ct.ColumnType)));
        //        }
        //        return internalDataSourceEnvelope;
        //    }
        //}
        public DataSourceEnvelope GenerateDSE()
        {
            internalDataSourceEnvelope = new DataSourceEnvelope();
            dataSourceSequence.ForEach(tds =>
                {
                    internalDataSourceEnvelope.Add(tds.Item1.GetDataSource(),
                                                    tds.Item2.PID != null ? tds.Item2.PID.GetIDType() : null,
                                                    tds.Item2.CID != null ? tds.Item2.CID.GetIDType() : null,
                                                    tds.Item2.JnType);
                });

            if (destination == null)
                return null;
            else
                internalDataSourceEnvelope.SetDestinationColumnSet(destination.GetColumnSetObject());

            if (columnTypes == null)
                return null;
            else
            {
                columnTypes.ForEach(ct => internalDataSourceEnvelope.SetColType(ct.ColName, Type.GetType(ct.ColumnType)));
            }
            return internalDataSourceEnvelope;
        }

    }
    [DataContract]
    public class JoinSpec
    {
        [DataMember]
        public int ConnectedtoIndex;
        [DataMember]
        public IDTypeProxy PID;
        [DataMember]
        public IDTypeProxy CID;
        [DataMember]
        public JoinType JnType;
        public void ConnectTo(int index, IDTypeProxy pid, IDTypeProxy cid, JoinType jn)
        {
            ConnectedtoIndex = index;
            PID = pid;
            CID = cid;
            JnType = jn;
        }
    }



}

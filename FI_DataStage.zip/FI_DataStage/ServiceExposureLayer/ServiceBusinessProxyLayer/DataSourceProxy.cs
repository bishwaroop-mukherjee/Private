﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.Runtime;
using System.ServiceModel;
using System.ServiceModel.Web;

namespace ServiceExposureLayer.ServiceBusinessProxyLayer
{
    [DataContract]
    public class DataSourceProxy
    {
        internal FI_DataStage.DataSourceFactory dataSourceGen;

        private string _TableName;

        [DataMember]
        public string TableName
        {
            get { return _TableName; }
            set { _TableName = value; }
        }
        private String _SourceType = "XXX";

        [DataMember]
        public String SourceType
        {
            get { return _SourceType; }
            set { _SourceType = value; }
        }
        private List<IDTypeProxy> _ID;

        [DataMember]
        internal List<IDTypeProxy> ID
        {
            get { return _ID; }
            set { _ID = value; }
        }
        private String _SourceNameValue;

        [DataMember]
        public String SourceNameValue
        {
            get { return _SourceNameValue; }
            set { _SourceNameValue = value; }
        }
        private string _SheetName;

        [DataMember]
        public string SheetName
        {
            get { return _SheetName; }
            set { _SheetName = value; }
        }
        private int _TailSkipRows;

        [DataMember]
        public int TailSkipRows
        {
            get { return _TailSkipRows; }
            set { _TailSkipRows = value; }
        }
        private int _HeadSkipRows;

        [DataMember]
        public int HeadSkipRows
        {
            get { return _HeadSkipRows; }
            set { _HeadSkipRows = value; }
        }
        private string _Delim;

        [DataMember]
        public string Delim
        {
            get { return _Delim; }
            set { _Delim = value; }
        }
        private bool _Header_Present;

        [DataMember]
        public bool Header_Present
        {
            get { return _Header_Present; }
            set { _Header_Present = value; }
        }
        private bool _Merge_Delim;

        [DataMember]
        public bool Merge_Delim
        {
            get { return _Merge_Delim; }
            set { _Merge_Delim = value; }
        }
        private string _Range;

        [DataMember]
        public string Range
        {
            get { return _Range; }
            set { _Range = value; }
        }
        private string _InputType;

        [DataMember]
        public string InputType
        {
            get { return _InputType; }
            set { _InputType = value; }
        }
        private DataSourceProxy _InpDLI;

        [DataMember]
        public DataSourceProxy InpDLI
        {
            get { return _InpDLI; }
            set { _InpDLI = value; }
        }
        private string _SourceSpecification;

        [DataMember]
        public string SourceSpecification
        {
            get { return _SourceSpecification; }
            set { _SourceSpecification = value; }
        }
        private bool _TreatLeadingBlankAsData;

        [DataMember]
        public bool TreatLeadingBlankAsData
        {
            get { return _TreatLeadingBlankAsData; }
            set { _TreatLeadingBlankAsData = value; }
        }
        private string _ReplaceLeadingBlank;

        [DataMember]
        public string ReplaceLeadingBlank
        {
            get { return _ReplaceLeadingBlank; }
            set { _ReplaceLeadingBlank = value; }
        }
        private string _UnderlyingDS;

        [DataMember]
        public string UnderlyingDS
        {
            get { return _UnderlyingDS; }
            set { _UnderlyingDS = value; }
        }
        private FI_DataStage.DataSourceClass GenDataSourceWithoutInput()
        {
            List<FI_DataStage.ComplexTempType> lID;
            lID = _ID == null?null:(from i in _ID select (FI_DataStage.ComplexTempType)i.GetIDType()).ToList();
            

            dataSourceGen = new FI_DataStage.DataSourceFactory(_TableName, _SourceType, _SourceNameValue, _SheetName,
                                                               _Range, _TailSkipRows, _HeadSkipRows, _Delim, _Merge_Delim,
                                                               _Header_Present, lID, _UnderlyingDS);

            return dataSourceGen.GetDataSourceInstance();
        }

        private FI_DataStage.DataSourceClass GenDataSourceWithInput()
        {
            List<FI_DataStage.ComplexTempType> lID;
            lID = _ID==null?null:(from i in _ID select (FI_DataStage.ComplexTempType)i.GetIDType()).ToList();
            

            //dataSourceGen = new FI_DataStage.DataSourceFactory(_TableName, _SourceType, _SourceNameValue, _SheetName,
            //                                                   _Range, _TailSkipRows, _HeadSkipRows, _Delim, _Merge_Delim,
            //                                                   _Header_Present, lID, _UnderlyingDS);
            dataSourceGen = new FI_DataStage.DataSourceFactory(_TableName, _SourceType, _SourceNameValue, _SheetName,
                                                               _Range, _TailSkipRows, _HeadSkipRows, _Delim, _Merge_Delim,
                                                               _Header_Present, lID, _InputType, _InpDLI.GenDataSourceWithoutInput(), _SourceSpecification,
                                                               _TreatLeadingBlankAsData, _ReplaceLeadingBlank, _UnderlyingDS);
            return dataSourceGen.GetDataSourceInstance();
        }

        public FI_DataStage.DataSourceClass GetDataSource()
        {
            if (_InpDLI == null)
                return GenDataSourceWithoutInput();
            else
                return GenDataSourceWithInput();
        }
    }
}

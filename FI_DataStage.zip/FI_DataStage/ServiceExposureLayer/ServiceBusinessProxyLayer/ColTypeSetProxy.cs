﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FI_DataTranformations;
using System.Runtime.Serialization;

namespace ServiceExposureLayer.ServiceBusinessProxyLayer
{
    [DataContract]
    public class ColTypeSetProxy
    {


        List<ColTypeProxy> columns;
        [DataMember]
        public List<ColTypeProxy> Columns
        {
            get { return columns; }
            set { columns = value; }
        }

    }
}

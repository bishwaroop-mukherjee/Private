﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Web;
using System.ServiceModel;
using ServiceExposureLayer.ServiceBusinessProxyLayer;

namespace ServiceExposureLayer.ServiceImplementationLayer
{
    [ETLServiceLibrary.ETLPublishService("ServiceClass")]
    [ServiceBehavior(IncludeExceptionDetailInFaults = true, IgnoreExtensionDataObject = true)]
    public class DataStageETLService : ServiceBusinessProxyLayer.IDataStageETLService
    {
        FI_DataTranformations.DataTransformations DataTransObject;
        Dictionary<string, ServiceBusinessProxyLayer.TransformationContainerProxy> Transformations;
        Dictionary<string, ServiceBusinessProxyLayer.DataSourceEnvelopeProxy> Data;

        public System.Data.DataTable GetDataFromSource(ServiceBusinessProxyLayer.DataSourceProxy ds)
        {
            FI_DataStage.DataSourceClass dsc;
            dsc = ds.GetDataSource();
            System.Data.DataTable dt = dsc.getDataTable();
            dt.TableName = dsc.TableName;
            return dt;
        }

        public List<string> GetDataSchemaFromSource(ServiceBusinessProxyLayer.DataSourceProxy ds)
        {
            FI_DataStage.DataSourceClass dsc;
            dsc = ds.GetDataSource();

            return dsc.getDataSchema();
        }

        public void AddData(ServiceBusinessProxyLayer.DataSourceEnvelopeProxy dataJoin, string name)
        {
            if (Data == null)
                Data = new Dictionary<string, ServiceBusinessProxyLayer.DataSourceEnvelopeProxy>();

            Data.Add(name, dataJoin);
        }

        public System.Data.DataTable GetTransformationData()
        {
            DataTransObject = new FI_DataTranformations.DataTransformations();
            if (Data != null)
                Data.
                    Select<KeyValuePair<string, DataSourceEnvelopeProxy>, DataSourceEnvelopeProxy>(dk => dk.Value).
                    ToList().
                    ForEach(dsep => DataTransObject.AddData(dsep.GenerateDSE()));

            if (Transformations != null)
            {
                Transformations.
                    Select<KeyValuePair<string, TransformationContainerProxy>, TransformationContainerProxy>(dk => dk.Value)
                    .ToList().
                    ForEach(tr =>
                        {
                            for (int i = 0; i < tr.Inputs.Count; i++)
                            {
                                if (Data.ContainsKey(tr.Inputs[i]))
                                {
                                    tr.Inputs[i] = "TD:" + i.ToString();
                                }
                                else
                                    if (Transformations.ContainsKey(tr.Inputs[i]))
                                    {
                                        tr.Inputs[i] = "TX:" + i.ToString();
                                    }
                                    else
                                    {
                                        throw new Exception("This Input source is not available in data  or transformation");
                                    }
                            }
                        });

                Transformations.
                    Select<KeyValuePair<string, TransformationContainerProxy>, TransformationContainerProxy>(dk => dk.Value)
                    .ToList().
                    ForEach(tr => DataTransObject.AddTransformations(tr.GenerateTransformationContainer()));
            }
            try
            {
                if (Data != null)
                    return DataTransObject.Select();
                else
                    return null;
            }
            catch (Exception)
            {

                throw;
            }
        }

        public void AddDataSourcetoEnvelope(DataSourceProxy datasource, string envelopeName, string connecttodatasourcename, IDTypeProxy pid, IDTypeProxy cid, FI_DataTranformations.JoinType jn)
        {
            Data[envelopeName].Add(datasource, connecttodatasourcename, pid, cid, jn);

        }

        public void ModifyJoin(DataSourceProxy datasource, string envelopeName, string connecttodatasourcename, IDTypeProxy pid, IDTypeProxy cid, FI_DataTranformations.JoinType jn)
        {
            Data[envelopeName].ModifyJoin(datasource, connecttodatasourcename, pid, cid, jn);
        }

        public void AddFirstDataSourcetoEnvelope(DataSourceProxy datasource, string envelopeName)
        {
            if (Data == null) throw new Exception("Data non existent");
            if (!Data.ContainsKey(envelopeName)) throw new Exception("Key not found\n");
            Data[envelopeName].Add(datasource, "null", null, null, FI_DataTranformations.JoinType.Cross);
        }

        public System.Data.DataTable JoinTables(string dseName)
        {

            System.Data.DataTable retdata = Data[dseName].GenerateDSE().GetResult();
            retdata.TableName = dseName;
            return retdata;
        }

        public System.Collections.IDictionary GetData()
        {
            return Data;
        }

        public void AddDestinationColumntoEnvelope(ColumnSetProxy dest, string dsename)
        {
            Data[dsename].Destination = new ColumnSetProxy();
            foreach (ColumnProxy c in dest.Columns)
                Data[dsename].Destination.Add(c);
        }

        public void AddColTypetoEnvelope(ColTypeSetProxy coltypes, string dsename)
        {
            Data[dsename].ColumnTypes = new List<ColTypeProxy>();
            foreach (ColTypeProxy ct in coltypes.Columns)
            {
                Data[dsename].ColumnTypes.Add(ct);
            }
        }

        public void AddDataSourceSequence(List<DataNode> sequence, string envelopeName)
        {
            string PrevDsName = null;
            if (Data[envelopeName].DataSourceSequence != null && Data[envelopeName].DataSourceSequence.Count > 0)
                Data[envelopeName].DataSourceSequence.Clear();

            sequence.ToList().ForEach(dn =>
                {
                    Data[envelopeName].Add(dn.DataSource, PrevDsName, dn.Pid, dn.Cid, dn.jointype);
                    PrevDsName = dn.DataSource.TableName;
                });
        }

        public List<string> GetTransFormationCategories()
        {
            FI_DataTranformations.Transformations.TransformationFactory tf = new FI_DataTranformations.Transformations.TransformationFactory();
            return tf.GetTransformationCategories();
        }

        public void AddTransformation(ServiceBusinessProxyLayer.TransformationContainerProxy transwithinput, string name)
        {
            if (Transformations == null)
                Transformations = new Dictionary<string, ServiceBusinessProxyLayer.TransformationContainerProxy>();

            Transformations.Add(name, transwithinput);
        }

        public void AddTransformationCollection(List<TransformationContainerProxy> coll)
        {
            if (Transformations == null)
                Transformations = new Dictionary<string, ServiceBusinessProxyLayer.TransformationContainerProxy>();
            else if (Transformations.Count > 0)
                Transformations.Clear();

            coll.ForEach(tcp => Transformations.Add(tcp.TransActor.Name, tcp));

        }
    }
}

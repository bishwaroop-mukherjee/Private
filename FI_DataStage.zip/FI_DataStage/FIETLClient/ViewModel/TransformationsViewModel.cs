﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ETL = FIETLClient.FIETLWCFService;
using System.Collections.ObjectModel;
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using System.Data;
namespace FIETLClient.ViewModel
{
    public class TransformationsViewModel : ViewModelBase
    {
        public TransformationsViewModel()
        {
            ModelInterface.ServiceInterfacing.UpdateDestCaller += UpdateCall;
        }
        void UpdateCall()
        {
            //RaisePropertyChanged("DataSourceEnvelopes");
            RaisePropertyChanged("ProjectElements");
        }
        public ObservableCollection<DataSourceEnvelopeViewModel> DataSourceEnvelopes
        {
            get
            {
                List<DataSourceEnvelopeViewModel> lst = ModelInterface.ServiceInterfacing.GetAllEnvelopes();

                return new ObservableCollection<DataSourceEnvelopeViewModel>(lst);
            }
        }

        public ObservableCollection<TransformationViewModel> Transformations
        {
            get
            {
                List<TransformationViewModel> lst = ModelInterface.ServiceInterfacing.GetAllTransformations();
                return new ObservableCollection<TransformationViewModel>(lst);
            }
        }

        public ObservableCollection<ViewModelBase> ProjectElements
        {
            get
            {
                List<ViewModelBase> lst = new List<ViewModelBase>();
                List<DataSourceEnvelopeViewModel> dtlst = ModelInterface.ServiceInterfacing.GetAllEnvelopes();
                if (dtlst != null)
                    lst.AddRange(dtlst);
                List<TransformationViewModel> xlst = ModelInterface.ServiceInterfacing.GetAllTransformations();
                if (xlst != null)
                    lst.AddRange(xlst);
                return new ObservableCollection<ViewModelBase>(lst);
            }
        }

        private DataTable _PreviewData;
        public DataTable PreviewData
        {
            get
            {
                return _PreviewData;
            }
        }

        public RelayCommand PreviewDataCommand
        {
            get
            {
                RelayCommand rc = new RelayCommand(() =>
                    {
                        _PreviewData = ModelInterface.ServiceInterfacing.GetTransformationData();
                        RaisePropertyChanged("PreviewData");
                    });
                return rc;
            }
        }
        public RelayCommand<string> AddDSECommand
        {
            get
            {
                RelayCommand<string> dc = new RelayCommand<string>(AddDSEMethod, CanAddDSEExecute);
                return dc;
            }
        }

        public void AddDSEMethod(string param)
        {
            ViewModel.DataSourceEnvelopeViewModel dsevm = ViewModel.DataSourceEnvelopeViewModel.GetViewModelFromModel(new ETL.DataSourceEnvelopeProxy() { Destination = null, ColumnTypes = null });
            dsevm.DseName = param;

            dsevm.Save();
        }

        public bool CanAddDSEExecute(string param)
        {
            return !ModelInterface.ServiceInterfacing.ContainsEnvelopeName(param);
        }

        public RelayCommand<TransformationViewModel> AddTransformation
        {
            get
            {
                RelayCommand<TransformationViewModel> tc = new RelayCommand<TransformationViewModel>(
                                                            t => t.Save(),
                                                            t => ModelInterface.ServiceInterfacing.ContainsTransformation(t.TransName));
                return tc;
            }
        }
    }
}

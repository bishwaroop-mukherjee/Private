﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Data;

namespace FIETLClient.ViewModel
{
    public class ValueToListConverter : IMultiValueConverter
    {
        object[] ValsProvided;
        public object Convert(object[] values, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (values != null && values.Length > 0 && values[0].GetType() == typeof(string))
            {
                ValsProvided = new object[] { };
                Array.Resize<object>(ref ValsProvided, values.Length);
                values.CopyTo(ValsProvided, 0);
            }

            List<string> l = new List<string>();
            string[] Params = new string[] { };
            if (parameter.GetType() == typeof(string))
                Params = ((string)parameter).Split(new string[] { ", " }, StringSplitOptions.RemoveEmptyEntries);
            if (Params.Length != ValsProvided.Length) return null;
            for (int i = 0; i < ValsProvided.Length; i++)
            {
                l.Add(Params[i] + ": " + ValsProvided[i]);
            }
            return l;
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}

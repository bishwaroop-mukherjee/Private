﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Controls;
using ExpressionBuilder.Controls;
using ExpressionBuilder.Expressions;
using ExpressionBuilder.BaseTypes;
using System.Windows;

namespace FIETLClient.ViewModel
{
    public class ValuesTemplateSelector : DataTemplateSelector
    {
        private string _LeftRightSelector;

        public string LeftRightSelector
        {
            get { return _LeftRightSelector; }
            set { _LeftRightSelector = value; }
        }
        public override System.Windows.DataTemplate SelectTemplate(object item, System.Windows.DependencyObject container)
        {
            var viewer = container.GetParent<ExpressionViewer>();
            DataTemplate dt;

            if (_LeftRightSelector == "Left")
                dt = (DataTemplate)viewer.Resources["DT_Left"];
            else
                dt = (DataTemplate)viewer.Resources["DT_Right"];

            return dt;
        }
    }
}

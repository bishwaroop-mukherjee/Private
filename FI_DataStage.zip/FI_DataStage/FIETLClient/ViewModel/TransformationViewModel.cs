﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using GalaSoft.MvvmLight;
using System.Collections.ObjectModel;
using ETL = FIETLClient.FIETLWCFService;
using GalaSoft.MvvmLight.Command;
using ExpressionBuilder.BaseTypes;
using ExpressionBuilder.Expressions;

namespace FIETLClient.ViewModel
{
    public class TransformationViewModel : ViewModelBase
    {
        public TransformationViewModel()
        {
            ModelInterface.ServiceInterfacing.UpdateDestCaller += UpdateInputSourcePossibilities;
        }
        private void UpdateInputSourcePossibilities()
        {
            RaisePropertyChanged("InputPossibleCols");
        }
        #region PublicProperties
        public ObservableCollection<string> Categories
        {
            get
            {
                List<string> lst = ModelInterface.ServiceInterfacing.GetTransformationCategories();
                return new ObservableCollection<string>(lst);
            }
        }

        private string _TransCategory;
        public string TransCategory
        {
            get
            {
                return _TransCategory;
            }
            set
            {
                _TransCategory = value;
                RaisePropertyChanged("TransCategory");
            }
        }
        private string _TransName;

        public string Name
        {
            get { return _TransName; }
            set
            {
                _TransName = value;
                RaisePropertyChanged("Name");
            }
        }
        public string TransName
        {
            get
            {
                return _TransName;
            }
            set
            {
                _TransName = value;
                RaisePropertyChanged("TransName");
            }
        }
        private FIETLClient.FIETLWCFService.ParameterProxyBase _Params;
        public FIETLClient.FIETLWCFService.ParameterProxyBase Params
        {
            get
            {
                return _Params;
            }
            set
            {
                _Params = value;
                RaisePropertyChanged("Params");
            }
        }
        private List<String> _TxInputs;

        public List<string> Inputs
        {
            get { return _TxInputs; }
            set
            {
                _TxInputs = value;
                RaisePropertyChanged("Inputs");
                RaisePropertyChanged("TxInputs");
            }
        }
        public ObservableCollection<string> TxInputs
        {
            get
            {
                if (_TxInputs == null)
                    return null;
                return new ObservableCollection<string>(_TxInputs);
            }
        }

        private List<ViewModelBase> _InputsVM;
        public ObservableCollection<ViewModelBase> InputsVM
        {
            get
            {
                if (_InputsVM == null)
                    _InputsVM = new List<ViewModelBase>();
                return new ObservableCollection<ViewModelBase>(_InputsVM);
            }
        }

        public ObservableCollection<ETL.ColumnProxy> InputPossibleCols
        {
            get
            {
                if (_InputsVM == null) return null;
                List<ETL.ColumnProxy> ocs = new List<ETL.ColumnProxy>();
                var l = _InputsVM.Cast<dynamic>();
                l.ToList().ForEach(s =>
                    {
                        if (s.Destination != null)
                            ocs.AddRange(s.Destination);
                    });
                return new ObservableCollection<ETL.ColumnProxy>(ocs);
            }
        }

        private List<ETL.ColumnProxy> _InputCols;

        public ObservableCollection<ETL.ColumnProxy> InputCols
        {
            get
            {
                if (_InputCols == null)
                    return null;
                return new ObservableCollection<ETL.ColumnProxy>(_InputCols);
            }
        }


        private ExpressionBuilder.Expressions.Expression _CommandExpression;
        public ExpressionBuilder.Expressions.Expression CommandExpression
        {
            get
            {
                return _CommandExpression;
            }
            set
            {
                _CommandExpression = value;
                _CommandString = _CommandExpression.ConverttoInfixString<ETL.ColumnProxy>(_CommandString, c => c.ColumnName);
                RaisePropertyChanged("CommandExpression");
                RaisePropertyChanged("CommandString");
            }
        }
        private string _CommandString;

        public string CommandString
        {
            get
            {
                return _CommandString;
            }
            set
            {
                _CommandString = value;
                RaisePropertyChanged("CommandString");
            }
        }
        private List<ETL.ColumnProxy> _OutputCols;

        public ObservableCollection<ETL.ColumnProxy> Destination
        {
            get
            {
                if (_OutputCols == null)
                    return null;
                return new ObservableCollection<ETL.ColumnProxy>(_OutputCols);
            }
        }
        #endregion
        public RelayCommand<ETL.ColumnProxy> AddInputCol
        {
            get
            {
                RelayCommand<ETL.ColumnProxy> rc = new RelayCommand<ETL.ColumnProxy>(c =>
                    {
                        if (_InputCols == null)
                            _InputCols = new List<ETL.ColumnProxy>();
                        _InputCols.Add(c);
                        RaisePropertyChanged("InputCols");
                    });
                return rc;
            }
        }
        public RelayCommand<ETL.ColumnProxy> AddOutputCol
        {
            get
            {
                RelayCommand<ETL.ColumnProxy> rc = new RelayCommand<ETL.ColumnProxy>(c =>
                {
                    if (_OutputCols == null)
                        _OutputCols = new List<ETL.ColumnProxy>();
                    _OutputCols.Add(c);
                    RaisePropertyChanged("Destination");
                });
                return rc;
            }
        }

        public RelayCommand<ViewModelBase> AddInputsCommand
        {
            get
            {
                RelayCommand<ViewModelBase> rc = new RelayCommand<ViewModelBase>(s =>
                    {
                        if (_TxInputs == null)
                            _TxInputs = new List<string>();
                        if (_InputsVM == null)
                            _InputsVM = new List<ViewModelBase>();
                        dynamic sd = s;
                        _TxInputs.Add(sd.Name);
                        _InputsVM.Add(sd);
                        RaisePropertyChanged("TxInputs");
                        RaisePropertyChanged("InputsVM");
                        ModelInterface.ServiceInterfacing.UpdateDestCaller();
                    });
                return rc;
            }
        }

        public DelegateCommand<ExpressionBuilder.Expressions.Expression, ExpressionBuilder.Expressions.Expression> ExpressionChangeCommand
        {
            get
            {
                DelegateCommand<ExpressionBuilder.Expressions.Expression, ExpressionBuilder.Expressions.Expression> dc = new DelegateCommand<ExpressionBuilder.Expressions.Expression, ExpressionBuilder.Expressions.Expression>((eL, eR) =>
                    {
                        CommandExpression = eL;
                        if (eR != null)
                        {
                            if (eL.GetType() == typeof(ComparisionExpression))
                            {
                                ComparisionExpression e = (ComparisionExpression)eL;
                                if (eR.GetType() == typeof(RightValueExpression))
                                    e.Right.Value = ((RightValueExpression)eR).Value;
                            }
                        }
                    });
                return dc;
            }
        }
        public RelayCommand<TransformationViewModel> TransSaveCommand
        {
            get
            {
                RelayCommand<TransformationViewModel> rc = new RelayCommand<TransformationViewModel>(t =>
                    {
                        t.Save();
                    });
                return rc;
            }
        }

        public void Save()
        {
            if (_InputCols != null)
            {
                _Params = new ETL.ParameterProxyBase();
                _Params.OnColumns = _InputCols.Select<ETL.ColumnProxy, ETL.Column>(c => new ETL.Column() { ColumnName = c.ColumnName, ColumnExpression = c.ColExpr, MappingColumn = c.MapCol }).ToArray();

                if (_OutputCols != null)
                    _Params.RetColumns = _OutputCols.Select<ETL.ColumnProxy, ETL.Column>(c => new ETL.Column() { ColumnName = c.ColumnName, ColumnExpression = c.ColExpr, MappingColumn = c.MapCol }).ToArray();

                if (!string.IsNullOrEmpty(_CommandString))
                    _Params.Command = _CommandString;
            }
            ETL.TransformationProxy txp = new ETL.TransformationProxy()
            {
                Category = TransCategory,
                Name = TransName,
                Parameters = Params

            };
            ETL.TransformationContainerProxy txcp = new ETL.TransformationContainerProxy()
            {
                TransActor = txp
                //Inputs = TxInputs.ToArray()
            };
            if (Inputs != null)
            {
                txcp.Inputs = Inputs.ToArray();
            }


            ModelInterface.ServiceInterfacing.RegisterTransformation(txcp);
            ModelInterface.ServiceInterfacing.UpdateDestCaller();
        }
    }
}

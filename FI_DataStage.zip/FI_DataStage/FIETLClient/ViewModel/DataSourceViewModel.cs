﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using GalaSoft.MvvmLight;
using ETL = FIETLClient.FIETLWCFService;
using GalaSoft.MvvmLight.Command;
namespace FIETLClient.ViewModel
{
    public class DataSourceViewModel : ViewModelBase
    {
        #region InternalServiceBindings
        ETL.DataSourceProxy dataSourceInternal;
        #endregion

        #region Fields
        private string delim;
        private bool header_Present = false;
        private int headSkipRows = 0;
        private ETL.IDTypeProxy[] id = null;
        private ETL.DataSourceProxy inpDLI = null;
        private string inpType = String.Empty;
        private bool merge_Delim = false;
        private string range = String.Empty;
        private string replaceLeadingBlank = String.Empty;
        private string sheetName = String.Empty;
        private string sourceNameValue = String.Empty;
        private string sourceSpecification = String.Empty;
        private string sourceType = String.Empty;
        private string tableName = String.Empty;
        private int tailSkipRows = 0;
        private bool treatLeadingBlankAsData = false;
        private string underlyingDS = String.Empty;

        #endregion

        #region DataTreeEleme
        public static Dictionary<string, DataSourceViewModel> TreeRoot;

        public delegate void UpdateTreeCallHandler();
        public static UpdateTreeCallHandler UpdateTreeCaller;

        private List<ChildPointer> Children = null;

        public static List<ETL.DataNode> GetJoinSequence(string DseName)
        {
            List<ETL.DataNode> seq = new List<ETL.DataNode>();
            if (TreeRoot == null)
                throw new Exception("The Data Tree does not exist");
            if (!TreeRoot.ContainsKey(DseName))
                throw new Exception("The Data Source Envelope does not exist");
            if (TreeRoot[DseName] == null)
                throw new Exception("The Data Source Envelope is empty");
            seq.Add(new ETL.DataNode() { DataSource = TreeRoot[DseName].GetDataSource(), Pid = null, Cid = null, jointype = ETL.JoinType.Cross });
            TreeRoot[DseName].ResolveJoinTree(seq);
            return seq;
        }
        private void ResolveJoinTree(List<ETL.DataNode> sequence)
        {
            if (Children != null)
            {
                if (Children.Count > 0)
                {
                    foreach (ChildPointer ch in Children)
                    {
                        sequence.Add(new ETL.DataNode() { DataSource = ch.child.GetDataSource(), Pid = ch.Pid, Cid = ch.Cid, jointype = ch.Join });
                        foreach (DataSourceViewModel ds in ch.ChildArr)
                        {
                            ds.ResolveJoinTree(sequence);
                        }
                    }
                }
            }

        }

        private void AddChild(string parenttablename, ETL.IDTypeProxy pid, ETL.IDTypeProxy cid, ETL.JoinType jn, DataSourceViewModel root)
        {
            if (root.TableName == parenttablename)
            {
                if (root.Children == null)
                    root.Children = new List<ChildPointer>();

                root.Children.Add(new ChildPointer() { child = this, Pid = pid, Cid = cid, Join = jn, Parent = root });
            }
            else if (root.Children == null)
            {
                return;
            }
            else if (root.Children.Count < 1)
            {
                return;
            }
            else
            {
                root.Children.ForEach(cp => AddChild(parenttablename, pid, cid, jn, cp.child));
            }
        }
        private void RemoveChild(DataSourceViewModel root)
        {
            if (root.Children == null) return;

            for (int i = 0; i < root.Children.Count; i++)
            {
                if (root.Children[i].child.TableName == this.TableName)
                    root.Children.RemoveAt(i);
            }

            root.Children.ForEach(cp => RemoveChild(cp.child));
        }
        private void Add(string envelopename, string parenttablename, ETL.IDTypeProxy pid, ETL.IDTypeProxy cid, ETL.JoinType jn)
        {
            if (DataSourceViewModel.TreeRoot == null)
                DataSourceViewModel.TreeRoot = new Dictionary<string, DataSourceViewModel>();

            Dictionary<string, DataSourceViewModel> root = DataSourceViewModel.TreeRoot;
            if (!root.ContainsKey(envelopename))
            {
                root.Add(envelopename, this);
                UpdateTreeCaller();
                return;
            }
            DataSourceViewModel dsvm = root[envelopename];
            if (parenttablename == null && jn == ETL.JoinType.Cross)
            {
                root[envelopename] = this;
                this.Children = new List<ChildPointer>();
                this.Children.Add(new ChildPointer() { child = dsvm, Join = jn, Parent = null });
            }
            if (dsvm.TableName == TableName && (!string.IsNullOrEmpty(parenttablename)))
            {
                if (parenttablename == TableName) return;

                root[envelopename] = dsvm.ChildData[0].child;
                dsvm.ChildData.RemoveAt(0);
                DataSourceViewModel temp;
                foreach (ChildPointer c in dsvm.ChildData)
                {
                    if (c.Join == ETL.JoinType.Cross)
                    {
                        temp = root[envelopename];
                        root[envelopename] = c.child;
                        root[envelopename].Children.Add(new ChildPointer() { child = temp, Join = ETL.JoinType.Cross, Parent = root[envelopename] });
                    }
                }
                dsvm.ChildData.RemoveAll(new Predicate<ChildPointer>(c => c.Join == ETL.JoinType.Cross));
            }
            RemoveChild(dsvm);

            AddChild(parenttablename, pid, cid, jn, root[envelopename]);

            RaisePropertyChanged("ChildData");
            UpdateTreeCaller();
        }
        #endregion

        #region PublicVisibleProperties
        public List<ChildPointer> ChildData
        {
            get
            {
                if (Children == null)
                    return null;
                return Children;
            }
        }

        public string Delim
        {
            get
            {
                return delim;
            }
            set
            {
                delim = value;
                RaisePropertyChanged("Delim");
            }
        }
        public bool Header_Present
        {
            get
            {
                return header_Present;
            }
            set
            {
                header_Present = value;
                RaisePropertyChanged("Header_Present");
            }
        }
        public int HeadSkipRows
        {
            get
            {
                return headSkipRows;
            }
            set
            {
                headSkipRows = value;
                RaisePropertyChanged("HeadSkipRows");
            }
        }
        public ETL.IDTypeProxy[] Id
        {
            get
            {
                return id;
            }
            set
            {
                if (id == value)
                    return;
                id = value;
                RaisePropertyChanged("Id");
            }
        }
        public ETL.DataSourceProxy InpDLI
        {
            get
            {
                return inpDLI;
            }
            set
            {
                inpDLI = value;
                RaisePropertyChanged("InputDLI");
            }
        }
        public string InpType
        {
            get
            {
                return inpType;
            }
            set
            {
                inpType = value;
                RaisePropertyChanged("InpType");
            }
        }
        public bool Merge_Delim
        {
            get
            {
                return merge_Delim;
            }
            set
            {
                merge_Delim = value;
                RaisePropertyChanged("Merge_Delim");
            }
        }
        public string Range
        {
            get
            {
                return range;
            }
            set
            {
                range = value;
                RaisePropertyChanged("Range");
            }
        }
        public string ReplaceLeadingBlank
        {
            get
            {
                return replaceLeadingBlank;
            }
            set
            {
                replaceLeadingBlank = value;
                RaisePropertyChanged("ReplaceLeadingBlank");
            }
        }
        public string SheetName
        {
            get
            {
                return sheetName;
            }
            set
            {
                sheetName = value;
                RaisePropertyChanged("SheetName");
            }
        }
        public string SourceNameValue
        {
            get
            {
                return sourceNameValue;
            }
            set
            {
                sourceNameValue = value;
                RaisePropertyChanged("SourceNameValue");
            }
        }
        public string SourceSpecification
        {
            get
            {
                return sourceSpecification;
            }
            set
            {
                sourceSpecification = value;
                RaisePropertyChanged("SourceSpecification");
            }
        }
        public string SourceType
        {
            get
            {
                return sourceType;
            }
            set
            {
                sourceType = value;
                RaisePropertyChanged("SourceType");
            }
        }
        public string TableName
        {
            get
            {
                return tableName;
            }
            set
            {
                tableName = value;
                RaisePropertyChanged("TableName");
            }
        }
        public bool TreatLeadingBlankAsData
        {
            get
            {
                return treatLeadingBlankAsData;
            }
            set
            {
                treatLeadingBlankAsData = value;
                RaisePropertyChanged("TreatLeadingBlankAsData");
            }
        }
        public int TailSkipRows
        {
            get
            {
                return tailSkipRows;
            }
            set
            {
                tailSkipRows = value;
                RaisePropertyChanged("TailSkipRows");
            }
        }
        public string UnderlyingDS
        {
            get
            {
                return underlyingDS;
            }
            set
            {
                underlyingDS = value;
                RaisePropertyChanged("UnderLyingDS");
            }
        }
        public List<string> Schema
        {
            get
            {
                ETL.DataSourceProxy temp = new ETL.DataSourceProxy()
                {
                    Delim = delim,
                    Header_Present = header_Present,
                    HeadSkipRows = headSkipRows,
                    Merge_Delim = merge_Delim,
                    Range = range,
                    ReplaceLeadingBlank = replaceLeadingBlank,
                    SheetName = sheetName,
                    SourceNameValue = sourceNameValue,
                    SourceSpecification = sourceSpecification,
                    SourceType = sourceType,
                    TableName = tableName,
                    TailSkipRows = tailSkipRows,
                    TreatLeadingBlankAsData = treatLeadingBlankAsData,
                    UnderlyingDS = UnderlyingDS,
                    InpDLI = inpDLI,
                    InputType = inpType,
                    ID = id
                };
                return new List<string>(ModelInterface.ServiceInterfacing.GetDataSourceSchema(temp));
            }
        }
        #endregion

        #region LateBindingMethods
        public void SaveDataSource(string envelopename, string connectto, ETL.IDTypeProxy pid, ETL.IDTypeProxy cid, ETL.JoinType jn)
        {
            dataSourceInternal = new ETL.DataSourceProxy()
            {
                Delim = delim,
                Header_Present = header_Present,
                HeadSkipRows = headSkipRows,
                Merge_Delim = merge_Delim,
                Range = range,
                ReplaceLeadingBlank = replaceLeadingBlank,
                SheetName = sheetName,
                SourceNameValue = sourceNameValue,
                SourceSpecification = sourceSpecification,
                SourceType = sourceType,
                TableName = tableName,
                TailSkipRows = tailSkipRows,
                TreatLeadingBlankAsData = treatLeadingBlankAsData,
                UnderlyingDS = UnderlyingDS,
                InpDLI = inpDLI,
                InputType = inpType,
                ID = id
            };
            List<ETL.DataSourceProxy> temp = ModelInterface.ServiceInterfacing.GetAllSourcesinEnvelope(envelopename);
            if (temp == null || temp.Count(d => d.TableName == TableName) <= 0)
                ModelInterface.ServiceInterfacing.RegisterDataSourceWithEnvelope(envelopename, dataSourceInternal, connectto, pid, cid, jn);
            else
                ModelInterface.ServiceInterfacing.ModifyJoin(envelopename, dataSourceInternal, connectto, pid, cid, jn);

            Add(envelopename, connectto, pid, cid, jn);
            ModelInterface.ServiceInterfacing.UpdateDestCaller();
        }
        public void SaveDataSource(string envelopename)
        {
            dataSourceInternal = new ETL.DataSourceProxy()
            {
                Delim = delim,
                Header_Present = header_Present,
                HeadSkipRows = headSkipRows,
                Merge_Delim = merge_Delim,
                Range = range,
                ReplaceLeadingBlank = replaceLeadingBlank,
                SheetName = sheetName,
                SourceNameValue = sourceNameValue,
                SourceSpecification = sourceSpecification,
                SourceType = sourceType,
                TableName = tableName,
                TailSkipRows = tailSkipRows,
                TreatLeadingBlankAsData = treatLeadingBlankAsData,
                UnderlyingDS = UnderlyingDS,
                InpDLI = inpDLI,
                InputType = inpType,
                ID = id
            };
            dseName = envelopename;
            ModelInterface.ServiceInterfacing.RegisterDataSourceWithEnvelope(envelopename, dataSourceInternal);
            Add(envelopename, null, null, null, ETL.JoinType.Cross);
            ModelInterface.ServiceInterfacing.UpdateDestCaller();
        }
        public void SaveDataSource()
        {
            dataSourceInternal = new ETL.DataSourceProxy()
            {
                Delim = delim,
                Header_Present = header_Present,
                HeadSkipRows = headSkipRows,
                Merge_Delim = merge_Delim,
                Range = range,
                ReplaceLeadingBlank = replaceLeadingBlank,
                SheetName = sheetName,
                SourceNameValue = sourceNameValue,
                SourceSpecification = sourceSpecification,
                SourceType = sourceType,
                TableName = tableName,
                TailSkipRows = tailSkipRows,
                TreatLeadingBlankAsData = treatLeadingBlankAsData,
                UnderlyingDS = UnderlyingDS,
                InpDLI = inpDLI,
                InputType = inpType,
                ID = id
            };

            //ModelInterface.ServiceInterfacing.RegisterDataSourceWithEnvelope();
        }

        public ETL.DataSourceProxy GetDataSource()
        {
            return new ETL.DataSourceProxy()
            {
                Delim = delim,
                Header_Present = header_Present,
                HeadSkipRows = headSkipRows,
                Merge_Delim = merge_Delim,
                Range = range,
                ReplaceLeadingBlank = replaceLeadingBlank,
                SheetName = sheetName,
                SourceNameValue = sourceNameValue,
                SourceSpecification = sourceSpecification,
                SourceType = sourceType,
                TableName = tableName,
                TailSkipRows = tailSkipRows,
                TreatLeadingBlankAsData = treatLeadingBlankAsData,
                UnderlyingDS = UnderlyingDS,
                InpDLI = inpDLI,
                InputType = inpType,
                ID = id
            };

            //ModelInterface.ServiceInterfacing.RegisterDataSourceWithEnvelope();
        }
        #endregion

        public static DataSourceViewModel GetViewModelfromModel(ETL.DataSourceProxy dp)
        {
            DataSourceViewModel dvm = new DataSourceViewModel()
            {
                Delim = dp.Delim,
                Header_Present = dp.Header_Present,
                HeadSkipRows = dp.HeadSkipRows,
                Merge_Delim = dp.Merge_Delim,
                Range = dp.Range,
                ReplaceLeadingBlank = dp.ReplaceLeadingBlank,
                SheetName = dp.SheetName,
                SourceNameValue = dp.SourceNameValue,
                SourceSpecification = dp.SourceSpecification,
                SourceType = dp.SourceType,
                TableName = dp.TableName,
                TailSkipRows = dp.TailSkipRows,
                TreatLeadingBlankAsData = dp.TreatLeadingBlankAsData,
                UnderlyingDS = dp.UnderlyingDS,
                InpDLI = dp.InpDLI,
                InpType = dp.InputType,
                Id = dp.ID
            };
            return dvm;
        }

        #region CommandsAndImplementations
        public RelayCommand<DataSourceViewModel> BrowsePathCommand
        {
            get
            {
                RelayCommand<DataSourceViewModel> rc = new RelayCommand<DataSourceViewModel>(BrowseSourcePath,
                    (d) =>
                        ((!string.IsNullOrEmpty(d.SourceType))
                        &&
                        (!string.IsNullOrEmpty(d.TableName))));

                return rc;
            }
        }
        void BrowseSourcePath(DataSourceViewModel dsvm)
        {
            Microsoft.Win32.OpenFileDialog opdg = new Microsoft.Win32.OpenFileDialog();
            bool? res = opdg.ShowDialog();
            if (res.HasValue)
            {
                if (res == true && !string.IsNullOrEmpty(opdg.FileName))
                    dsvm.SourceNameValue = opdg.FileName;
            }
        }
        public RelayCommand<string> AddDataSourceCommand
        {
            get
            {
                RelayCommand<string> rc = new RelayCommand<string>(AddDataSource,
                    (s) =>
                        ((!string.IsNullOrEmpty(this.SourceType))
                        &&
                        (!string.IsNullOrEmpty(this.TableName))
                        &&
                        (!string.IsNullOrEmpty(s))));

                return rc;
            }
        }
        public RelayCommand<ETL.ColumnProxy> AddColToDestCommand
        {
            get
            {
                RelayCommand<ETL.ColumnProxy> rc = new RelayCommand<ETL.ColumnProxy>(AddColToDest, s => s != null);
                return rc;
            }
        }
        public RelayCommand<string> AddColToDestCommandDefault
        {
            get
            {
                RelayCommand<string> rc = new RelayCommand<string>(s =>
                    {

                        AddColToDest(new
                        {
                            ColumnName = s.Replace(TableName + "_", ""),
                            ColExpr = s,
                            MapCol = s.Replace(TableName + "_", ""),
                            ActualName = s
                        });
                    },
                    s => !string.IsNullOrEmpty(s));
                return rc;
            }
        }
        void AddColToDest(dynamic col)
        {
            List<DataSourceEnvelopeViewModel> dses = ModelInterface.ServiceInterfacing.GetAllEnvelopes();
            if (dses == null)
                return;

            DataSourceEnvelopeViewModel temp = dses.Where(dp => dp.DseName == dseName).First();
            temp.AddDestinationColumn(col.ColumnName, col.ColExpr, col.MapCol, col.ActualName);
            ModelInterface.ServiceInterfacing.UpdateDestCaller();
        }
        void AddDataSource(string dse)
        {
            DataSourceViewModel temp = new DataSourceViewModel()
            {
                Delim = delim,
                Header_Present = header_Present,
                HeadSkipRows = headSkipRows,
                Merge_Delim = merge_Delim,
                Range = range,
                ReplaceLeadingBlank = replaceLeadingBlank,
                SheetName = sheetName,
                SourceNameValue = sourceNameValue,
                SourceSpecification = sourceSpecification,
                SourceType = sourceType,
                TableName = tableName,
                TailSkipRows = tailSkipRows,
                TreatLeadingBlankAsData = treatLeadingBlankAsData,
                UnderlyingDS = UnderlyingDS,
                InpDLI = inpDLI,
                InpType = inpType,
                Id = id,
                dseName = dse
            };
            temp.SaveDataSource(dse, null, null, null, ETL.JoinType.Cross);
        }


        #endregion

        public override bool Equals(object obj)
        {
            if (obj.GetType().Name.Contains("DataSourceViewModel"))
                return ((DataSourceViewModel)obj).TableName == TableName;
            else
                return base.Equals(obj);
        }

        public bool Equals(DataSourceViewModel x)
        {
            return x.TableName == TableName;
        }

        public string dseName;
        public ChildPointer CorrCurrChPt
        {
            get
            {
                return new ChildPointer() { child = this, Parent = null, Pid = null, Cid = null, Join = ETL.JoinType.Cross };
            }

        }
    }

    public class ChildPointer : ViewModelBase
    {

        public ChildPointer()
        {
            ModelInterface.ServiceInterfacing.UpdateDestCaller += UpdateCall;
        }
        void UpdateCall()
        {
            RaisePropertyChanged("PossibleParents");
        }
        DataSourceViewModel _Parent;
        public DataSourceViewModel Parent
        {
            get
            {
                return _Parent;
            }
            set
            {
                _Parent = value;
                RaisePropertyChanged("Parent");
            }
        }

        public List<DataSourceViewModel> PossibleParents
        {
            get
            {
                List<ETL.DataSourceProxy> l = ModelInterface.ServiceInterfacing.GetAllSourcesinEnvelope(child.dseName);
                if (l != null)
                {
                    if (l.Count > 0)
                        return l.ConvertAll(d => DataSourceViewModel.GetViewModelfromModel(d));
                    else
                        return null;
                }
                else
                    return null;
            }
        }

        private DataSourceViewModel _Child;
        public DataSourceViewModel child
        {
            get
            {
                return _Child;
            }
            set
            {
                _Child = value;
                RaisePropertyChanged("child");
                RaisePropertyChanged("ChildArr");
            }
        }

        public List<DataSourceViewModel> ChildArr
        {
            get
            {
                return new List<DataSourceViewModel>(new DataSourceViewModel[] { child });
            }

        }
        private ETL.IDTypeProxy _Pid;
        public ETL.IDTypeProxy Pid
        {
            get
            {
                if (_Pid == null)
                {
                    _Pid = new ETL.IDTypeProxy();
                }
                return _Pid;
            }
            set
            {
                _Pid = value;
                RaisePropertyChanged("Pid");
            }
        }
        private ETL.IDTypeProxy _Cid;
        public ETL.IDTypeProxy Cid
        {
            get
            {
                if (_Cid == null)
                {
                    _Cid = new ETL.IDTypeProxy();
                }
                return _Cid;
            }
            set
            {
                _Cid = value;
                RaisePropertyChanged("Cid");
            }
        }
        private ETL.JoinType _Join;
        public ETL.JoinType Join
        {
            get
            {
                return _Join;
            }
            set
            {
                _Join = value;
                RaisePropertyChanged("Join");
            }
        }
        public int JoinInt
        {
            get
            {
                return (int)_Join;
            }
            set
            {
                _Join = (ETL.JoinType)value;
                RaisePropertyChanged("JoinInt");
                RaisePropertyChanged("Join");
            }
        }
        public string JoinString
        {
            get
            {
                string x = "Invalid";
                switch (_Join)
                {
                    case ETL.JoinType.Cross:
                        x = "Cross";
                        break;
                    case ETL.JoinType.Inner:
                        x = "Inner";
                        break;
                    case ETL.JoinType.LeftOuter:
                        x = "LeftOuter";
                        break;
                    case ETL.JoinType.Outer:
                        x = "Outer";
                        break;
                    case ETL.JoinType.RightOuter:
                        x = "RightOuter";
                        break;

                }
                return x;
            }
            set
            {
                ETL.JoinType x = ETL.JoinType.Cross;
                switch (value)
                {
                    case "Cross":
                        x = ETL.JoinType.Cross;
                        break;
                    case "Inner":
                        x = ETL.JoinType.Inner;
                        break;
                    case "LeftOuter":
                        x = ETL.JoinType.LeftOuter;
                        break;
                    case "Outer":
                        x = ETL.JoinType.Outer;
                        break;
                    case "RightOuter":
                        x = ETL.JoinType.RightOuter;
                        break;

                }
                _Join = x;
                RaisePropertyChanged("Join");
                RaisePropertyChanged("JoinString");
            }
        }
        public RelayCommand<ChildPointer> AddChildDataSourceCommand
        {
            get
            {
                RelayCommand<ChildPointer> rc = new RelayCommand<ChildPointer>(AddChildDataSource,
                    (s) =>
                        s != null);

                return rc;
            }
        }
        void AddChildDataSource(ChildPointer chld)
        {
            chld.child.SaveDataSource(chld.child.dseName, chld.Parent.TableName, chld.Pid, chld.Cid, chld.Join);
            DataSourceViewModel.UpdateTreeCaller();
            //temp.SaveDataSource(dse, null, null, null, ETL.JoinType.Cross);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using GalaSoft.MvvmLight;
using ETL = FIETLClient.FIETLWCFService;
using GalaSoft.MvvmLight.Command;

namespace FIETLClient.ViewModel
{
    public class DataSourceEnvelopeViewModel : ViewModelBase
    {
        public DataSourceEnvelopeViewModel()
        {
            ModelInterface.ServiceInterfacing.UpdateDestCaller += UpdateCall;
            DataSourceViewModel.UpdateTreeCaller += UpdateTree;
        }

        void UpdateCall()
        {
            RaisePropertyChanged("DataSources");
            RaisePropertyChanged("Destination");
            RaisePropertyChanged("ColTypes");
        }
        void UpdateTree()
        {
            RaisePropertyChanged("DataSourceTree");
        }

        #region PrivateFields
        private ETL.DataSourceEnvelopeProxy DataSourceEnvelopeInternal;
        private string dseName;

        private ETL.ColumnSetProxy destination;
        private ETL.ColTypeProxy[] colTypes;
        private System.Data.DataView previewData;


        #endregion

        #region Properties
        public string Name
        {
            get
            {
                return dseName;
            }
            set
            {
                dseName = value;
                RaisePropertyChanged("Name");
            }
        }

        public ObservableCollection<ETL.ColTypeProxy> ColTypes
        {
            get
            {
                colTypes = ModelInterface.ServiceInterfacing.GetDestinationColumnTypesforEnvelope(dseName);
                if (colTypes == null)
                    return null;
                return new ObservableCollection<ETL.ColTypeProxy>(colTypes);
            }
        }
        public ObservableCollection<ETL.ColumnProxy> Destination
        {
            get
            {
                destination = ModelInterface.ServiceInterfacing.GetDestinationColumnsforEnvelope(dseName);
                if (destination == null)
                    return null;

                return new ObservableCollection<ETL.ColumnProxy>(destination.Columns);
            }
        }
        public string DseName
        {
            get
            {
                return dseName;
            }
            set
            {
                dseName = value;
                RaisePropertyChanged("DseName");
            }
        }
        public System.Data.DataView PreviewData
        {
            get { return previewData; }
            set
            {
                previewData = value;
                RaisePropertyChanged("PreviewData");
            }
        }
        public RelayCommand<string> DataPreviewCommand
        {
            get
            {
                RelayCommand<string> rc = new RelayCommand<string>(s =>
                    {
                        System.Data.DataTable dt = ModelInterface.ServiceInterfacing.GetJoinData(DseName);
                        PreviewData = dt.DefaultView;
                    },
                    s =>
                    {
                        return (!string.IsNullOrEmpty(s)) &&
                               (ModelInterface.ServiceInterfacing.ContainsEnvelopeName(s));
                    });
                return rc;
            }
        }
        #endregion

        #region DataSourceCollection
        public ObservableCollection<DataSourceViewModel> DataSources
        {
            get
            {

                List<DataSourceViewModel> tmp = ModelInterface.ServiceInterfacing.GetAllSourcesinEnvelope(dseName).ConvertAll<DataSourceViewModel>(d => DataSourceViewModel.GetViewModelfromModel(d));
                ObservableCollection<DataSourceViewModel> ret = new ObservableCollection<DataSourceViewModel>(tmp ?? new List<DataSourceViewModel>());
                return ret;
            }

        }

        #endregion
        #region TreeProperty
        public ObservableCollection<DataSourceViewModel> DataSourceTree
        {
            get
            {
                if (DataSourceViewModel.TreeRoot == null)
                    return null;
                if (!DataSourceViewModel.TreeRoot.ContainsKey(DseName))
                    return null;
                return new ObservableCollection<DataSourceViewModel>(new DataSourceViewModel[] { DataSourceViewModel.TreeRoot[DseName] });
            }
        }

        #endregion
        #region LateBindingMethods
        public static DataSourceEnvelopeViewModel GetViewModelFromModel(ETL.DataSourceEnvelopeProxy dsep)
        {
            DataSourceEnvelopeViewModel dsevm = new DataSourceEnvelopeViewModel();
            dsevm.colTypes = dsep.ColumnTypes;
            dsevm.destination = dsep.Destination;
            dsevm.DataSourceEnvelopeInternal = dsep;
            return dsevm;

        }
        public void Save()
        {
            ETL.DataSourceEnvelopeProxy dsep = new ETL.DataSourceEnvelopeProxy()
            {
                Destination = destination,
                ColumnTypes = colTypes
            };
            ModelInterface.ServiceInterfacing.RegisterDataSourceEnvelope(dsep, dseName);
            ModelInterface.ServiceInterfacing.UpdateDestCaller();
        }
        public void AddDestinationColumn(string columnname, string colexpr, string mapcol, string Actual_ColumnName)
        {
            if (Destination == null)
                destination = new ETL.ColumnSetProxy();
            if (destination.Columns == null)
                destination.Columns = new ETL.ColumnProxy[0] { };
            ETL.ColumnProxy[] Temp = new ETL.ColumnProxy[0] { };
            int i;
            Array.Resize<ETL.ColumnProxy>(ref Temp, destination.Columns.Length);
            destination.Columns.CopyTo(Temp, 0);
            ////for (i = 0; i < destination.Columns.Length; i++)
            ////    Temp[i] = destination.Columns[i];

            if (Temp.Where(s => s.ColumnName == columnname).Count() > 0)
            {
                int idx = Array.FindIndex<ETL.ColumnProxy>(Temp, new Predicate<ETL.ColumnProxy>(c => c.ColumnName == columnname));
                Temp[idx] = new ETL.ColumnProxy() { ColumnName = columnname, ColExpr = colexpr, MapCol = mapcol };
            }
            else
            {
                Array.Resize<ETL.ColumnProxy>(ref Temp, destination.Columns.Length + 1);
                Temp[destination.Columns.Length] = new ETL.ColumnProxy() { ColumnName = columnname, ColExpr = colexpr, MapCol = mapcol };
            }
            destination.Columns = Temp;
            ModelInterface.ServiceInterfacing.SetDestinationColumnsforEnvelope(destination, dseName);
            //RaisePropertyChanged("Destination");
            AddDestinationColumnTypes(Actual_ColumnName, "System.String");
            ModelInterface.ServiceInterfacing.UpdateDestCaller();
            RaisePropertyChanged("Destination");
            RaisePropertyChanged("ColTypes");
            //destination.Columns = new 
        }
        public void AddDestinationColumnTypes(string columnname, string coltype)
        {
            if (ColTypes == null)
                colTypes = new ETL.ColTypeProxy[0] { };
            ETL.ColTypeProxy[] Temp = new ETL.ColTypeProxy[0] { };
            Array.Resize<ETL.ColTypeProxy>(ref Temp, colTypes.Length);
            colTypes.CopyTo(Temp, 0);
            //int i;
            //for (i = 0; i < colTypes.Length; i++)
            //    Temp[i] = colTypes[i];

            if (Temp.Where(s => s.ColName == columnname).Count() > 0)
            {
                int idx = Array.FindIndex<ETL.ColTypeProxy>(Temp, new Predicate<ETL.ColTypeProxy>(c => c.ColName == columnname));
                Temp[idx] = new ETL.ColTypeProxy() { ColName = columnname, ColumnType = coltype };
            }
            else
            {
                Array.Resize<ETL.ColTypeProxy>(ref Temp, colTypes.Length + 1);
                Temp[colTypes.Length] = new ETL.ColTypeProxy() { ColName = columnname, ColumnType = coltype };
            }
            colTypes = Temp;
            ModelInterface.ServiceInterfacing.SetDestinationColumnTypesforEnvelope(new ETL.ColTypeSetProxy() { Columns = colTypes }, dseName);
            //destination.Columns = new 
        }


        #endregion

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ExpressionBuilder;

namespace FIETLClient.View
{
    /// <summary>
    /// Interaction logic for TransformationView.xaml
    /// </summary>
    public partial class TransformationView : UserControl
    {
        public TransformationView()
        {
            InitializeComponent();

        }



        public object Source
        {
            get { return (object)GetValue(SourceProperty); }
            set { SetValue(SourceProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Source.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty SourceProperty =
            DependencyProperty.Register("Source", typeof(object), typeof(TransformationView), new UIPropertyMetadata(null));

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var v = ExpressionBuilder.Controls.ExpressionViewer.GetReplaceExpressionHandler(exBldr);
            ComboBox cb = (ComboBox)sender;
            ExpressionBuilder.Expressions.Expression newExpression = null;
            if (cb.Name == "cbExpressionL")
            {
                newExpression = new ExpressionBuilder.Expressions.LeftValueExpression(exBldr.Expression) { Value = e.AddedItems[0] };
            }
            else if (cb.Name == "cbExpressionR")
            {
                newExpression = new ExpressionBuilder.Expressions.LeftValueExpression(exBldr.Expression) { Value = e.AddedItems[0] };
            }
            if (newExpression != null)
                v.Execute(exBldr.Expression, newExpression);
        }


        private void txExpressionR_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Return)
            {
                var v = ExpressionBuilder.Controls.ExpressionViewer.GetReplaceExpressionHandler(exBldr);
                TextBox cb = (TextBox)sender;
                ExpressionBuilder.Expressions.Expression newExpression = null;
                if (cb.Name == "txExpressionL")
                {
                    newExpression = new ExpressionBuilder.Expressions.LeftValueExpression(exBldr.Expression) { Value = cb.Text };
                }
                else if (cb.Name == "txExpressionR")
                {
                    newExpression = new ExpressionBuilder.Expressions.RightValueExpression(exBldr.Expression) { Value = cb.Text };
                }
                if (newExpression != null)
                    v.Execute(exBldr.Expression, newExpression);
            }
        }


    }
}

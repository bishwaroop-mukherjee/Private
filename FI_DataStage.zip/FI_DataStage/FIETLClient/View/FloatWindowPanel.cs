﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows;
using System.Windows.Media.Animation;

namespace FIETLClient.View
{
    public class FloatWindowPanel : Panel
    {
        public FloatWindowPanel()
        {
            isDragging = false;
            mayDrag = false;
        }
        private bool isDragging;
        private bool mayDrag;
        private bool isMax;
        public bool MayDrag
        {
            get { return mayDrag; }
            set { mayDrag = value; }
        }
        public string Title
        {
            get { return (string)GetValue(TitleProperty); }
            set { SetValue(TitleProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Title.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty TitleProperty =
            DependencyProperty.Register("Title", typeof(string), typeof(FloatWindowPanel), new UIPropertyMetadata(string.Empty));




        public System.Windows.Media.FontFamily TitleFont
        {
            get { return (System.Windows.Media.FontFamily)GetValue(TitleFontProperty); }
            set { SetValue(TitleFontProperty, value); }
        }

        // Using a DependencyProperty as the backing store for TitleFont.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty TitleFontProperty =
            DependencyProperty.Register("TitleFont", typeof(System.Windows.Media.FontFamily), typeof(FloatWindowPanel), new UIPropertyMetadata(null));

        protected override void OnMouseLeftButtonDown(System.Windows.Input.MouseButtonEventArgs e)
        {
            if (isMax) return;
            System.Windows.Rect r = new System.Windows.Rect(new System.Windows.Point(0, 0),
                                                            new System.Windows.Size(this.Width, 20));
            if (!MayDrag)
                if (r.Contains(new Rect(e.GetPosition(this), new Size(1, 1))))
                    mayDrag = true;
            base.OnMouseLeftButtonDown(e);
        }

        protected override void OnMouseWheel(System.Windows.Input.MouseWheelEventArgs e)
        {
            base.OnMouseWheel(e);
            //mayDrag = false;
            //isMax = true;

        }

        double _normalSpace = 0.0;
        double _extraSpace = 0.0;

        protected override Size MeasureOverride(Size availableSize)
        {
            // first pass to evaluate DesiredSize given available size:
            foreach (UIElement child in Children)
                child.Measure(availableSize);

            // now determine the "normal" size:
            var sortedChildren = Children.Cast<UIElement>().OrderBy<UIElement, double>(child => child.DesiredSize.Height);
            double remainingSpace = availableSize.Height;
            int remainingChildren = Children.Count;
            foreach (UIElement child in sortedChildren)
            {
                _normalSpace = remainingSpace / remainingChildren;
                if (child.DesiredSize.Height < _normalSpace) // if == there would be no point continuing as there would be no remaining space
                    remainingSpace -= child.DesiredSize.Height;
                else
                {
                    remainingSpace = 0;
                    break;
                }
                remainingChildren--;
            }
            // there will be extra space if every child fits and the above loop terminates normally:
            _extraSpace = remainingSpace / Children.Count; // divide the remaining space up evenly among all children

            // second pass to give each child its proper available size:
            foreach (UIElement child in Children)
                child.Measure(new Size(availableSize.Width, _normalSpace));

            return availableSize;
        }

        protected override System.Windows.Size ArrangeOverride(System.Windows.Size finalSize)
        {
            double offset = 0.0;
            double value = 0.0;
            Canvas w;
            IEnumerable<UIElement> Ts = Children.Cast<UIElement>().Where(e => e.GetType().Equals(typeof(Canvas)) && ((Canvas)e).Name == Title);

            if (Ts != null && Ts.Count() > 0)
            {
                w = (Canvas)Ts.First();
                w.Width = finalSize.Width;

            }
            else
            {
                w = new Canvas();
                w.Width = finalSize.Width;
                w.Height = 20;
                //Title Text
                Label lblTitle = new Label();
                lblTitle.Content = Title;
                lblTitle.FontSize = 12;
                lblTitle.VerticalContentAlignment = System.Windows.VerticalAlignment.Top;
                lblTitle.Padding = new Thickness(0);
                lblTitle.Margin = new Thickness(0);
                Canvas.SetLeft(lblTitle, 46);
                Canvas.SetTop(lblTitle, 2);
                lblTitle.Height = 16;
                w.Children.Add(lblTitle);

                //Expand Button
                Button butExp = new Button();
                butExp.Content = "<>";
                butExp.Click += new RoutedEventHandler(butExp_Click);
                //Canvas.SetLeft(butExp, this.Width - 20);
                //Canvas.SetTop(butExp, 2);
                butExp.Height = 18;
                butExp.Width = 18;
                butExp.Background = new SolidColorBrush(Colors.Transparent);
                butExp.HorizontalAlignment = System.Windows.HorizontalAlignment.Right;
                w.Children.Add(butExp);

                //Contract Button
                Button butCont = new Button();
                butCont.Content = "><";
                butCont.Click += new RoutedEventHandler(butCont_Click);
                Canvas.SetLeft(butCont, 20);
                butCont.Height = 18;
                butCont.Width = 18;
                butCont.Background = new SolidColorBrush(Colors.Transparent);
                butCont.HorizontalAlignment = System.Windows.HorizontalAlignment.Right;
                w.Children.Add(butCont);


                LinearGradientBrush brs = new LinearGradientBrush();
                GradientStopCollection grsc = new GradientStopCollection();
                brs.GradientStops.Add(new GradientStop(Color.FromRgb(255, 255, 255), 0.2));
                brs.GradientStops.Add(new GradientStop(Color.FromRgb(127, 127, 255), 0.8));
                brs.StartPoint = new Point(0, 0);
                brs.EndPoint = new Point(0, 1);
                w.Background = brs;
                w.Name = Title;
                Children.Add(w);
            }

            w.Arrange(new Rect(0, 0, finalSize.Width, 20));

            IEnumerable<UIElement> childrenminustitle = Children.Cast<UIElement>().Where(child => !(child.GetType() == typeof(Canvas) && ((Canvas)child).Name == Title));
            foreach (UIElement child in childrenminustitle)
            {
                value = Math.Min(child.DesiredSize.Height, _normalSpace) + _extraSpace;
                child.Arrange(new Rect(0, 20 + offset, finalSize.Width, value));
                offset += value;
            }

            return finalSize;
        }

        private void ContractWindowby10()
        {
            FloatWindowManager fwm = (FloatWindowManager)this.Parent;
            //this.RenderSize = new Size(fwm.ActualWidth, fwm.ActualHeight);
            if (this.Width >= 110)
            {
                this.Width = this.Width - 10;
                this.Height = this.Height - 5;
            }
        }
        void butCont_Click(object sender, RoutedEventArgs e)
        {
            ContractWindowby10();
        }

        private void ExpandWindow()
        {
            FloatWindowManager fwm = (FloatWindowManager)this.Parent;
            //this.RenderSize = new Size(fwm.ActualWidth, fwm.ActualHeight);
            Canvas.SetLeft(this, 0);
            Canvas.SetTop(this, 0);
            this.Width = fwm.ActualWidth;
            this.Height = fwm.ActualHeight;

        }
        void butExp_Click(object sender, RoutedEventArgs e)
        {
            ExpandWindow();
        }
    }
}

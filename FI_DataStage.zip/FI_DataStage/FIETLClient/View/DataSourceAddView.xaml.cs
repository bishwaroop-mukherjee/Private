﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FIETLClient.View
{
    /// <summary>
    /// Interaction logic for DataSourceAddView.xaml
    /// </summary>
    public partial class DataSourceAddView : UserControl
    {
        public DataSourceAddView()
        {
            InitializeComponent();
        }





        public string DseName
        {
            get { return (string)GetValue(DseNameProperty); }
            set { SetValue(DseNameProperty, value); }
        }

        // Using a DependencyProperty as the backing store for DseName.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty DseNameProperty =
            DependencyProperty.Register("DseName", typeof(string), typeof(DataSourceAddView), new UIPropertyMetadata(""));




    }
}

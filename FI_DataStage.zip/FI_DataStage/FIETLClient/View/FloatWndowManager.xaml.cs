﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using System.Collections;
using DevExpress.Xpf.Docking;

namespace FIETLClient.View
{
    /// <summary>
    /// Interaction logic for FloatWndow.xaml
    /// </summary>
    public partial class FloatWindowManager : Canvas
    {
        public FloatWindowManager()
        {
            InitializeComponent();

        }

        public new IEnumerable ItemsSource
        {
            get { return (IEnumerable)GetValue(ItemsSourceProperty); }
            set { SetValue(ItemsSourceProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ItemsSource.  This enables animation, styling, binding, etc...
        public static readonly new DependencyProperty ItemsSourceProperty =
            DependencyProperty.Register("ItemsSource", typeof(IEnumerable), typeof(FloatWindowManager), new FrameworkPropertyMetadata(null,
            new PropertyChangedCallback(FloatWindowManager.OnItemsSourceChanged)));

        public DataTemplate ItemTemplate
        {
            get { return (DataTemplate)GetValue(ItemTemplateProperty); }
            set { SetValue(ItemTemplateProperty, value); }
        }
        public static readonly DependencyProperty ItemTemplateProperty =
        DependencyProperty.Register("ItemTemplate", typeof(DataTemplate), typeof(FloatWindowManager), new UIPropertyMetadata(null));





        public static void OnItemsSourceChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            FloatWindowManager fw = (FloatWindowManager)d;
            UIElement fg;
            IEnumerable its = (IEnumerable)e.NewValue;
            //if (fw.ItemTemplate != null)
            //{
            FloatGroupCollection fgc = new FloatGroupCollection();
            fw.ItemsSource.Cast<dynamic>().ToList().ForEach(o =>
                {
                    DataTemplateSelector ts = new DataTemplateSelector();

                    if (fw.ItemTemplate != null)
                        fg = (UIElement)fw.ItemTemplate.LoadContent();
                    else
                    {
                        DataTemplate dt;
                        var key = new System.Windows.DataTemplateKey(o.GetType());
                        dt = (DataTemplate)fw.TryFindResource(key);

                        if (dt == null)
                            throw new Exception("No Data Template found for the ItemsSource");
                        fg = (UIElement)dt.LoadContent();
                    }

                    if (fw.Children.Cast<FloatWindowPanel>().Where(c => c.Name == o.Name).Count() <= 0)
                    {
                        FloatWindowPanel WinFrame = new FloatWindowPanel();
                        Canvas.SetLeft(WinFrame, 0);
                        Canvas.SetTop(WinFrame, 0);
                        WinFrame.Width = 100;
                        WinFrame.Height = 100;
                        WinFrame.Name = o.Name;
                        WinFrame.Title = o.Name;
                        WinFrame.DataContext = o;
                        fw.Children.Add(WinFrame);
                        Border WinBorder = new Border();
                        WinBorder.BorderThickness = new Thickness(2);
                        WinBorder.BorderBrush = System.Windows.Media.Brushes.SlateGray;
                        WinFrame.Children.Add(WinBorder);
                        WinBorder.Child = fg;
                    }
                });
            //}

        }
        FloatWindowPanel Dragging = null;
        System.Windows.Point lastPos;
        protected override void OnMouseLeftButtonDown(MouseButtonEventArgs e)
        {
            base.OnMouseLeftButtonDown(e);
            if (Dragging == null)
            {
                IEnumerable<FloatWindowPanel> fs = Children.Cast<FloatWindowPanel>().Where(f => f.MayDrag);
                if (fs != null && fs.Count() > 0)
                    Dragging = fs.First();
            }
            lastPos = e.GetPosition(this);
        }
        protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e)
        {
            base.OnMouseLeftButtonUp(e);
            if (Dragging != null)
            {
                Dragging.MayDrag = false;
                Dragging = null;
            }
        }
        protected override void OnMouseLeave(MouseEventArgs e)
        {
            base.OnMouseLeave(e);
            if (Dragging != null)
            {
            }
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);
            if (Dragging != null)
            {
                double l = Canvas.GetLeft(Dragging);
                double r = Canvas.GetTop(Dragging);
                Point curPos = new Point(l, r);
                Point pos = e.GetPosition(this);
                curPos.Offset(pos.X - lastPos.X, pos.Y - lastPos.Y);
                Canvas.SetLeft(Dragging, curPos.X);
                Canvas.SetTop(Dragging, curPos.Y);
                lastPos = pos;
            }
        }
    }
}

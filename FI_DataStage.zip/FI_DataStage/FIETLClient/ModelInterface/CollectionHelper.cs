﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace System.Collections.Generic
{
    class StringHash<T> : Dictionary<string, List<T>>
    {
        public delegate bool StringHashComparer(T x, string v);

        StringHashComparer comparer;
        #region Constructors
        public StringHash()
            : base()
        {
            comparer = new StringHashComparer((d, s) => d.ToString() == s);
        }
        public StringHash(StringHashComparer comp)
            : base()
        {
            comparer = comp;
        }
        public StringHash(int capacity)
            : base(capacity)
        {
        }
        public StringHash(IEqualityComparer<string> comparer)
            : base(comparer)
        {
        }
        public StringHash(int capacity, IEqualityComparer<string> comparer)
            : base(capacity, comparer)
        {
        }
        public StringHash(IDictionary<string, List<T>> dictionary)
            : base(dictionary)
        {
        }
        public StringHash(IDictionary<string, List<T>> dictionary, IEqualityComparer<string> comparer)
            : base(dictionary, comparer)
        {
        }
        #endregion

        public void Add(string Key, T data)
        {
            List<T> list;
            if (!base.ContainsKey(Key))
            {
                base.Add(Key, new List<T>(new T[] { data }));
            }
            else
            {
                list = base[Key];
                list.Add(data);
            }
        }
        public IEnumerable<T> GetValues(string Key, string CompValue)
        {
            return base[Key].Where(L =>
            {
                return comparer(L, CompValue);
            });
        }

        public T GetFirstValue(string Key, string CompValue)
        {

            return base[Key].Where(L =>
            {
                return comparer(L, CompValue);
            }).First();
        }
        public bool Contains(string Key, string CompValue)
        {
            if (!base.ContainsKey(Key)) return false;

            IEnumerable<T> l = base[Key].Where(L =>
            {
                return comparer(L, CompValue);
            });


            return (l != null && l.Count() > 0);
        }

        public bool ContainsBucket(string Key)
        {
            return base.ContainsKey(Key);
        }
        public IEnumerable<T> GetAll(string Key)
        {
            if (!base.ContainsKey(Key))
                return null;
            return base[Key];
        }

    }
}

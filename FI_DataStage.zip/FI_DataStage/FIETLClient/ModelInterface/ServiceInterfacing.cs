﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Collections;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using FIETLClient.FIETLWCFService;


namespace FIETLClient.ModelInterface
{
    public static class ServiceInterfacing
    {
        #region UpdateLogic
        public delegate void UpdateDestinationHandler();
        public static UpdateDestinationHandler UpdateDestCaller;
        #endregion


        private static Dictionary<string, DataSourceEnvelopeProxy> RegisteredEnvelopes = new Dictionary<string, DataSourceEnvelopeProxy>();
        private static StringHash<DataSourceProxy> RegisteredDataSources = new StringHash<DataSourceProxy>(
                                                                                new StringHash<DataSourceProxy>.StringHashComparer(
                                                                                    (d, s) => d.TableName == s
                                                                                    ));
        private static StringHash<TransformationContainerProxy> RegisteredTransformations = new StringHash<TransformationContainerProxy>(
                                                                                new StringHash<TransformationContainerProxy>.StringHashComparer(
                                                                                    (d, s) => d.TransActor.Name == s
                                                                                    ));
        private static DataStageETLServiceClient EtlServiceChannel = new DataStageETLServiceClient();

        public static void RegisterDataSourceEnvelope(DataSourceEnvelopeProxy dsep, string name)
        {
            if (RegisteredEnvelopes.ContainsKey(name))
                throw new Exception("Join of this name (" + name + ") already exists in the transformation");
            if (dsep == null) return;
            if (string.IsNullOrEmpty(name)) return;

            EtlServiceChannel.AddData(dsep, name);
            RegisteredEnvelopes.Add(name, dsep);
            if (UpdateDestCaller != null)
                UpdateDestCaller.Invoke();
        }
        public static void SetDestinationColumnsforEnvelope(ColumnSetProxy cols, string dsename)
        {
            RegisteredEnvelopes[dsename].Destination = cols;
            EtlServiceChannel.AddDestinationColumntoEnvelope(cols, dsename);
        }
        public static ColTypeProxy[] GetDestinationColumnTypesforEnvelope(string dsename)
        {
            return RegisteredEnvelopes[dsename].ColumnTypes;
        }
        public static ColumnSetProxy GetDestinationColumnsforEnvelope(string dsename)
        {
            return RegisteredEnvelopes[dsename].Destination;
        }
        public static void SetDestinationColumnTypesforEnvelope(ColTypeSetProxy coltypes, string dsename)
        {
            RegisteredEnvelopes[dsename].ColumnTypes = coltypes.Columns.ToArray();
            EtlServiceChannel.AddColTypetoEnvelope(coltypes, dsename);
        }
        public static bool ContainsEnvelopeName(string envelopename)
        {
            return RegisteredEnvelopes.ContainsKey(envelopename);
        }
        public static bool ContainsTransformation(string transname)
        {
            return RegisteredTransformations.ContainsKey(transname);
        }
        public static void RegisterDataSourceWithEnvelope(string envelopeName, DataSourceProxy data)
        {
            if (RegisteredDataSources.Contains(envelopeName, data.TableName))
            {
                throw new Exception("Datasource of this name (" + data.TableName + ") already exists in the join");
            }

            if (!(!RegisteredDataSources.ContainsBucket(envelopeName) || RegisteredDataSources[envelopeName].Count <= 0))
                throw new Exception("Need join details to add this datasource");

            RegisteredDataSources.Add(envelopeName, data);

        }

        public static void RegisterDataSourceWithEnvelope(string envelopeName, DataSourceProxy data, string connecttoTable, IDTypeProxy PID, IDTypeProxy CID, JoinType jn)
        {
            if (RegisteredDataSources.Contains(envelopeName, data.TableName))
            {
                throw new Exception("Datasource of this name (" + data.TableName + ") already exists in the join");
            }

            //if (!RegisteredDataSources.ContainsBucket(envelopeName) || RegisteredDataSources[envelopeName].Count <= 0)
            //    EtlServiceChannel.AddFirstDataSourcetoEnvelope(data, envelopeName);
            //else
            //    EtlServiceChannel.AddDataSourcetoEnvelope(data, envelopeName, connecttoTable, PID, CID, jn);

            RegisteredDataSources.Add(envelopeName, data);

        }

        public static void ModifyJoin(string envelopeName, DataSourceProxy data, string connecttoTable, IDTypeProxy PID, IDTypeProxy CID, JoinType jn)
        {
            //if (RegisteredDataSources.Contains(envelopeName, data.TableName))
            //{
            //    throw new Exception("Datasource of this name (" + data.TableName + ") already exists in the join");
            //}

            //if (!RegisteredDataSources.ContainsBucket(envelopeName) || RegisteredDataSources[envelopeName].Count <= 0)
            //{
            //    throw new Exception("Datasource of this name (" + data.TableName + ") does not exist in the join");
            //}

            //EtlServiceChannel.ModifyJoin(data, envelopeName, connecttoTable, PID, CID, jn);

            //RegisteredDataSources.Add(envelopeName, data);

        }

        public static List<DataSourceProxy> GetAllSourcesinEnvelope(string envelopename)
        {
            List<DataSourceProxy> l;
            IEnumerable<DataSourceProxy> il = RegisteredDataSources.GetAll(envelopename);
            if (il != null)
                l = il.ToList();
            else
                l = new List<DataSourceProxy>();

            return l;
        }

        public static List<ViewModel.DataSourceEnvelopeViewModel> GetAllEnvelopes()
        {
            List<ViewModel.DataSourceEnvelopeViewModel> l;
            if (RegisteredEnvelopes == null || RegisteredEnvelopes.Count < 1)
                l = new List<ViewModel.DataSourceEnvelopeViewModel>();
            else
                l = RegisteredEnvelopes.Select(kpd => new ViewModel.DataSourceEnvelopeViewModel() { DseName = kpd.Key }).ToList();
            return l;
        }

        public static List<ViewModel.TransformationViewModel> GetAllTransformations()
        {
            List<ViewModel.TransformationViewModel> l;
            if (RegisteredEnvelopes == null || RegisteredEnvelopes.Count < 1)
                l = new List<ViewModel.TransformationViewModel>();
            else
                l = RegisteredTransformations.Select(kpd => new ViewModel.TransformationViewModel() { TransName = kpd.Value[0].TransActor.Name, TransCategory = kpd.Value[0].TransActor.Category, Params = kpd.Value[0].TransActor.Parameters, Inputs = kpd.Value[0].Inputs == null ? null : kpd.Value[0].Inputs.ToList<string>() }).ToList();
            return l;
        }

        public static List<string> GetDataSourceSchema(DataSourceProxy dsp)
        {
            return new List<string>(EtlServiceChannel.GetDataSchemaFromSource(dsp));
        }

        public static DataTable GetJoinData(string dseName)
        {

            List<DataNode> DataSeq = ViewModel.DataSourceViewModel.GetJoinSequence(dseName);
            EtlServiceChannel.AddDataSourceSequence(DataSeq.ToArray(), dseName);

            DataTable retData = EtlServiceChannel.JoinTables(dseName);
            return retData;
        }
        public static void RegisterAllDSEs()
        {
            if (RegisteredEnvelopes == null || RegisteredEnvelopes.Count == 0 || RegisteredDataSources == null || RegisteredDataSources.Count == 0)
                throw new Exception("No Data Source exists");
            RegisteredEnvelopes.ToList().ForEach(ek =>
                {
                    List<DataNode> DataSeq = ViewModel.DataSourceViewModel.GetJoinSequence(ek.Key);
                    EtlServiceChannel.AddDataSourceSequence(DataSeq.ToArray(), ek.Key);
                });
        }

        public static DataTable GetTransformationData()
        {
            DataTable dtRet = null;

            try
            {
                RegisterAllDSEs();
                LoadAllTransformations();
                dtRet = EtlServiceChannel.GetTransformationData();
            }
            catch (Exception) { }

            return dtRet;
        }

        public static List<string> GetTransformationCategories()
        {
            IEnumerable<string> lst = EtlServiceChannel.GetTransFormationCategories();
            return lst.ToList();
        }

        public static void RegisterTransformation(TransformationContainerProxy txcp)
        {
            if (!RegisteredTransformations.ContainsBucket(txcp.TransActor.Name))
                RegisteredTransformations.Add(txcp.TransActor.Name, txcp);
            else
            {
                RegisteredTransformations.Remove(txcp.TransActor.Name);
                RegisteredTransformations.Add(txcp.TransActor.Name, txcp);
            }
            //EtlServiceChannel.AddTransformation(txcp, txcp.TransActor.Name);
        }

        public static void LoadAllTransformations()
        {
            try
            {

                if (RegisteredTransformations == null || RegisteredTransformations.Count == 0)
                    throw new Exception("There are no Transformations registered");

                EtlServiceChannel.AddTransformationCollection((from k in RegisteredTransformations
                                                               select k.Value.First()).ToArray());
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ExpressCon
{
    public partial class FieldView : UserControl
    {
        private DataTable DSrc;
        private List<ExpField> fields;
        private bool wasClicked;
        private ExpField field;
        public DataTable DataSource
        {
            get
            {
                return DSrc;
            }
            set
            {
                DSrc = value;
                if (DSrc != null)
                {
                    fields = new List<ExpField>();
                    foreach (DataColumn dtc in DSrc.Columns)
                    {
                        fields.Add(new ExpField("[" + dtc.ColumnName + "]", dtc.DataType));
                        fList.Items.Add(dtc.ColumnName);
                    }
                }
            }
        }

        public ExpField Field
        {
            get
            {
                return field;
            }
        }
        public FieldView()
        {
            InitializeComponent();
            field = new ExpField("",typeof(Object));
            wasClicked = false;
        }

        public delegate void AfterSelectCommitedEvHandler(object sender, ListAfterSelectEventArgs e);

        // Declare the event.
        public event AfterSelectCommitedEvHandler AfterSelectCommitedEvent;

        // Wrap the event in a protected virtual method
        // to enable derived classes to raise the event.
        protected virtual void RaiseAfterSelectCommitedEH()
        {
            // Raise the event by using the () operator.
            if (AfterSelectCommitedEvent != null)
                AfterSelectCommitedEvent(this, new ListAfterSelectEventArgs("Hello"));
        }

        private void fList_MouseDown(object sender, MouseEventArgs e)
        {
            wasClicked = true;
        }

        private void fList_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (wasClicked)
            {
                field = fields[fList.SelectedIndex];
                RaiseAfterSelectCommitedEH();
                wasClicked = false;
            }
        }
    }

    public class ListAfterSelectEventArgs : EventArgs
    {
        public ListAfterSelectEventArgs(string s) { Func = s; }
        public String Func { get; private set; } // readonly
    }

    public struct  ExpField
    {
        public string fName;
        public Type  fType;

        public ExpField(string name, Type type)
        {
            fName = name;
            fType = type;
        }
    }
}

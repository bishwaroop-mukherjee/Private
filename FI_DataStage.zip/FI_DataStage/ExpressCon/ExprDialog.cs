﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ExpressCon
{
    public partial class ExprDialog : Form
    {
        public ExprDialog(ref DataTable dt,string ColName)
        {
            InitializeComponent();
            exprBuilder1.ColName = ColName;
            exprBuilder1.DataSource  = dt;
        }


        public void setData(ref DataTable dt)
        {
            exprBuilder1.DataSource = dt;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                ExpressionView.expression = exprBuilder1.Expression;
                DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void ExprDialog_Load(object sender, EventArgs e)
        {

        }
    }
}

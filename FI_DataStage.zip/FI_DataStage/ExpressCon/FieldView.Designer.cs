﻿namespace ExpressCon
{
    partial class FieldView
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.fList = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // fList
            // 
            this.fList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fList.FormattingEnabled = true;
            this.fList.Location = new System.Drawing.Point(0, 0);
            this.fList.Name = "fList";
            this.fList.Size = new System.Drawing.Size(225, 242);
            this.fList.TabIndex = 0;
            this.fList.SelectedIndexChanged += new System.EventHandler(this.fList_SelectedIndexChanged);
            this.fList.MouseDown += new System.Windows.Forms.MouseEventHandler(this.fList_MouseDown);
            // 
            // FieldView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.fList);
            this.Name = "FieldView";
            this.Size = new System.Drawing.Size(225, 242);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox fList;
    }
}

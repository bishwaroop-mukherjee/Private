﻿namespace ExpressCon
{
    partial class ExprBuilder
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.ftvFunctions = new ExpressCon.FunctionTreeView();
            this.fvFields = new ExpressCon.FieldView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.opView = new ExpressCon.OperatorView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblVal = new System.Windows.Forms.Label();
            this.txtExpr = new System.Windows.Forms.RichTextBox();
            this.cmWrapText = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.wrapTextToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.cmWrapText.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel2, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.txtExpr, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 72.1519F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 27.8481F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 183F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(528, 342);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 138F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 206F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 196F));
            this.tableLayoutPanel2.Controls.Add(this.ftvFunctions, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.fvFields, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.panel1, 2, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 158);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(528, 184);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // ftvFunctions
            // 
            this.ftvFunctions.Location = new System.Drawing.Point(141, 3);
            this.ftvFunctions.Name = "ftvFunctions";
            this.ftvFunctions.Size = new System.Drawing.Size(200, 178);
            this.ftvFunctions.TabIndex = 0;
            this.ftvFunctions.AfterSelectCommitedEvent += new ExpressCon.FunctionTreeView.AfterSelectCommitedEvHandler(this.ftvFunctions_AfterSelectCommitedEvent);
            // 
            // fvFields
            // 
            this.fvFields.DataSource = null;
            this.fvFields.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fvFields.Location = new System.Drawing.Point(3, 3);
            this.fvFields.Name = "fvFields";
            this.fvFields.Size = new System.Drawing.Size(132, 178);
            this.fvFields.TabIndex = 1;
            this.fvFields.AfterSelectCommitedEvent += new ExpressCon.FieldView.AfterSelectCommitedEvHandler(this.fvFields_AfterSelectCommitedEvent);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.opView);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(347, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(190, 178);
            this.panel1.TabIndex = 2;
            // 
            // opView
            // 
            this.opView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.opView.Location = new System.Drawing.Point(0, 0);
            this.opView.Name = "opView";
            this.opView.Size = new System.Drawing.Size(190, 178);
            this.opView.TabIndex = 0;
            this.opView.AfterSelectCommitedEvent += new ExpressCon.OperatorView.AfterSelectCommitedEvHandler(this.opView_AfterSelectCommitedEvent);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lblVal);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(3, 117);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(522, 38);
            this.panel2.TabIndex = 2;
            // 
            // lblVal
            // 
            this.lblVal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblVal.Location = new System.Drawing.Point(0, 0);
            this.lblVal.Name = "lblVal";
            this.lblVal.Size = new System.Drawing.Size(522, 38);
            this.lblVal.TabIndex = 0;
            // 
            // txtExpr
            // 
            this.txtExpr.AcceptsTab = true;
            this.txtExpr.AutoWordSelection = true;
            this.txtExpr.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtExpr.Location = new System.Drawing.Point(3, 3);
            this.txtExpr.Name = "txtExpr";
            this.txtExpr.ShowSelectionMargin = true;
            this.txtExpr.Size = new System.Drawing.Size(522, 108);
            this.txtExpr.TabIndex = 3;
            this.txtExpr.Text = "";
            this.txtExpr.TextChanged += new System.EventHandler(this.txtExpr_TextChanged);
            // 
            // cmWrapText
            // 
            this.cmWrapText.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.wrapTextToolStripMenuItem});
            this.cmWrapText.Name = "cmWrapText";
            this.cmWrapText.Size = new System.Drawing.Size(137, 26);
            // 
            // wrapTextToolStripMenuItem
            // 
            this.wrapTextToolStripMenuItem.Name = "wrapTextToolStripMenuItem";
            this.wrapTextToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.wrapTextToolStripMenuItem.Text = "Wrap Text";
            this.wrapTextToolStripMenuItem.Click += new System.EventHandler(this.wrapTextToolStripMenuItem_Click_1);
            // 
            // ExprBuilder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "ExprBuilder";
            this.Size = new System.Drawing.Size(528, 342);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.cmWrapText.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ContextMenuStrip cmWrapText;
        private System.Windows.Forms.ToolStripMenuItem wrapTextToolStripMenuItem;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private FunctionTreeView ftvFunctions;
        private FieldView fvFields;
        private System.Windows.Forms.Panel panel1;
        private OperatorView opView;
        private System.Windows.Forms.RichTextBox txtExpr;
        private System.Windows.Forms.Label lblVal;
    }
}

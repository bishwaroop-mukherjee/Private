﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExpressCon
{
    public class ExpressionView
    {
        public static string expression;
        public static string ExpressionBuilder(ref System.Data.DataTable src,string ColName)
        {
            
            System.Windows.Forms.Form f = new ExprDialog(ref src, ColName);
            
            if (f.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                return expression;
            }
            else
            {
                return "";
            }
        }
    }
}

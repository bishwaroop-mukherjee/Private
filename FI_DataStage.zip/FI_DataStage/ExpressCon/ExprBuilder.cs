﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ExpressCon
{
    public partial class ExprBuilder : UserControl
    {
        DataColumn work;
        string _Colname;
        bool txtwrap = false;
        public static int Num=0;
        public ExprBuilder()
        {
            InitializeComponent();
            ExprBuilder.Num++;
        }
        public string ColName
        {
            get { return _Colname; }
            set { _Colname = value; }
        }
        public String Expression
        {
            get
            {
                return txtExpr.Text;
            }
            private set{}
        }

        public DataTable DataSource
        {
            get 
            {
                return fvFields.DataSource;
            }
            set 
            {
                if (value == null)
                {
                    fvFields.DataSource = null;
                    return;
                }
                if (_Colname != null)
                {
                    try
                    {
                        work = ((DataTable)value).Columns.Add(_Colname);
                        fvFields.DataSource = value;
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                }
                else
                    throw new Exception("No column name specified");
            }
        }

        private void ftvFunctions_AfterSelectCommitedEvent(object sender, AfterSelectEventArgs e)
        {
            int OldPos = txtExpr.SelectionStart;
            txtExpr.SelectedText = ftvFunctions.Function;
            txtExpr.SelectionStart = OldPos + ftvFunctions.Function.CursorFinalPos;
            txtExpr.Focus();
        }

        private void fvFields_AfterSelectCommitedEvent(object sender, ListAfterSelectEventArgs e)
        {
            txtExpr.SelectedText = fvFields.Field.fName;
        }

        private void wrapTextToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void wrapTextToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            txtwrap = txtExpr.WordWrap = !txtwrap;
        }


        private void opView_AfterSelectCommitedEvent(object sender, AfterSelectEventArgsOp e)
        {
            txtExpr.SelectedText = " " + opView.Operator.Operator + " ";
        }

        private void txtExpr_TextChanged(object sender, EventArgs e)
        {
            
            try
            {

                work.Expression = txtExpr.Text;
                System.Drawing.Font fnt = new System.Drawing.Font(txtExpr.Font,FontStyle.Regular );
                
                txtExpr.ForeColor = Color.Green;
                txtExpr.Font = fnt;
                
            }
            catch (Exception ex)
            {
                System.Drawing.Font fnt = new System.Drawing.Font(txtExpr.Font,FontStyle.Underline|FontStyle.Italic  );
                txtExpr.ForeColor = Color.Red;
                txtExpr.Font = fnt;
                lblVal.Text = ex.Message;
            }
            
        }
    }

    public class ExpressionB
    {
        public string Expression;
        public string Type;
    }
}

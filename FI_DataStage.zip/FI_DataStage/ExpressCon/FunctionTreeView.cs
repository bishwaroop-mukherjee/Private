﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ExpressCon
{
    public partial class FunctionTreeView : UserControl 
    {
        FunctionBuilder func;
        bool wasClicked;
        public FunctionBuilder Function
        {
            get
            {
                return func;
            }
        }

        public FunctionTreeView()
        {
            InitializeComponent();

            func = "";
            wasClicked = false;
        }

        private void fTree_AfterSelect(object sender, TreeViewEventArgs e)
        {
          
        }
        private void fTree_MouseDown(object sender, MouseEventArgs e)
        {
            wasClicked = true;
        }

        public delegate void AfterSelectCommitedEvHandler(object sender, AfterSelectEventArgs e);

        // Declare the event.
        public event AfterSelectCommitedEvHandler AfterSelectCommitedEvent;

        // Wrap the event in a protected virtual method
        // to enable derived classes to raise the event.
        protected virtual void RaiseAfterSelectCommitedEH()
        {
            // Raise the event by using the () operator.
            if (AfterSelectCommitedEvent != null)
                AfterSelectCommitedEvent(this, new AfterSelectEventArgs("Hello"));
        }

        private void fTree_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            if (wasClicked)
            {
                if (e.Node.Level == 0)
                {
                    return;
                }
                if (e.Node.Name == "fIIF")
                {
                    func = "IIF(|,,)";
                }
                else if (e.Node.Name == "fUPPER")
                {
                    func = "UPPER(|)";
                } 
                else if (e.Node.Name == "fLOWER")
                {
                    func = "LOWER(|)";
                }
                else if (e.Node.Name == "fAVG")
                {
                    func = "AVG(|)";
                }
                else if (e.Node.Name == "fSUM")
                {
                    func = "SUM(|)";
                }
                else if (e.Node.Name == "fCOUNT")
                {
                    func = "COUNT(|)";
                }
                else if (e.Node.Name == "fMAX")
                {
                    func = "MAX(|)";
                }
                else if (e.Node.Name == "fMIN")
                {
                    func = "MIN(|)";
                }
                else if (e.Node.Name == "fLAST")
                {
                    func = "LAST(|)";
                }
                else if (e.Node.Name == "")
                {

                }
                RaiseAfterSelectCommitedEH();

                wasClicked = false;
            }
        }
    }

    public class AfterSelectEventArgs: EventArgs 
    {
        public AfterSelectEventArgs(string s) { Func = s; }
        public String Func { get; private set; } // readonly
    }

    public class FunctionBuilder
    {
        int CFPos;
        public int CursorFinalPos
        {
            get
            {
                return CFPos;
            }
            set
            {
                CFPos = value;
            }
        }

        String func;
        public FunctionBuilder(string f, int Pos)
        {
            func = f;
            CFPos = Pos;
        }
        enum FType
        {
            OperatorUnary,
            OperatorBinary,
            Function
        }
        FType fType;
        public static implicit operator FunctionBuilder(string f)
        {
            int p;
            p = f.IndexOf("|");
            return new FunctionBuilder(f.Replace("|", ""), p);
        }
        public static implicit operator string(FunctionBuilder f)
        {
            return f.func;
        }

        public override string ToString()
        {
            return func;
        }
    }
}

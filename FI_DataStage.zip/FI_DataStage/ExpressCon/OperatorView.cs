﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ExpressCon
{
    public partial class OperatorView : UserControl
    {
        private string[] Operators = new string[] 
                                                {"+","-","*","/","%",
                                                 "=","<",">","<=",">=","<>"};
        private OperatorV Op;
        public OperatorV Operator
        {
            get
            {
                return Op;
            }
            private set { }

        }
        private int left, top;
        public OperatorView()
        {
            InitializeComponent();
            Button bt;
            int iCnt=0;
            left=top=0;
            foreach(string op in Operators)
            {
                bt = new Button()
                    {
                        Name = "bt" + iCnt.ToString(),
                        Width = this.Width/5 - 2,
                        Height = this.Width /5 - 2,
                        Left = left,
                        Top = top,
                        Text=op,
                    };
                bt.Click += bt_Click;

                if (iCnt >= 0 && iCnt <= 4)
                {
                    bt.Tag = "";
                }
                else if (iCnt >= 5 && iCnt <= 11)
                {
                    bt.Tag = "Bit";
                }

                if (bt.Left + bt.Width >= this.Right)
                {
                    left = 0;
                    top = top + bt.Height + 2;
                    bt.Top = top;
                    bt.Left = left;
                }
                left = left + bt.Width + 2;

                this.Controls.Add(bt);

            }

        }

        private void bt_Click(object sender, EventArgs e)
        {
            Button b=(Button)sender ;
            Op = new OperatorV()
                {
                    Operator = b.Text,
                    RetType = (string)b.Tag
                };

            RaiseAfterSelectCommitedEH();
        }

        private void OperatorView_Load(object sender, EventArgs e)
        {

        }

        public delegate void AfterSelectCommitedEvHandler(object sender, AfterSelectEventArgsOp e);

        // Declare the event.
        public event AfterSelectCommitedEvHandler AfterSelectCommitedEvent;

        // Wrap the event in a protected virtual method
        // to enable derived classes to raise the event.
        protected virtual void RaiseAfterSelectCommitedEH()
        {
            // Raise the event by using the () operator.
            if (AfterSelectCommitedEvent != null)
                AfterSelectCommitedEvent(this, new AfterSelectEventArgsOp("Hello"));
        }

        private void OperatorView_Resize(object sender, EventArgs e)
        {
            left = top = 0;
            foreach (Control c in this.Controls)
            {
                if(this.Width<(c.Width+2)*5 && this.Height<(c.Width+2)*5)
                {
                    c.Width = this.Width / 5 - 2;
                    c.Height = this.Width / 5 - 2;
                }
                c.Left = left;
                c.Top = top;
                if (c.Left + c.Width >= this.Right)
                {
                    left = 0;
                    top = top + c.Height + 2;
                    c.Top = top;
                    c.Left = left;
                }
                left = left + c.Width + 2;
            }
        }

    }

    public class AfterSelectEventArgsOp : EventArgs
    {
        public AfterSelectEventArgsOp(string s) { Func = s; }
        public String Func { get; private set; } // readonly
    }

    public class OperatorV
    {
        public string Operator;
        public string RetType;
    }

}

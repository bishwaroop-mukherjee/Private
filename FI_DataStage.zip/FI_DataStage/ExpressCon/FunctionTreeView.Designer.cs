﻿namespace ExpressCon
{
    partial class FunctionTreeView
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("IIF");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("UPPER");
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("LOWER");
            System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode("Value Functions", new System.Windows.Forms.TreeNode[] {
            treeNode1,
            treeNode2,
            treeNode3});
            System.Windows.Forms.TreeNode treeNode5 = new System.Windows.Forms.TreeNode("AVG");
            System.Windows.Forms.TreeNode treeNode6 = new System.Windows.Forms.TreeNode("SUM");
            System.Windows.Forms.TreeNode treeNode7 = new System.Windows.Forms.TreeNode("COUNT");
            System.Windows.Forms.TreeNode treeNode8 = new System.Windows.Forms.TreeNode("MAX");
            System.Windows.Forms.TreeNode treeNode9 = new System.Windows.Forms.TreeNode("MIN");
            System.Windows.Forms.TreeNode treeNode10 = new System.Windows.Forms.TreeNode("LAST");
            System.Windows.Forms.TreeNode treeNode11 = new System.Windows.Forms.TreeNode("Aggregate Functions", new System.Windows.Forms.TreeNode[] {
            treeNode5,
            treeNode6,
            treeNode7,
            treeNode8,
            treeNode9,
            treeNode10});
            this.fTree = new System.Windows.Forms.TreeView();
            this.SuspendLayout();
            // 
            // fTree
            // 
            this.fTree.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fTree.Location = new System.Drawing.Point(0, 0);
            this.fTree.Name = "fTree";
            treeNode1.Name = "fIIF";
            treeNode1.Text = "IIF";
            treeNode2.Name = "fUPPER";
            treeNode2.Text = "UPPER";
            treeNode3.Name = "fLOWER";
            treeNode3.Text = "LOWER";
            treeNode4.Name = "ValGrp";
            treeNode4.Text = "Value Functions";
            treeNode5.Name = "fAVG";
            treeNode5.Text = "AVG";
            treeNode6.Name = "fSUM";
            treeNode6.Text = "SUM";
            treeNode7.Name = "fCOUNT";
            treeNode7.Text = "COUNT";
            treeNode8.Name = "fMAX";
            treeNode8.Text = "MAX";
            treeNode9.Name = "fMIN";
            treeNode9.Text = "MIN";
            treeNode10.Name = "fLAST";
            treeNode10.Text = "LAST";
            treeNode11.Name = "AggFuncs";
            treeNode11.Text = "Aggregate Functions";
            this.fTree.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode4,
            treeNode11});
            this.fTree.Size = new System.Drawing.Size(167, 216);
            this.fTree.TabIndex = 0;
            this.fTree.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.fTree_AfterSelect);
            this.fTree.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.fTree_NodeMouseClick);
            this.fTree.MouseDown += new System.Windows.Forms.MouseEventHandler(this.fTree_MouseDown);
            // 
            // FunctionTreeView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.fTree);
            this.Name = "FunctionTreeView";
            this.Size = new System.Drawing.Size(167, 216);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TreeView fTree;
    }
}

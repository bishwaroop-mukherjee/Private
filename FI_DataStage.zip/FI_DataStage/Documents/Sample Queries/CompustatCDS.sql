UPDATE DT_FI_CompustatMnthlyAndQtlyData 
SET Qtrly_Cost_of_debt = '0.2' 
WHERE Qtrly_Cost_of_debt IS NULL
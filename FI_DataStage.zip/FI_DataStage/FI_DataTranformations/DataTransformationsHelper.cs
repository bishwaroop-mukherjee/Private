﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Xml.Serialization;
using System.IO;
using FI_DataStage;
using Ionic.Zip;
using System.Runtime.Serialization;

namespace FI_DataTranformations
{
    [DataContract]
    public enum JoinType
    {
        [EnumMember]
        Inner = 0,
        [EnumMember]
        LeftOuter = 1,
        [EnumMember]
        RightOuter = 2,
        [EnumMember]
        Outer = 3,
        [EnumMember]
        Cross = 4
    }
    class DataTransformationsHelper
    {

        public static void SaveTransformationFull(DataTransformations dtTrans, TableTree tablesinjoin, string Filename)
        {
            FileInfo finf = new FileInfo(Filename);
            XmlSerializer xmlS = new XmlSerializer(typeof(DataTransformations));
            XmlSerializer xmlG = new XmlSerializer(typeof(TableTree));
            FileStream fst = new FileStream(finf.DirectoryName + "\\TransFormations.xml", FileMode.CreateNew);
            FileStream fst1 = new FileStream(finf.DirectoryName + "\\TrGui.xml", FileMode.CreateNew);
            //FileStream ZipArchst = new FileStream(finf.FullName,FileMode.CreateNew|FileMode.Truncate );
            //Ionic.Zlib.GZipStream ZipArch = new GZipStream(ZipArchst, CompressionMode.Compress);

            xmlG.Serialize(fst1, tablesinjoin);
            xmlS.Serialize(fst, dtTrans);

            if (File.Exists(finf.FullName))
                File.Delete(finf.FullName);

            Ionic.Zip.ZipFile ZipArch = new ZipFile(finf.FullName);
            ZipArch.AddFile(finf.DirectoryName + "\\TransFormations.xml", "");
            ZipArch.AddFile(finf.DirectoryName + "\\TrGui.xml", "");
            ZipArch.Save();
            fst.Close();
            fst1.Close();
            ZipArch.Dispose();
            File.Delete(finf.DirectoryName + "\\TransFormations.xml");
            File.Delete(finf.DirectoryName + "\\TrGui.xml");
        }
        public static DataTransformations LoadTransformation(string Filename, string TempPath)
        {
            DataTransformations dtTrans;

            FileInfo finf = new FileInfo(Filename);
            ZipFile ZipArch = new ZipFile(finf.FullName);
            DirectoryInfo dinf;
            if (TempPath.Substring(TempPath.Length - 2, 1) != "\\")
                TempPath = TempPath + "\\";
            dinf = Directory.CreateDirectory(TempPath + finf.Name);

            ZipArch.ExtractAll(dinf.FullName);
            XmlSerializer xmlS = new XmlSerializer(typeof(DataTransformations));

            FileStream fst = new FileStream(dinf.FullName + "\\TransFormations.xml", FileMode.Open);
            dtTrans = (DataTransformations)xmlS.Deserialize(fst);
            fst.Close();
            dinf.Delete(true);
            return dtTrans;

        }

        public static TableTree LoadTransformationGUI(string Filename, string TempPath)
        {
            TableTree TrGui;

            FileInfo finf = new FileInfo(Filename);
            ZipFile ZipArch = new ZipFile(finf.FullName);
            DirectoryInfo dinf;
            if (TempPath.Substring(TempPath.Length - 2, 1) != "\\")
                TempPath = TempPath + "\\";
            dinf = Directory.CreateDirectory(TempPath + finf.Name);

            ZipArch.ExtractAll(dinf.FullName);
            XmlSerializer xmlS = new XmlSerializer(typeof(TableTree));

            FileStream fst = new FileStream(dinf.FullName + "\\TrGUI.xml", FileMode.Open);
            TrGui = (TableTree)xmlS.Deserialize(fst);
            fst.Close();
            dinf.Delete(true);
            return TrGui;

        }


        public static Object[] GetNullArray(int Count)
        {
            Object[] Narr = new Object[Count];
            for (int i = 0; i < Count; i++)
                Narr[i] = null;
            return Narr;
        }

        public
        static void Main(string[] args)
        {
            List<DataTable> dtList = new List<DataTable>();

            DataTable dtTemp;

            dtTemp = dtList[0];
            for (int i = 1; i < dtList.Count; i++)
            {
                IEnumerable<IEnumerable<object>> T = from DataRow dR1 in dtTemp.Rows
                                                     join DataRow dR2 in dtList[i].Rows
                                                     on Convert.ChangeType(dR1["ID"], Type.GetType("System.Int32")) equals Convert.ChangeType(dR2["ID"], Type.GetType("System.Int32"))
                                                     select dR1.ItemArray.MergeEnumerable(dR2.ItemArray, new int[] { 0 });

                IEnumerable<DataColumn> C = (from DataColumn dc1 in dtTemp.Columns
                                             select new DataColumn(dc1.ColumnName)).Union(
                                             (IEnumerable<DataColumn>)(from DataColumn dc2 in dtList[i].Columns
                                                                       select new DataColumn(dc2.ColumnName))).Distinct(new DataColEqualityComp());

                dtTemp = new DataTable();
                dtTemp.Columns.AddRange(C.ToArray());
                foreach (IEnumerable<object> R in T)
                {
                    dtTemp.Rows.Add(R.ToArray());
                }
            }
        }
    }

    public class DataColEqualityComp : EqualityComparer<DataColumn>
    {
        public DataColEqualityComp()
        {

        }
        public override bool Equals(DataColumn x, DataColumn y)
        {
            return (x.ColumnName == y.ColumnName);
        }
        public override int GetHashCode(DataColumn obj)
        {
            return 0;
        }
    }

    public static class Extensions
    {
        public static IEnumerable<Object> MergeEnumerable(this IEnumerable<Object> First, IEnumerable<Object> Second, int[] eliminate)
        {
            List<Object> Result = new List<object>();
            List<int> Elim = new List<int>(eliminate);
            Result.AddRange(First);
            int index = 0;
            foreach (Object o in Second)
            {
                if (Elim.IndexOf(index) < 0)
                    Result.Add(o);
                index++;
            }
            return Result.AsEnumerable();
        }

    }


}
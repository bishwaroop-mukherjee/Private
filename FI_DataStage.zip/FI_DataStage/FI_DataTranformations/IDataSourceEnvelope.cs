﻿using System;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
namespace FI_DataTranformations
{
    [ServiceContract]
    interface IDataSourceEnvelope
    {
        [OperationContract]
        void Add(FI_DataStage.DataSourceClass Dsrc, FI_DataStage.IDType PID, FI_DataStage.IDType CID, JoinType jn);
        [OperationContract]
        void ClearColumnsData();
        [OperationContract]
        System.Data.DataTable ExtractTable();
        [OperationContract]
        System.Data.DataTable GetResult();
        [OperationContract]
        DataSourceEnvelope getWorkingTemp();
        [OperationContract]
        System.Data.DataTable Join();
        [OperationContract]
        System.Data.DataTable Project(System.Data.DataTable dtSource);
        [OperationContract]
        void RenameCol(string ColName, string NewColName);
        [OperationContract]
        void SetColType(string ColName, Type type);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Collections.Concurrent;
using System.Linq;
using System.Text;
using FI_DataStage;
using System.Data;
using System.Reflection;
using System.Xml.Serialization;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Threading;

namespace FI_DataTranformations
{
    // Class for transformation logic

    [XmlRoot("DataTransformations")]
    public class DataTransformations : FI_DataTranformations.IDataTransformations
    {
        private string _name;

        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }
        protected List<Transformations.TransformationContainer> _transformations;
        [XmlArray("TransformationList")]
        public List<Transformations.TransformationContainer> TransformationList
        {
            get { return _transformations; }
            set { _transformations = value; }
        }


        /* Should I create a list of JoinPanels internally? LINQ again!!!!! Hell 
         * Yep, I think this is a better idea - This will contain both the Data and GUI (DSE and TableAdded) 
         * We don't need to write this to the project xml. So 'private'.*/
        private List<DataSourceEnvelope> sourceData;
        public List<DataSourceEnvelope> SourceData
        {
            get { return sourceData; }
            set { sourceData = value; }
        }
        /* Intermediate resolved data needs to be stored somewhere - 
         * preferably dictionary */
        private ConcurrentDictionary<string, DataTable> ResolutionBuffer;

        /* No more writing the GUI Separately. - Embedded into the same project.
         * This should go into the project xml. So 'public'.*/
        //[XmlElement("SourceData")]
        //public DataGUIList SourceData
        //{
        //    get
        //    {
        //        var L = from D in DataGUI.AsEnumerable()
        //                select D.DataGUI;
        //        return L.ToList();
        //    }
        //    set
        //    {
        //        DataGUI = new List<UI.JoinPanel>();
        //        ((List<DataGUIEnvelope>)value).ForEach(DGE =>
        //            {
        //                UI.JoinPanel j = new UI.JoinPanel();
        //                j.DataGUI = DGE;
        //                DataGUI.Add(j);
        //            });
        //    }
        //}

        // Methods to perform calculations and get result columns
        // It will contain Linq query 
        public DataTransformations()
        {
            sourceData = new List<DataSourceEnvelope>();
        }

        public void ClearJoinData()
        {
            sourceData = new List<DataSourceEnvelope>();
        }
        public void AddData(DataSourceEnvelope j)
        {
            if (sourceData == null)
                sourceData = new List<DataSourceEnvelope>();
            sourceData.Add(j);
        }

        public void AddTransformations(Transformations.TransformationContainer tr)
        {
            if (TransformationList == null)
            {
                TransformationList = new List<Transformations.TransformationContainer>();
            }
            TransformationList.Add(tr);
        }
        //private DataTable UpdateValue(string key, DataTable dt)
        //{
        //}
        public DataTable ApplyTransformation()
        {
            List<WaitHandle> waitHandles = new List<WaitHandle>();
            /* Data Cannot be created nor destroyed - it can only be transformed
             * The Project must have at least one DataSourceEnvelope with at least one DataSource */
            if (sourceData == null)
                return null;
            int idx;
            if (_transformations != null)
            {
                /* Let us apply compiler theories - 
                 * 1. Resolve the data for every Data Item - DataSources - 
                 * Cannot resolve transformations without an algorithm to create the sequence 
                 * as if a transformation accepts input from another transformation and the list contains 
                 * them in the incorrect order, then the transformation logic will fail.*/

                ResolutionBuffer = new ConcurrentDictionary<string, DataTable>();
                ResolutionBuffer.TryAdd("OP", new DataTable());
                idx = 0;
                sourceData.ForEach(dg =>
                    {
                        ResolutionBuffer.TryAdd("TD:" + idx.ToString(), dg.GetResult());
                        idx++;
                    });

                //Cloning the Transformation list to create a safe list of transactions
                Dictionary<string, Transformations.TransformationContainer> trs = new Dictionary<string, Transformations.TransformationContainer>();
                idx = 0;
                _transformations.ForEach(T =>
                {
                    List<Transformations.TransformationInput> TIs = new List<Transformations.TransformationInput>();
                    T.Inputs.ForEach(TI => TIs.Add((Transformations.TransformationInput)TI.Clone()));
                    trs.Add("TX:" + idx.ToString(), new Transformations.TransformationContainer((Transformations.Transformation)T.TransformationSpec.Clone(), TIs.ToArray()));
                    trs["TX:" + idx.ToString()].SetRefs(ResolutionBuffer);
                    idx++;
                });
                /* Acting on trs - need to create a parse tree/sequence for transformations 
                 * according to the inputs. Only the Devil knows how.*/
                /* 2. Using BFS to resolve the transformation tree - 
                 *      Step 1: Resolve Data Nodes
                 *      Step 2: Resolve transformations that have no other transformation inputs (only data inputs) - Treated as leaves
                 *      Step 3: Push the results from step 3 to the Resolved list, remove them from the actual list
                 *      Step 4: If Actual node list is not empty go to Step 2
                 *      Step 5: Resolve Last Transformation and return data 
                 *      
                 *  There is another Idea for this part - agent based (parallel) execution of transformations
                 *  TransFormationContainer acts as an agent acting on the transformation. It has to wait for the bulbs to glow.
                 *  I mean inputs to appear(become not null). Once inputs are available, they will run the transformations. 
                 *  The mutex sequence will automatically decide the flow of transformations.
                 *  Good idea to try... 
                */
                //ThreadPool.QueueUserWorkItem(new WaitCallback())
                trs.ToList().ForEach(tx =>
                {
                    waitHandles.Add(new AutoResetEvent(false));
                    ThreadPool.QueueUserWorkItem(tx.Value.ExecTrans, new { State = waitHandles[waitHandles.Count - 1], inp = tx.Key });
                });
                WaitHandle.WaitAll(waitHandles.ToArray());
                waitHandles.Clear();

                DataTable dtReturn = ResolutionBuffer["OP"];
                dtReturn.TableName = _name ?? "Table#" + (new Random()).Next(10000).ToString();

                return dtReturn;
            }
            else
            {
                /* The whole project has only one DataSourceEnvelope (join) - In Case there are no transformations 
                 * the project must have only one DataSourceEnvelope - If others are present only the first one will be 
                 * considered */
                DataTable dtReturn = sourceData[0].GetResult(); ;
                dtReturn.TableName = _name ?? "Table#" + (new Random()).Next(10000).ToString();

                return dtReturn;

            }
            //return dtSource;
        }

        public DataTable Select()
        {
            return ApplyTransformation();
        }

        public DataTable CreateProjectView()
        {
            DataTable Result = new DataTable();
            return Result;
        }
    }

}

﻿using System;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
namespace FI_DataTranformations
{
    interface IDataTransformations
    {
        void AddData(DataSourceEnvelope j);
        void AddTransformations(FI_DataTranformations.Transformations.TransformationContainer tr);
        System.Data.DataTable ApplyTransformation();
        void ClearJoinData();
        System.Data.DataTable CreateProjectView();
        System.Data.DataTable Select();
        
        System.Collections.Generic.List<DataSourceEnvelope> SourceData { get; set; }
        System.Collections.Generic.List<FI_DataTranformations.Transformations.TransformationContainer> TransformationList { get; set; }
    }
}

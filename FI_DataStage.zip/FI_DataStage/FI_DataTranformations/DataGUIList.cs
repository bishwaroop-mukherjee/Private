﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FI_DataTranformations
{
    public class DataGUIList
    {
        List<DataGUIEnvelope> Item;
        public List<DataGUIEnvelope> DataGUIItems
        {
            get
            {
                List<DataGUIEnvelope> l = new List<DataGUIEnvelope>();
                Item.ForEach(i=> l.Add(new DataGUIEnvelope(i.DataPart.getWorkingTemp(),i.GUIPart)));
                return l;
            }
        }

        public DataGUIList() { Item = new List<DataGUIEnvelope>(); }

        public DataGUIList(List<DataGUIEnvelope> dge) 
        {
            Item = new List<DataGUIEnvelope>();
            dge.ForEach(dg=>Item.Add(new DataGUIEnvelope(dg.DataPart.getWorkingTemp(),dg.GUIPart)));
        }

        public static implicit operator List<DataGUIEnvelope> (DataGUIList dgl)
        {
            if (dgl == null)
                return null;
            List<DataGUIEnvelope> l = new List<DataGUIEnvelope>();
            dgl.Item.ForEach(i => l.Add(new DataGUIEnvelope(i.DataPart.getWorkingTemp(),i.GUIPart)));
            return l;
        }
        public static implicit operator DataGUIList(List<DataGUIEnvelope> l)
        {
            DataGUIList dgl = new DataGUIList();
            l.ForEach(i => dgl.Item.Add(new DataGUIEnvelope(i.DataPart.getWorkingTemp(), i.GUIPart)));
            return dgl;
        }

    }
}

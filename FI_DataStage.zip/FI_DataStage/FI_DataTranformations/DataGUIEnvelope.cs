﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FI_DataTranformations
{
    public class DataGUIEnvelope
    {
        DataSourceEnvelope _datapart;
        TableTree _guipart;

        public DataSourceEnvelope DataPart
        {
            get { return _datapart; }
            set { _datapart = value; }
        }
        public TableTree GUIPart
        {
            get { return _guipart; }
            set { _guipart = value; }
        }

        public DataGUIEnvelope(DataSourceEnvelope d, TableTree g)
        {
            _datapart = d;
            _guipart = g;
        }
    }
}

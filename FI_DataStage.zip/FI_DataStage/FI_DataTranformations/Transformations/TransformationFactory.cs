﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;

namespace FI_DataTranformations.Transformations
{
    public class TransformationFactory
    {
        //Transformation internalTransformation;

        public Transformation GetTransformationInstance(string transcode, Transformations.Parameter param)
        {
            Type trType;

            Type[] typesInAssembly;
            Assembly trAss = Assembly.GetAssembly(typeof(Transformation));
            typesInAssembly = trAss.GetTypes();
            trType = typesInAssembly.AsEnumerable().Where(tp => tp.IsSubclassOf(typeof(Transformation))).FirstOrDefault(t => t.GetField("Category").GetRawConstantValue().ToString() == transcode);

            Transformation trans = (Transformation)Activator.CreateInstance(trType);

            //Type paramType;
            //FieldInfo paramField;
            //paramField = trType.GetField("_parameters");
            //paramType = paramField.FieldType;
            //dynamic assignParam = Convert.ChangeType(param, paramType);
            trans.InputParameter = param; // assignParam;
            return trans;
        }

        public List<string> GetTransformationCategories()
        {
            List<string> ret = new List<string>();
            Type[] typesInAssembly;
            Assembly trAss = Assembly.GetAssembly(typeof(Transformation));
            typesInAssembly = trAss.GetTypes();
            typesInAssembly.AsEnumerable().Where(tp => tp.IsSubclassOf(typeof(Transformation))).ToList().ForEach(t => ret.Add(t.GetField("Category").GetRawConstantValue().ToString()));
            return ret;
        }
    }
}

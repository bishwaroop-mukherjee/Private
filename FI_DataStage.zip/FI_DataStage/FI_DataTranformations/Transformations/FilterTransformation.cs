﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FI_DataTranformations.Transformations
{
    public class FilterTransformation : Transformation
    {
        public new const string Category = "Simple Filter Transformation";


    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FI_DataTranformations.Transformations
{
    public class AggregateParameter : Parameter
    {
        public new const string Category = "Aggregate";
        private string _Command;
        public override string Command
        {
            get
            {
                return _Command;
            }
            set
            {
                _Command = value;
            }
        }

        private List<Column> _OnColumns;
        public override List<Column> OnColumns
        {
            get
            {
                return _OnColumns;
            }
            set
            {
                _OnColumns = value;
            }
        }

        private List<Column> _RetColumns;
        public override List<Column> RetColumns
        {
            get
            {
                return _RetColumns;
            }
            set
            {
                _RetColumns = value;
            }
        }
    }
}

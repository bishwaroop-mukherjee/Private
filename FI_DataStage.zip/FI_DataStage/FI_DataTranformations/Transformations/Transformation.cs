﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using FI_DataStage;
using System.Runtime.Serialization;
using System.Xml.Serialization;

namespace FI_DataTranformations.Transformations
{
    public class Transformation:iTransformation, ICloneable 
    {
        public const string Category = "Pass Through Transformation";

        protected string _name;
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        protected List<DataTable> _sources;
        [XmlIgnore]
        public List<DataTable> Inputs
        {
            get { return _sources; }
            set { _sources = value; }
        }

        protected Parameter _parameters;
        public virtual Parameter InputParameter
        {
            get { return _parameters; }
            set { _parameters = value; }
        }

        public virtual DataTable Transform()
        {
            return _sources[0];
        }

        public virtual object Clone()
        {
            Transformation T = new Transformation();
            T.Name = _name;
            if (_sources != null)
            {
                T.Inputs = new List<DataTable>();
                _sources.ForEach(s =>
                {
                    DataTable dt = s.Clone();
                    s.Rows.Cast<DataRow>().ToList().ForEach(r => dt.ImportRow(r));
                    T.Inputs.Add(dt);
                });
            }
            return T;
        }
        
    }
}

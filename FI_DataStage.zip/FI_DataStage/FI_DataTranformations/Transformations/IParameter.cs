﻿using System;
namespace FI_DataTranformations.Transformations
{
    interface IParameter
    {
        string Command { get; set; }
        System.Collections.Generic.List<FI_DataTranformations.Column> OnColumns { get; set; }
        System.Collections.Generic.List<FI_DataTranformations.Column> RetColumns { get; }
    }
}

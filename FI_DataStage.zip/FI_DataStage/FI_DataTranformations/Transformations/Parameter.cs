﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FI_DataTranformations.Transformations
{
    public class Parameter : FI_DataTranformations.Transformations.IParameter
    {
        public const string Category = "Abstract";
        List<Column> _retcolumn;

        public Parameter()
        {
            _retcolumn = null;
        }

        private string _Command;
        public virtual string Command
        {
            get
            {
                return _Command;
            }
            set
            {
                _Command = value;
            }
        }

        private List<Column> _OnColumns;
        public virtual List<Column> OnColumns
        {
            get
            {
                return _OnColumns;
            }
            set
            {
                _OnColumns = value;
            }
        }

        public virtual List<Column> RetColumns
        {
            get
            {
                return _retcolumn;
            }
            set
            {
                _retcolumn = value;
            }
        }
    }
}

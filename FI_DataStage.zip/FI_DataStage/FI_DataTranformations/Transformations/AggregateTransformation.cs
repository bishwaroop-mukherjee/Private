﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FI_DataTranformations.Transformations
{
    public class AggregateTransformation:Transformation 
    {
        public new const string Category = "Simple Aggregate Transformation";
    }
}

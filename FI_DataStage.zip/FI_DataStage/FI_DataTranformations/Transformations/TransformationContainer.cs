﻿using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Linq;
using System.Data;
using System.Text;
using System.Threading;
namespace FI_DataTranformations.Transformations
{
    public class TransformationContainer
    {
        string ThisKey;
        Thread RunTx;
        WaitCallback _ExecTrans;
        public WaitCallback ExecTrans
        {
            get
            {
                if (_ExecTrans == null)
                    _ExecTrans = new WaitCallback(PerformTx);
                return _ExecTrans;
            }
        }
        ConcurrentDictionary<string, DataTable> RefRes;
        public void SetRefs(ConcurrentDictionary<string, DataTable> rD)
        {
            RefRes = rD;
        }
        private Transformation _transformation;
        public Transformation TransformationSpec
        {
            get { return _transformation; }
            set { _transformation = value; }
        }
        private List<TransformationInput> _inputs;
        public List<TransformationInput> Inputs
        {
            get { return _inputs; }
            set { _inputs = value; }
        }
        public TransformationContainer()
        {
            if (_inputs == null)
                _inputs = new List<TransformationInput>();
            //if (ExecTrans == null) ExecTrans = new WaitCallback(PerformTx);
            //ExecTrans += PerformTx; 
        }
        public TransformationContainer(Transformation Tr, params string[] Inp)
        {
            if (_inputs == null)
                _inputs = new List<TransformationInput>();
            TransformationInput tI;
            _transformation = Tr;
            Inp.AsEnumerable().ToList().ForEach(r =>
                    {
                        tI = new TransformationInput();
                        tI.TransInput = r;
                        _inputs.Add(tI);
                    }
                );
            //_ExecTrans += PerformTx;
        }
        public TransformationContainer(Transformation Tr, params TransformationInput[] Inp)
        {
            if (_inputs == null)
                _inputs = new List<TransformationInput>();
            TransformationInput tI;
            _transformation = Tr;
            Inp.AsEnumerable().ToList().ForEach(r =>
                                                    {
                                                        tI = r;
                                                        _inputs.Add(tI);
                                                    }
                                                );
        }

        public TransformationContainer(Transformation Tr)
        {
            if (_inputs == null)
                _inputs = new List<TransformationInput>();
            _transformation = Tr;
            //ExecTrans += PerformTx;
        }

        public void EnqueueTx(string OpKey)
        {
            ThisKey = OpKey;
            RunTx = new Thread(new ParameterizedThreadStart(PerformTx));
            RunTx.Start(ThisKey);
        }
        private void PerformTx(dynamic thrInp)
        {
            AutoResetEvent are = (AutoResetEvent)thrInp.State;
            object inp = thrInp.inp;
            List<DataTable> inps;
            DataTable op;
            while (!InpAvailable()) ;
            inps = new List<DataTable>();
            _inputs.ForEach(i => inps.Add(RefRes[i.TransInput]));
            _transformation.Inputs = inps;
            op = _transformation.Transform();
            RefRes.TryAdd(inp.ToString(), op);
            lock (RefRes["OP"])
            {
                RefRes.AddOrUpdate("OP", op, (k, d) => op);
            }
            are.Set();
        }
        private Boolean InpAvailable()
        {
            Boolean Available = true;
            foreach (TransformationInput i in _inputs)
            {
                if (RefRes.ContainsKey(i.TransInput))
                {
                    DataTable dt;
                    Available = RefRes.TryGetValue(i.TransInput, out dt);
                    if (!Available)
                        return Available;
                }
            }
            return Available;
        }
    }
    public enum TransformationsInputType
    {
        Table, Transformation
    }
    public class TransformationInput : ICloneable
    {
        string[] TypeCode = new string[] { "TD", "TX" };
        private TransformationsInputType _TransType;
        private int _TransInpIndex;
        public string TransInput
        {
            get { return (TypeCode[(int)_TransType] + ":" + _TransInpIndex.ToString()); }
            set
            {
                try
                {
                    string[] spVals = value.Split(new string[] { ":" }, StringSplitOptions.RemoveEmptyEntries);
                    _TransType = (TransformationsInputType)Array.FindIndex(TypeCode, r => r == spVals[0]);
                    _TransInpIndex = Convert.ToInt32(spVals[1]);
                }
                catch (Exception e)
                {
                    _TransInpIndex = -1;
                    throw (e);
                }
            }
        }
        public object Clone()
        {
            TransformationInput TI = new TransformationInput();
            TI.TransInput = (string)TransInput.Clone();
            return TI;
        }

        #region "Transformation Execution"



        #endregion
    }
}

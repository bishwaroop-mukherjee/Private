﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FI_DataTranformations
{
    public class Column
    {
        public string ColumnName;
        public string ColumnExpression;
        public string MappingColumn;

        public static Column CreateColumn(string columnName, string columnExpression, string mappingcolumn)
        {
            Column col = new Column()
                {
                    ColumnName = columnName,
                    ColumnExpression = columnExpression,
                    MappingColumn = mappingcolumn
                };
            return col;
        }
        public static Column GUICreateColumn(System.Data.DataTable refTable, string ColumnName)
        {

            Column col = new Column();
            string CName;
            //System.Data.DataTable table = refTable.Clone();
            string expr = "";
            if (refTable != null)
            {
                if ((CName = ColumnName) != null)
                {
                    try
                    {
                        expr = ExpressCon.ExpressionView.ExpressionBuilder(ref refTable, CName);
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                }
                else
                    throw new Exception("No Column Name Specified");

            }
            if (expr == "")
            {
                col = null;
            }
            else
            {
                col.ColumnExpression = expr;
                col.ColumnName = refTable.Columns[refTable.Columns.Count - 1].ColumnName;
                col.MappingColumn = refTable.Columns[refTable.Columns.Count - 1].ColumnName;
            }
            return col;
        }
    }
}

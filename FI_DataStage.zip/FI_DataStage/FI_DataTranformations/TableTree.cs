﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using System.IO;
using FI_DataStage;
using System.Windows.Forms;

namespace FI_DataTranformations
{
    [XmlRoot()]
    public class TableTree
    {
        public DataSourceClass DataSource;
        public IDType Pid;
        public IDType Cid;
        public JoinType jointype;
        public List<TableTree> JoinedTo;
        //[XmlIgnore()]
        //public frmTable tabFrm;

        public TableTree()
        {
            DataSource = null;
            Pid = Cid = null;
            JoinedTo = null;
            jointype = JoinType.Inner;
        }

        public TableTree Add(string ParentTableName, DataSourceClass dSrc, IDType pid, IDType cid, JoinType jn)
        {
            TableTree T;
            if (dSrc == null) return null;
            if (dSrc.TableName == DataSource.TableName)
            {
                return this;
            }

            if (JoinedTo != null)
                if (JoinedTo.Count(t => t.DataSource.TableName == dSrc.TableName) > 0)
                {
                    JoinedTo.RemoveAt(JoinedTo.FindIndex(t => t.DataSource.TableName == dSrc.TableName && t.jointype == JoinType.Cross));
                }

            if (DataSource != null)
                if (dSrc.TableName == DataSource.TableName)
                    throw new Exception("The table name already exists");

            if (DataSource == null)
            {
                DataSource = dSrc;
                Pid = pid;
                Cid = cid;
                jointype = jn;
                JoinedTo = null;

                return this;
            }
            else if (jn == JoinType.Cross)
            {
                if (JoinedTo == null)
                    JoinedTo = new List<TableTree>();

                JoinedTo.Add(new TableTree());
                //JoinedTo[JoinedTo.Count - 1].tabFrm = frmTab;
                JoinedTo[JoinedTo.Count - 1].DataSource = dSrc;
                JoinedTo[JoinedTo.Count - 1].Pid = pid;
                JoinedTo[JoinedTo.Count - 1].Cid = cid;
                JoinedTo[JoinedTo.Count - 1].jointype = jn;
                JoinedTo[JoinedTo.Count - 1].JoinedTo = null;
                return JoinedTo[JoinedTo.Count - 1];
            }
            else if (DataSource.TableName == ParentTableName)
            {
                if (JoinedTo == null)
                {
                    JoinedTo = new List<TableTree>();
                    JoinedTo.Add(new TableTree());
                    JoinedTo[JoinedTo.Count - 1].DataSource = dSrc;
                    JoinedTo[JoinedTo.Count - 1].Pid = pid;
                    JoinedTo[JoinedTo.Count - 1].Cid = cid;
                    JoinedTo[JoinedTo.Count - 1].jointype = jn;
                    JoinedTo[JoinedTo.Count - 1].JoinedTo = null;
                    return JoinedTo[JoinedTo.Count - 1];
                }
                else
                {
                    JoinedTo.Add(new TableTree());
                    JoinedTo[JoinedTo.Count - 1].DataSource = dSrc;
                    JoinedTo[JoinedTo.Count - 1].Pid = pid;
                    JoinedTo[JoinedTo.Count - 1].Cid = cid;
                    JoinedTo[JoinedTo.Count - 1].jointype = jn;
                    JoinedTo[JoinedTo.Count - 1].JoinedTo = null;
                    return JoinedTo[JoinedTo.Count - 1];
                }
            }
            else
            {
                if (JoinedTo != null)
                {
                    foreach (TableTree t in JoinedTo)
                    {
                        T = t.Add(ParentTableName, dSrc, pid, cid, jn);
                        if (T != null)
                            return T;
                    }

                }
                return null;
            }
        }

        public void PrepareJoin(DataSourceEnvelope dse)
        {
            if (DataSource != null)
            {
                dse.Add(DataSource, Pid, Cid, jointype);
                if (JoinedTo != null)
                {
                    foreach (TableTree t in JoinedTo)
                    {
                        t.PrepareJoin(dse);
                    }
                }
            }

        }


    }
}

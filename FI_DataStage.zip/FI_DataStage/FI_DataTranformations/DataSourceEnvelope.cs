﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FI_DataStage;
using System.Xml.Serialization;
using System.Data;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;

namespace FI_DataTranformations
{
    public class DataSourceEnvelope : FI_DataTranformations.IDataSourceEnvelope
    {


        private DataSourceClass Table;

        public DataSourceClass TableNode
        {
            get { return Table; }
            set { Table = value; }
        }

        public ChildDataSource ChildTable;


        private ColumnSet destination;

        [XmlElement("Destination")]
        public ColumnSet Destination
        {
            get { return destination; }
            set { destination = value; }
        }

        private List<ColType> columnTypes;
        [XmlArray("ColumnTypes")]
        public List<ColType> ColumnTypes
        {
            get { return columnTypes; }
            set { columnTypes = value; }
        }

        public DataSourceEnvelope()
        {
            Table = null;
            ChildTable = null;
            destination = new ColumnSet();
        }
        public DataSourceEnvelope(DataSourceClass ds)
        {
            Table = ds;
            ChildTable = null;
            destination = new ColumnSet();
        }
        public void ClearColumnsData()
        {
            destination = new ColumnSet();
        }

        public void RenameCol(string ColName, string NewName)
        {
            string newname;
            newname = NewName;
            if (newname != null)
            {
                Column col = destination[ColName];
                destination.Remove(ColName);
                col.ColumnName = newname;
                destination.Add(newname, col);
            }
        }
        public void SetDestinationColumnSet(ColumnSet cs)
        {
            if (destination == null)
                destination = new ColumnSet();
            cs.ToList().ForEach(c => destination.Add(c.Value));
        }
        public void SetColType(string ColName, System.Type type)
        {
            if (columnTypes == null)
            {
                columnTypes = new List<ColType>();
            }
            columnTypes.Add(new ColType(ColName, type));
        }
        private DataTable ApplyType(DataTable dtSource)
        {
            //dtSource.Columns.Cast<DataColumn>().ToList().ForEach(c => c.DataType = ColumnTypes.Where(Ct=>Ct.ColName==c.ColumnName).First().ColType);
            if (columnTypes != null)
            {
                DataTable tempClone = dtSource.Clone();
                columnTypes.ForEach(Ct => tempClone.Columns[Ct.ColName].DataType = Type.GetType(Ct.ColumnType));
                dtSource.AsEnumerable().ToList().ForEach(R => tempClone.ImportRow(R));
                dtSource.Dispose();
                return tempClone;
            }
            else
                return dtSource;
        }
        public DataTable Project(DataTable dtSource)
        {
            DataTable dtRet;
            if (destination == null)
                return dtSource;
            if (destination.Count > 0)
            {
                destination.AsEnumerable().ToList().ForEach(c =>
                    {
                        DataColumn dc = new DataColumn(c.Value.MappingColumn);
                        dc.Expression = c.Value.ColumnExpression;
                        dtSource.Columns.Add(dc);
                    });


                var query = dtSource.AsEnumerable().AsQueryable().Select(ProjectRow);

                dtRet = query.CopyToDataTable();

                return dtRet;
            }
            else
            {

                return dtSource;
            }
        }
        private DataRow ProjectRow(DataRow r)
        {
            DataTable dt = new DataTable();
            DataRow dr;
            List<DataColumn> dcs = new List<DataColumn>();
            destination.ToList().ForEach(k => dcs.Add(new DataColumn(k.Value.ColumnName)));

            dt.Columns.AddRange(dcs.ToArray());
            dr = dt.NewRow();
            destination.ToList().ForEach(k => dr[k.Value.ColumnName] = r[k.Value.MappingColumn]);

            return dr;

        }
        public DataSourceEnvelope getWorkingTemp()
        {
            DataSourceEnvelope dse = new DataSourceEnvelope();
            ChildDataSource dsTemp = this.ChildTable;
            dse.Add(this.Table, null, null, JoinType.Inner);

            while (dsTemp != null)
            {
                dse.Add(dsTemp.Tab.Table, dsTemp.ParentID, dsTemp.ChildID, dsTemp.jointype);
                dsTemp = dsTemp.Tab.ChildTable;
            }
            return dse;

        }
        public DataTable GetResult()
        {
            DataTable dt = ExtractTable();
            dt = ApplyType(dt);
            dt = Project(dt);
            return dt;
        }

        public void Add(DataSourceClass Dsrc, IDType PID, IDType CID, JoinType jn)
        {
            if (Table == null)
            {
                Table = Dsrc;
                ChildTable = null;
            }
            else
            {
                AddChild(new ChildDataSource(Dsrc, PID, CID, jn));

            }
        }

        private void AddChild(ChildDataSource cld)
        {
            if (ChildTable == null)
            {
                ChildTable = cld;
            }
            else
            {
                ChildTable.Tab.AddChild(cld);
            }
        }
        public DataTable ExtractTable()
        {
            if (this.ChildTable == null)
            {
                return this.Table.getDataTable();
            }
            else
            {
                return this.Join();
            }
        }

        public DataTable Join()
        {
            DataSourceEnvelope Temp = this.getWorkingTemp();
            return Join(Temp);
        }
        private DataTable Join(DataSourceEnvelope source)//DataSourceEnvelope source)
        {
            try
            {
                List<DataTable> dtList = new List<DataTable>();
                IEnumerable<IEnumerable<object>> T = null;
                if (source.ChildTable.Tab.ChildTable != null)
                {
                    DataTable res = new DataTable();
                    JoinType jn = source.ChildTable.jointype;
                    DataTable dtTemp = source.Table.getDataTable();
                    DataTable dtTemp2 = source.ChildTable.Tab.Table.getDataTable();
                    IDType ColS = source.ChildTable.ParentID;
                    IDType ColC = source.ChildTable.ChildID;

                    if (jn == JoinType.Inner)
                    {
                        T = from DataRow dR1 in dtTemp.Rows
                            join DataRow dR2 in dtTemp2.Rows
                            on Convert.ChangeType(dR1[ColS.ID.ToString()], Type.GetType("System.String"))
                            equals Convert.ChangeType(dR2[ColC.ID.ToString()], Type.GetType("System.String"))
                            select dR1.ItemArray.MergeEnumerable(dR2.ItemArray, new int[] { });
                    }
                    else if (jn == JoinType.LeftOuter)
                    {
                        T = from DataRow dR1 in dtTemp.Rows
                            join DataRow dR2 in dtTemp2.Rows
                            on Convert.ChangeType(dR1[ColS.ID.ToString()], Type.GetType("System.String"))
                            equals Convert.ChangeType(dR2[ColC.ID.ToString()], Type.GetType("System.String")) into JoinedRow
                            from jnr in JoinedRow.DefaultIfEmpty()
                            select dR1.ItemArray.MergeEnumerable((jnr == null ? DataTransformationsHelper.GetNullArray(dtTemp2.Columns.Count) : jnr.ItemArray), new int[] { });
                    }
                    else if (jn == JoinType.RightOuter)
                    {
                        T = from DataRow dR2 in dtTemp2.Rows
                            join DataRow dR1 in dtTemp.Rows
                            on Convert.ChangeType(dR2[ColC.ID.ToString()], Type.GetType("System.String"))
                            equals Convert.ChangeType(dR1[ColS.ID.ToString()], Type.GetType("System.String")) into JoinedRow
                            from jnr in JoinedRow.DefaultIfEmpty()
                            select (jnr == null ? DataTransformationsHelper.GetNullArray(dtTemp.Columns.Count) : jnr.ItemArray).MergeEnumerable(dR2.ItemArray, new int[] { });
                    }
                    else if (jn == JoinType.Outer)
                    {

                        T = (from DataRow dR1 in dtTemp.Rows
                             join DataRow dR2 in dtTemp2.Rows
                             on Convert.ChangeType(dR1[ColS.ID.ToString()], Type.GetType("System.String"))
                             equals Convert.ChangeType(dR2[ColC.ID.ToString()], Type.GetType("System.String")) into JoinedRow
                             from jnr in JoinedRow.DefaultIfEmpty()
                             select dR1.ItemArray.MergeEnumerable((jnr == null ? DataTransformationsHelper.GetNullArray(dtTemp2.Columns.Count) : jnr.ItemArray),
                                                                   new int[] { }))
                            .Union(
                            from DataRow dR2 in dtTemp2.Rows
                            join DataRow dR1 in dtTemp.Rows
                            on Convert.ChangeType(dR2[ColC.ID.ToString()], Type.GetType("System.String"))
                            equals Convert.ChangeType(dR1[ColS.ID.ToString()], Type.GetType("System.String")) into JoinedRow
                            from jnr in JoinedRow.DefaultIfEmpty()
                            where jnr == null
                            select (jnr == null ? DataTransformationsHelper.GetNullArray(dtTemp.Columns.Count) : jnr.ItemArray).MergeEnumerable(dR2.ItemArray,
                                    new int[] { }));
                    }
                    else if (jn == JoinType.Cross)
                    {
                        T = from DataRow dR1 in dtTemp.Rows
                            join DataRow dR2 in dtTemp2.Rows
                            on 1 equals 1
                            select dR1.ItemArray.MergeEnumerable(dR2.ItemArray, new int[] { });
                    }


                    //Complete join
                    //Convert T to Datatable
                    IEnumerable<DataColumn> C;
                    C = (from DataColumn dc1 in dtTemp.Columns
                         select new DataColumn(dc1.ColumnName)).Union(
                        (IEnumerable<DataColumn>)(from DataColumn dc2 in dtTemp2.Columns
                                                  select new DataColumn(dc2.ColumnName))).Distinct(new DataColEqualityComp());


                    res.Columns.AddRange(C.ToArray());

                    foreach (IEnumerable<object> R in T)
                    {
                        res.Rows.Add(R.ToArray());
                    }
                    ChildDataSource cldData;
                    cldData = source.ChildTable;
                    source.ChildTable = new ChildDataSource(new TempDataSource(res, "JoinTemp"), cldData.ParentID, cldData.ChildID, jn);
                    source.ChildTable.Tab.ChildTable = cldData.Tab.ChildTable;
                    return Join(source.ChildTable.Tab);
                }
                else
                {
                    DataTable res = new DataTable();
                    DataTable dtTemp = source.Table.getDataTable();
                    dtTemp.TableName = source.Table.TableName;
                    JoinType jn = source.ChildTable.jointype;
                    DataTable dtTemp2 = source.ChildTable.Tab.Table.getDataTable();
                    dtTemp2.TableName = source.ChildTable.Tab.Table.TableName;
                    IDType ColS = source.ChildTable.ParentID;
                    IDType ColC = source.ChildTable.ChildID;

                    if (jn == JoinType.Inner)
                    {
                        T = from DataRow dR1 in dtTemp.Rows
                            join DataRow dR2 in dtTemp2.Rows
                            on Convert.ChangeType(dR1[ColS.ID.ToString()], Type.GetType("System.String"))
                            equals Convert.ChangeType(dR2[ColC.ID.ToString()], Type.GetType("System.String"))
                            select dR1.ItemArray.MergeEnumerable(dR2.ItemArray, new int[] { });
                    }
                    else if (jn == JoinType.LeftOuter)
                    {
                        T = from DataRow dR1 in dtTemp.Rows
                            join DataRow dR2 in dtTemp2.Rows
                            on Convert.ChangeType(dR1[ColS.ID.ToString()], Type.GetType("System.String"))
                            equals Convert.ChangeType(dR2[ColC.ID.ToString()], Type.GetType("System.String")) into JoinedRow
                            from jnr in JoinedRow.DefaultIfEmpty()
                            select dR1.ItemArray.MergeEnumerable((jnr == null ? DataTransformationsHelper.GetNullArray(dtTemp2.Columns.Count) : jnr.ItemArray), new int[] { });
                    }
                    else if (jn == JoinType.RightOuter)
                    {
                        T = from DataRow dR2 in dtTemp2.Rows
                            join DataRow dR1 in dtTemp.Rows
                            on Convert.ChangeType(dR2[ColC.ID.ToString()], Type.GetType("System.String"))
                            equals Convert.ChangeType(dR1[ColS.ID.ToString()], Type.GetType("System.String")) into JoinedRow
                            from jnr in JoinedRow.DefaultIfEmpty()
                            select (jnr == null ? DataTransformationsHelper.GetNullArray(dtTemp.Columns.Count) : jnr.ItemArray).MergeEnumerable(dR2.ItemArray, new int[] { });
                    }
                    else if (jn == JoinType.Outer)
                    {

                        T = (from DataRow dR1 in dtTemp.Rows
                             join DataRow dR2 in dtTemp2.Rows
                             on Convert.ChangeType(dR1[ColS.ID.ToString()], Type.GetType("System.String"))
                             equals Convert.ChangeType(dR2[ColC.ID.ToString()], Type.GetType("System.String")) into JoinedRow
                             from jnr in JoinedRow.DefaultIfEmpty()
                             select dR1.ItemArray.MergeEnumerable((jnr == null ? DataTransformationsHelper.GetNullArray(dtTemp2.Columns.Count) : jnr.ItemArray),
                                                                   new int[] { }))
                            .Union(
                            from DataRow dR2 in dtTemp2.Rows
                            join DataRow dR1 in dtTemp.Rows
                            on Convert.ChangeType(dR2[ColC.ID.ToString()], Type.GetType("System.String"))
                            equals Convert.ChangeType(dR1[ColS.ID.ToString()], Type.GetType("System.String")) into JoinedRow
                            from jnr in JoinedRow.DefaultIfEmpty()
                            where jnr == null
                            select (jnr == null ? DataTransformationsHelper.GetNullArray(dtTemp.Columns.Count) : jnr.ItemArray).MergeEnumerable(dR2.ItemArray,
                                    new int[] { }));
                    }
                    else if (jn == JoinType.Cross)
                    {
                        T = from DataRow dR1 in dtTemp.Rows
                            join DataRow dR2 in dtTemp2.Rows
                            on 1 equals 1
                            select dR1.ItemArray.MergeEnumerable(dR2.ItemArray, new int[] { });
                    }

                    //Complete join
                    //Convert T to Datatable
                    IEnumerable<DataColumn> C;
                    C = (from DataColumn dc1 in dtTemp.Columns
                         select new DataColumn(dc1.ColumnName)).Union(
                        (IEnumerable<DataColumn>)(from DataColumn dc2 in dtTemp2.Columns
                                                  select new DataColumn(dc2.ColumnName))).Distinct(new DataColEqualityComp());

                    res.Columns.AddRange(C.ToArray());
                    foreach (IEnumerable<object> R in T)
                    {
                        res.Rows.Add(R.ToArray());
                    }
                    return res;
                }
            }
            catch (Exception)
            {
                return null;
            }
        }

    }

    public class ChildDataSource
    {

        public DataSourceEnvelope Tab;


        public IDType ParentID, ChildID;
        public JoinType jointype;
        public ChildDataSource() { }
        public ChildDataSource(DataSourceClass ds, IDType pid, IDType cid, JoinType jn)
        {
            Tab = new DataSourceEnvelope(ds);
            ParentID = pid;
            ChildID = cid;
            jointype = jn;
            Tab.ChildTable = null;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FI_DataTranformations
{
    [Serializable]
    public class ColType
    {
        string _colname;
        System.Type _type;
        public ColType()
        {
            _colname = null;
            _type = null;
        }
        public ColType(string colName, Type  colType)
        {
            _colname = colName;
            _type = colType;
        }
        public string ColName
        {
            get
            {
                return _colname;
            }
            set
            {
                _colname = value;
            }
        }
        public string ColumnType
        { 
            get
            {
                return _type.ToString();
            }
            set
            {
                _type = Type.GetType(value);
            }
        }
    }
}

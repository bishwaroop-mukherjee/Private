﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Runtime.Serialization;
using System.Xml.Serialization;
using System.Xml;

namespace FI_DataTranformations
{
    public class ColumnSet : Dictionary<string, Column>, IXmlSerializable
    {
        public Column Add(Column c)
        {
            base.Add(c.ColumnName, c);
            return base[c.ColumnName];
        }

        public Column AddNew(string ColumnName, string ColExpr, string MapCol)
        {
            base.Add(ColumnName, Column.CreateColumn(ColumnName, ColExpr, MapCol));
            return base[ColumnName];
        }
        public Column AddNew(Column c)
        {
            Add(Column.CreateColumn(c.ColumnName, c.ColumnExpression, c.MappingColumn));
            return base[c.ColumnName];
        }
        public Column GUIAddNew(System.Data.DataTable refTable, string ColumnName)
        {
            try
            {
                Column col = Column.GUICreateColumn(refTable, ColumnName);
                if (col != null)
                {
                    base.Add(col.ColumnName, col);
                    return base[col.ColumnName];
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void WriteXml(System.Xml.XmlWriter writer)
        {
            writer.WriteAttributeString("Data", "ColumnSet");

            writer.WriteStartElement("Columns");

            foreach (KeyValuePair<string, Column> c in this)
            {
                writer.WriteElementString("Column", c.Value.ColumnName);
                writer.WriteElementString("Expression", c.Value.ColumnExpression);
                writer.WriteElementString("MappingColumn", c.Value.MappingColumn);

            }
            writer.WriteEndElement();
        }
        public void ReadXml(System.Xml.XmlReader reader)
        {
            if (this.Count > 0)
                return;
            string Name, Expr, Map;
            XmlDocument xmld = new XmlDocument();
            string iNnerxMlsTr;
            iNnerxMlsTr = reader.ReadInnerXml();
            xmld.LoadXml(iNnerxMlsTr);
            XmlNodeList NodeDest = xmld.FirstChild.ChildNodes;
            for (int i = 0; i < NodeDest.Count - 1; i++)
            {
                if (NodeDest[i].Name == "Column")
                {
                    Name = NodeDest[i].InnerText;
                    Expr = NodeDest[i + 1].InnerText;
                    Map = NodeDest[i + 2].InnerText;
                    this.AddNew(Name, Expr, Map);
                }

            }
        }

        public System.Xml.Schema.XmlSchema GetSchema() { return null; }
    }
}
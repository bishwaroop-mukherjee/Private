﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace FI_DataTranformations
{
    class DataTransformationsHelper
    {
        static void Main(string[] args)
        {
            List<DataTable> dtList = new List<DataTable>();

            DataTable dtTemp;

            dtTemp = dtList[0];
            for (int i = 1; i < dtList.Count; i++)
            {
                IEnumerable<IEnumerable<object>> T = from DataRow dR1 in dtTemp.Rows
                                                     join DataRow dR2 in dtList[i].Rows
                                                     on Convert.ChangeType(dR1["ID"], Type.GetType("System.Int32")) equals Convert.ChangeType(dR2["ID"], Type.GetType("System.Int32"))
                                                     select dR1.ItemArray.MergeEnumerable(dR2.ItemArray, new int[] { 0 });

                IEnumerable<DataColumn> C = (from DataColumn dc1 in dtTemp.Columns
                                             select new DataColumn(dc1.ColumnName)).Union(
                                             (IEnumerable<DataColumn>)(from DataColumn dc2 in dtList[i].Columns
                                                                       select new DataColumn(dc2.ColumnName))).Distinct(new DataColEqualityComp());

                dtTemp = new DataTable();
                dtTemp.Columns.AddRange(C.ToArray());
                foreach (IEnumerable<object> R in T)
                {
                    dtTemp.Rows.Add(R.ToArray());
                }
            }
        }
    }

    public class DataColEqualityComp : EqualityComparer<DataColumn>
    {
        public DataColEqualityComp()
        {

        }
        public override bool Equals(DataColumn x, DataColumn y)
        {
            return (x.ColumnName == y.ColumnName);
        }
        public override int GetHashCode(DataColumn obj)
        {
            return 0;
        }
    }

     public static class Extensions
    {
        public static IEnumerable<Object> MergeEnumerable(this IEnumerable<Object> First, IEnumerable<Object> Second, int[] eliminate)
        {
            List<Object> Result = new List<object>();
            List<int> Elim = new List<int>(eliminate);
            Result.AddRange(First);
            int index = 0;
            foreach (Object o in Second)
            {
                if (Elim.IndexOf(index) < 0)
                    Result.Add(o);
                index++;
            }
            return Result.AsEnumerable();
        }
        
    }

}
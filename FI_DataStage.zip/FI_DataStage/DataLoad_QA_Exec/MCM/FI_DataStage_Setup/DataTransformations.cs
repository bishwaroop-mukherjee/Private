﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FI_DataStage;
using System.Data;
using System.Reflection;
using System.Xml.Serialization;

namespace FI_DataTranformations
{
    // Class for transformation logic
    [XmlRoot("DataTransformations")]
    public class DataTransformations
    {
        
        // Methods to perform calculations and get result columns
        // It will contain Linq query 
        public DataTransformations()
        {
            SourceData = new DataSourceEnvelope();
        }
        public DataSourceEnvelope SourceData;
        //public ColumnSet Destination;

        public DataTable JoinSource()
        {
            return Join(SourceData);
        }

        private DataTable Join(DataSourceEnvelope source)
        {
            List<DataTable> dtList = new List<DataTable>();
            IEnumerable<IEnumerable<object>> T=null;
            if (source.ChildTable.Tab.ChildTable != null)
            {
                DataTable res = new DataTable();
                JoinType jn = source.ChildTable.jointype;
                DataTable dtTemp = source.Table.getDataTable();
                DataTable dtTemp2 = source.ChildTable.Tab.Table.getDataTable();
                IDType ColS = source.ChildTable.ParentID;
                IDType ColC = source.ChildTable.ChildID;

                if (jn == JoinType.Inner)
                {
                    T = from DataRow dR1 in dtTemp.Rows
                        join DataRow dR2 in dtTemp2.Rows
                        on Convert.ChangeType(dR1[ColS.ID.ToString()], Type.GetType("System.String"))
                        equals Convert.ChangeType(dR2[ColC.ID.ToString()], Type.GetType("System.String"))
                        select dR1.ItemArray.MergeEnumerable(dR2.ItemArray, new int[] { dtTemp2.Columns[ColC.ID.ToString()].Ordinal });
                }
                else if(jn == JoinType.LeftOuter)
                {
                    T = from DataRow dR1 in dtTemp.Rows
                        join DataRow dR2 in dtTemp2.Rows
                        on Convert.ChangeType(dR1[ColS.ID.ToString()], Type.GetType("System.String"))
                        equals Convert.ChangeType(dR2[ColC.ID.ToString()], Type.GetType("System.String")) into JoinedRow
                        from jnr in JoinedRow.DefaultIfEmpty()
                        select dR1.ItemArray.MergeEnumerable((jnr==null?GetNullArray(dtTemp2.Columns.Count):jnr.ItemArray), new int[] { dtTemp2.Columns[ColC.ID.ToString()].Ordinal });
                }
                else if(jn == JoinType.RightOuter )
                {
                    T = from DataRow dR2 in dtTemp2.Rows
                        join DataRow dR1 in dtTemp.Rows
                        on Convert.ChangeType(dR2[ColC.ID.ToString()], Type.GetType("System.String"))
                        equals Convert.ChangeType(dR1[ColS.ID.ToString()], Type.GetType("System.String")) into JoinedRow
                        from jnr in JoinedRow.DefaultIfEmpty()
                        select (jnr==null?GetNullArray(dtTemp.Columns.Count ):jnr.ItemArray).MergeEnumerable(dR2.ItemArray, new int[] { dtTemp2.Columns[ColC.ID.ToString()].Ordinal });
                }
                else if (jn == JoinType.Outer) 
                {

                    T = (from DataRow dR1 in dtTemp.Rows
                         join DataRow dR2 in dtTemp2.Rows
                         on Convert.ChangeType(dR1[ColS.ID.ToString()], Type.GetType("System.String"))
                         equals Convert.ChangeType(dR2[ColC.ID.ToString()], Type.GetType("System.String")) into JoinedRow
                         from jnr in JoinedRow.DefaultIfEmpty()
                         select dR1.ItemArray.MergeEnumerable((jnr == null ? GetNullArray(dtTemp2.Columns.Count) : jnr.ItemArray),
                                                               new int[] { dtTemp2.Columns[ColC.ID.ToString()].Ordinal }))
                        .Union(
                        from DataRow dR2 in dtTemp2.Rows
                        join DataRow dR1 in dtTemp.Rows
                        on Convert.ChangeType(dR2[ColC.ID.ToString()], Type.GetType("System.String"))
                        equals Convert.ChangeType(dR1[ColS.ID.ToString()], Type.GetType("System.String")) into JoinedRow
                        from jnr in JoinedRow.DefaultIfEmpty()
                        where jnr == null 
                        select (jnr == null ? GetNullArray(dtTemp.Columns.Count) : jnr.ItemArray).MergeEnumerable(dR2.ItemArray,
                                new int[] { dtTemp2.Columns[ColC.ID.ToString()].Ordinal }));
                }

                
                
                //Complete join
                //Convert T to Datatable
                IEnumerable<DataColumn> C;
                C = (from DataColumn dc1 in dtTemp.Columns
                     select new DataColumn(dc1.ColumnName)).Union(
                    (IEnumerable<DataColumn>)(from DataColumn dc2 in dtTemp2.Columns
                                              select new DataColumn(dc2.ColumnName))).Distinct(new DataColEqualityComp());


                res.Columns.AddRange(C.ToArray());

                foreach (IEnumerable<object> R in T)
                {
                    res.Rows.Add(R.ToArray());
                }
                ChildDataSource cldData;
                cldData = source.ChildTable;
                source.ChildTable = new ChildDataSource(new TempDataSource(res, "JoinTemp"), cldData.ParentID, cldData.ChildID,jn);
                source.ChildTable.Tab.ChildTable = cldData.Tab.ChildTable;
                return Join(source.ChildTable.Tab );
            }
            else
            {
                DataTable res = new DataTable();
                DataTable dtTemp = source.Table.getDataTable();
                dtTemp.TableName = source.Table.TableName;
                JoinType jn = source.ChildTable.jointype;
                DataTable dtTemp2 = source.ChildTable.Tab.Table.getDataTable();
                dtTemp2.TableName = source.ChildTable.Tab.Table.TableName;
                IDType ColS = source.ChildTable.ParentID;
                IDType ColC = source.ChildTable.ChildID;

                if (jn == JoinType.Inner)
                {
                    T = from DataRow dR1 in dtTemp.Rows
                        join DataRow dR2 in dtTemp2.Rows
                        on Convert.ChangeType(dR1[ColS.ID.ToString()], Type.GetType("System.String"))
                        equals Convert.ChangeType(dR2[ColC.ID.ToString()], Type.GetType("System.String"))
                        select dR1.ItemArray.MergeEnumerable(dR2.ItemArray, new int[] { dtTemp2.Columns[ColC.ID.ToString()].Ordinal });
                }
                else if (jn == JoinType.LeftOuter)
                {
                    T = from DataRow dR1 in dtTemp.Rows
                        join DataRow dR2 in dtTemp2.Rows
                        on Convert.ChangeType(dR1[ColS.ID.ToString()], Type.GetType("System.String"))
                        equals Convert.ChangeType(dR2[ColC.ID.ToString()], Type.GetType("System.String")) into JoinedRow
                        from jnr in JoinedRow.DefaultIfEmpty()
                        select dR1.ItemArray.MergeEnumerable((jnr == null ? GetNullArray(dtTemp2.Columns.Count) : jnr.ItemArray), new int[] { dtTemp2.Columns[ColC.ID.ToString()].Ordinal });
                }
                else if (jn == JoinType.RightOuter)
                {
                    T = from DataRow dR2 in dtTemp2.Rows
                        join DataRow dR1 in dtTemp.Rows
                        on Convert.ChangeType(dR2[ColC.ID.ToString()], Type.GetType("System.String"))
                        equals Convert.ChangeType(dR1[ColS.ID.ToString()], Type.GetType("System.String")) into JoinedRow
                        from jnr in JoinedRow.DefaultIfEmpty()
                        select (jnr == null ? GetNullArray(dtTemp.Columns.Count) : jnr.ItemArray).MergeEnumerable(dR2.ItemArray, new int[] { dtTemp2.Columns[ColC.ID.ToString()].Ordinal });
                }
                else if (jn == JoinType.Outer)
                {

                    T = (from DataRow dR1 in dtTemp.Rows
                         join DataRow dR2 in dtTemp2.Rows
                         on Convert.ChangeType(dR1[ColS.ID.ToString()], Type.GetType("System.String"))
                         equals Convert.ChangeType(dR2[ColC.ID.ToString()], Type.GetType("System.String")) into JoinedRow
                         from jnr in JoinedRow.DefaultIfEmpty()
                         select dR1.ItemArray.MergeEnumerable((jnr == null ? GetNullArray(dtTemp2.Columns.Count) : jnr.ItemArray),
                                                               new int[] { dtTemp2.Columns[ColC.ID.ToString()].Ordinal }))
                        .Union(
                        from DataRow dR2 in dtTemp2.Rows
                        join DataRow dR1 in dtTemp.Rows
                        on Convert.ChangeType(dR2[ColC.ID.ToString()], Type.GetType("System.String"))
                        equals Convert.ChangeType(dR1[ColS.ID.ToString()], Type.GetType("System.String")) into JoinedRow
                        from jnr in JoinedRow.DefaultIfEmpty()
                        where jnr == null
                        select (jnr == null ? GetNullArray(dtTemp.Columns.Count) : jnr.ItemArray).MergeEnumerable(dR2.ItemArray,
                                new int[] { dtTemp2.Columns[ColC.ID.ToString()].Ordinal }));
                }


                //Complete join
                //Convert T to Datatable
                IEnumerable<DataColumn> C;
                C = (from DataColumn dc1 in dtTemp.Columns
                    select new DataColumn(dc1.ColumnName)).Union(
                    (IEnumerable<DataColumn>)(from DataColumn dc2 in dtTemp2.Columns
                                            select new DataColumn(dc2.ColumnName))).Distinct(new DataColEqualityComp());

                res.Columns.AddRange(C.ToArray());
                foreach (IEnumerable<object> R in T)
                {
                    res.Rows.Add(R.ToArray());
                }
                return res;
            }
        }
        private Object[] GetNullArray(int Count)
        {
            Object[] Narr = new Object[Count ];
            for (int i = 0; i < Count; i++)
                Narr[i] = null;
            return Narr;
        }
    }
    public enum JoinType
    {
        Inner = 0,
        LeftOuter = 1,
        RightOuter = 2,
        Outer = 3
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FI_DataTranformations
{
    public class Join
    {
        public string Table1;
        public string Table2;
        public string IDColumn1;
        public string IDColumn2;
    }
}

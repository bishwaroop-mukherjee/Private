﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace FI_DataStage
{
    public partial class FI : Form
    {
        public FI()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Load actions
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_Load(object sender, EventArgs e)
        {
            
            /// text file
            
            //FI_DataStage.TextDataSource txtSrc = new FI_DataStage.TextDataSource(@"X:\ejv.txt", "\t",false,false);
            //DataTable dt = new DataTable();
            //dt = txtSrc.getDataTable();
            //dataGridView1.DataSource = dt;

            /// xml file

            //FI_DataStage.XMLDataSource xmlSrc = new XMLDataSource();
            //xmlSrc.loadGainLossFromXML();

            /// XML new 
            //FI_DataStage.XMLDataSource xml = new XMLDataSource();
            //xml.ImportGenericXML(@"\\crenshaw\traders\India\AUTOMATION\PROD_DBs\FI_Exposures_C#\FWD GL Report\ReX_Forward_GL_XML.xml");

           // FI_DataStage.CSVDataSource csvSrc = new CSVDataSource(@"X:\test1.csv",",",false);
            
            // CSV alternate approach

            //FI_DataStage.CSVDataSource csvSrc = new CSVDataSource();
            //DataSet ds = new DataSet();
            //ds = csvSrc.ReadFromCsv(@"X:\test1.csv");
            //dataGridView1.DataSource = ds.Tables[0];

            //FI_DataStage.CSVDataSource csvSrc = new FI_DataStage.CSVDataSource(@"X:\FI_R_All_Bonds.csv", ",", true);
            //DataTable dt = new DataTable();
            //dt = csvSrc.getDataTable();
            //dataGridView1.DataSource = dt;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        //private void timer1_Tick(object sender, EventArgs e)
        //{
        //    ParameterizedThreadStart p = new ParameterizedThreadStart(Run);
            
        //    Thread th = new Thread(p);
        //    th.Start(
        //}
        //public void Run(int i)
        //{
        //}
    }
}

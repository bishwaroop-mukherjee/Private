﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FI_DataTranformations
{
    public class Joins:Dictionary<string,Join>
    {
        public Join Add(Join j)
        {
            base.Add(j.Table1 + "_" + j.Table2, j);
            return base[j.Table1 + "_" + j.Table2];
        }
    }
}

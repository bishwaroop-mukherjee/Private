﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace FI_DataTranformations
{
    public class ColumnSet:Dictionary <string,Column>
    {
        public Column Add(Column c)
        {
            base.Add(c.ColumnName, c);
            return base[c.ColumnName];
        }
    }
}

﻿namespace Scheduler
{
    partial class frmScheduler
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.dgvDataLoadTasks = new System.Windows.Forms.DataGridView();
            this.btnAddTasks = new System.Windows.Forms.Button();
            this.lblDataLoadTasks = new System.Windows.Forms.Label();
            this.btnDeleteTasks = new System.Windows.Forms.Button();
            this.btnEditTask = new System.Windows.Forms.Button();
            this.btnRunTask = new System.Windows.Forms.Button();
            this.btnLog = new System.Windows.Forms.Button();
            this.btStat = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDataLoadTasks)).BeginInit();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Interval = 2000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // dgvDataLoadTasks
            // 
            this.dgvDataLoadTasks.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDataLoadTasks.Location = new System.Drawing.Point(12, 29);
            this.dgvDataLoadTasks.Name = "dgvDataLoadTasks";
            this.dgvDataLoadTasks.Size = new System.Drawing.Size(665, 278);
            this.dgvDataLoadTasks.TabIndex = 0;
            this.dgvDataLoadTasks.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgvDataLoadTasks_CellBeginEdit);
            this.dgvDataLoadTasks.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDataLoadTasks_CellContentClick);
            this.dgvDataLoadTasks.MouseClick += new System.Windows.Forms.MouseEventHandler(this.dataGridDataLoadTasks_MouseClick);
            // 
            // btnAddTasks
            // 
            this.btnAddTasks.Location = new System.Drawing.Point(12, 330);
            this.btnAddTasks.Name = "btnAddTasks";
            this.btnAddTasks.Size = new System.Drawing.Size(100, 25);
            this.btnAddTasks.TabIndex = 1;
            this.btnAddTasks.Text = "Add Tasks";
            this.btnAddTasks.UseVisualStyleBackColor = true;
            this.btnAddTasks.Click += new System.EventHandler(this.btnAddTasks_Click);
            // 
            // lblDataLoadTasks
            // 
            this.lblDataLoadTasks.AutoSize = true;
            this.lblDataLoadTasks.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDataLoadTasks.Location = new System.Drawing.Point(23, 10);
            this.lblDataLoadTasks.Name = "lblDataLoadTasks";
            this.lblDataLoadTasks.Size = new System.Drawing.Size(112, 16);
            this.lblDataLoadTasks.TabIndex = 2;
            this.lblDataLoadTasks.Text = "Data Load Tasks";
            // 
            // btnDeleteTasks
            // 
            this.btnDeleteTasks.Location = new System.Drawing.Point(127, 330);
            this.btnDeleteTasks.Name = "btnDeleteTasks";
            this.btnDeleteTasks.Size = new System.Drawing.Size(100, 25);
            this.btnDeleteTasks.TabIndex = 3;
            this.btnDeleteTasks.Text = "Delete Tasks";
            this.btnDeleteTasks.UseVisualStyleBackColor = true;
            this.btnDeleteTasks.Click += new System.EventHandler(this.btnDeleteTasks_Click);
            // 
            // btnEditTask
            // 
            this.btnEditTask.Location = new System.Drawing.Point(243, 330);
            this.btnEditTask.Name = "btnEditTask";
            this.btnEditTask.Size = new System.Drawing.Size(100, 25);
            this.btnEditTask.TabIndex = 4;
            this.btnEditTask.Text = "Edit Task";
            this.btnEditTask.UseVisualStyleBackColor = true;
            this.btnEditTask.Click += new System.EventHandler(this.btnEditTask_Click);
            // 
            // btnRunTask
            // 
            this.btnRunTask.Location = new System.Drawing.Point(360, 330);
            this.btnRunTask.Name = "btnRunTask";
            this.btnRunTask.Size = new System.Drawing.Size(100, 25);
            this.btnRunTask.TabIndex = 6;
            this.btnRunTask.Text = "Run Task";
            this.btnRunTask.UseVisualStyleBackColor = true;
            this.btnRunTask.Click += new System.EventHandler(this.btnRunTask_Click);
            // 
            // btnLog
            // 
            this.btnLog.Location = new System.Drawing.Point(476, 330);
            this.btnLog.Name = "btnLog";
            this.btnLog.Size = new System.Drawing.Size(97, 25);
            this.btnLog.TabIndex = 7;
            this.btnLog.Text = "Show Log";
            this.btnLog.UseVisualStyleBackColor = true;
            this.btnLog.Click += new System.EventHandler(this.btnLog_Click);
            // 
            // btStat
            // 
            this.btStat.Location = new System.Drawing.Point(580, 330);
            this.btStat.Name = "btStat";
            this.btStat.Size = new System.Drawing.Size(97, 25);
            this.btStat.TabIndex = 8;
            this.btStat.Text = "Show Statistics";
            this.btStat.UseVisualStyleBackColor = true;
            this.btStat.Click += new System.EventHandler(this.btStat_Click);
            // 
            // frmScheduler
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(689, 372);
            this.Controls.Add(this.btStat);
            this.Controls.Add(this.btnLog);
            this.Controls.Add(this.btnRunTask);
            this.Controls.Add(this.btnEditTask);
            this.Controls.Add(this.btnDeleteTasks);
            this.Controls.Add(this.lblDataLoadTasks);
            this.Controls.Add(this.btnAddTasks);
            this.Controls.Add(this.dgvDataLoadTasks);
            this.Name = "frmScheduler";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Task Scheduler";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDataLoadTasks)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.DataGridView dgvDataLoadTasks;
        private System.Windows.Forms.Button btnAddTasks;
        private System.Windows.Forms.Label lblDataLoadTasks;
        private System.Windows.Forms.Button btnDeleteTasks;
        private System.Windows.Forms.Button btnEditTask;
        private System.Windows.Forms.Button btnRunTask;
        private System.Windows.Forms.Button btnLog;
        private System.Windows.Forms.Button btStat;
    }
}


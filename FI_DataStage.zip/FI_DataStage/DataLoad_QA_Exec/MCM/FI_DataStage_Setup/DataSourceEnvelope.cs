﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FI_DataStage;
using System.Xml.Serialization;
namespace FI_DataTranformations
{
    public class DataSourceEnvelope
    {
        public DataSourceClass Table;

        public ChildDataSource ChildTable;

        public DataSourceEnvelope()
        {
            Table = null;
            ChildTable = null;
        }
        public DataSourceEnvelope(DataSourceClass  ds)
        {
            Table = ds;
            ChildTable = null;
        }

        public void Add(DataSourceClass Dsrc, IDType PID, IDType CID, JoinType jn)
        {
            if (Table == null)
            {
                Table = Dsrc;
                ChildTable = null;
            }
            else
            {
                AddChild(new ChildDataSource(Dsrc, PID, CID, jn));

            }
        }
        private void AddChild(ChildDataSource cld)
        {
            if (ChildTable == null)
            {
                ChildTable = cld;
            }
            else
            {
                ChildTable.Tab.AddChild(cld);
            }
        }
    }

    public class ChildDataSource
    {
        
        public DataSourceEnvelope Tab;

        
        public IDType ParentID, ChildID;
        public JoinType jointype;
        public ChildDataSource() { }
        public ChildDataSource(DataSourceClass ds, IDType pid, IDType cid, JoinType jn)
        {
            Tab = new DataSourceEnvelope(ds);
            ParentID = pid;
            ChildID = cid;
            jointype = jn;
            Tab.ChildTable = null;
        }
    }
}

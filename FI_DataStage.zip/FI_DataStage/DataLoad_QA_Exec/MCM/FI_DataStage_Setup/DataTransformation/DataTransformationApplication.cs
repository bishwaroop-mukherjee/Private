﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FI_DataStage;
using Scheduler;
using System.Data;
using FI_DataTranformations;
using System.Xml.Serialization;


namespace Scheduler.DataTransformation
{
    public class DataTransformationApplication
    {
        public DataTable GetTransformedData(Scheduler.EntityModel.Data_Load_Item dlI)
        {
            //deserialize Transformation xml
            //Call transformations

            DataSourceFactory dsf = new DataSourceFactory();

            return new DataTable();
        }

        

    }
}

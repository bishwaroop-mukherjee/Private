﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Scheduler.EntityModel;

namespace Scheduler
{

    public partial class frmScheduler : Form
    {
        Scheduler.TaskScheduler ts;
        List<Data_Load_Item> schItems = null;

        public frmScheduler()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //ts = new TaskScheduler();
            //ts.schedule(DateTime.Now);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Start();
            FillData();
        }

        private void FillData()
        {

            using (FI_Data_SchedulerEntities3 context = new FI_Data_SchedulerEntities3())
            {
                schItems = new List<Data_Load_Item>(
                            from LoadItem in context.Data_Load_Item
                            select LoadItem);

                DataGridViewButtonColumn dgvCBC = new DataGridViewButtonColumn();
                
                dgvCBC.Name = "Delete";
                dgvCBC.HeaderText = "Delete";
                dgvCBC.Text = "Delete";
                dgvDataLoadTasks.DataSource = schItems;
                dgvDataLoadTasks.Columns.Add(dgvCBC);
                dgvDataLoadTasks.Columns["Load_Item_ID"].Visible = false;
                dgvDataLoadTasks.Columns["Destination_Table_Name"].Visible = false;
                dgvDataLoadTasks.Columns["Header_Present"].Visible = false;
                dgvDataLoadTasks.Columns["Delimiter_Present"].Visible = false;
                dgvDataLoadTasks.Columns["Delimiter"].Visible = false;
                dgvDataLoadTasks.Columns["Merge_Col"].Visible = false;
                dgvDataLoadTasks.Columns["Destination_Con_String"].Visible = false;
                dgvDataLoadTasks.Columns["Source_Path_String_Value"].Visible = false;
                dgvDataLoadTasks.Columns["Source_Path_String_Name"].Visible = false;
                dgvDataLoadTasks.Columns["Source_Connection_String"].Visible = false;
                dgvDataLoadTasks.Columns["Data_Scheduler"].Visible = false;
                dgvDataLoadTasks.Columns["Range"].Visible = false;
                dgvDataLoadTasks.Columns["SheetName"].Visible = false;
                dgvDataLoadTasks.Columns["HeadSkipRows"].Visible = false;
                dgvDataLoadTasks.Columns["TailSkipRows"].Visible = false;
            }
        }

        private void btnEditTask_Click(object sender, EventArgs e)
        {

        }

        private void btnRunTask_Click(object sender, EventArgs e)
        {
            int rowIndex = dgvDataLoadTasks.SelectedCells[0].RowIndex;

            TaskScheduler ts = new TaskScheduler();
            string strLoadItemName = Convert.ToString(dgvDataLoadTasks.Rows[rowIndex].Cells["Load_Item_Name"].Value);
            //string temp = schItems[rowIndex+2].ToString();
            ts.StaticLoad(strLoadItemName);
        }

        private void btnDeleteTasks_Click(object sender, EventArgs e)
        {
            //DataGridViewRow row = dataGridDataLoadTasks.SelectedCells[0].RowIndex;
            //dataGridDataLoadTasks.Rows.Remove(row);
        }

        private void btnAddTasks_Click(object sender, EventArgs e)
        {
            //dgvDataLoadTasks.Rows.Add();
     
        }

        private void dataGridDataLoadTasks_MouseClick(object sender, MouseEventArgs e)
        {
            
            //if (e.Button == MouseButtons.Right)
            //{
            //    ContextMenu m = new ContextMenu();
            //    m.MenuItems.Add(new MenuItem("Delete"));
            //    m.MenuItems[0].Click += new EventHandler(Delete_Click);
            //    m.Show(dgvDataLoadTasks, new Point(e.X, e.Y));
            //}
        }

        void Delete_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvDataLoadTasks.SelectedRows.Count > 0)
                {
                    
                    dgvDataLoadTasks.Rows.Remove(dgvDataLoadTasks.SelectedRows[0]);
                }
            }
            catch (Exception ex)
            {
                
                throw ex;
            }
        }

        private void dgvDataLoadTasks_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            try
            {
                if (dgvDataLoadTasks.Columns[e.ColumnIndex].Name == "Delete")
                {
                    string str = Convert.ToString(dgvDataLoadTasks.Rows[e.RowIndex].Cells["Load_Item_ID"].Value);
                 
                }
            }
            catch (Exception ex)
            {
            }
        }

        private void btnLog_Click(object sender, EventArgs e)
        {
            int LDID;
            LDID = (int)dgvDataLoadTasks.Rows[dgvDataLoadTasks.SelectedCells[0].RowIndex ].Cells["Load_Item_ID"].Value;
            using (FI_Data_SchedulerEntities3 context = new FI_Data_SchedulerEntities3())
            {
                var schItems = new List<DataStageLog >(
                            from log in context.DataStageLogs 
                            where log.Load_Item_ID == LDID
                            orderby log.DateTimeStamp descending, log.LogType ascending
                            select log);

                
                
                
                frmLog frmlg = new frmLog();

                frmlg.dgvLog.DataSource = schItems;

                frmlg.ShowDialog();
                frmlg.Activate();
            }
            
        }

        private void dgvDataLoadTasks_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btStat_Click(object sender, EventArgs e)
        {
            Stat st = new Stat();
            st.Show();
            int rowIndex = dgvDataLoadTasks.SelectedCells[0].RowIndex;
            int LDID;
            LDID= (int)dgvDataLoadTasks.Rows[dgvDataLoadTasks.SelectedCells[0].RowIndex].Cells["Load_Item_ID"].Value;

            using (FI_Data_SchedulerEntities3 fid = new FI_Data_SchedulerEntities3())
            {

                Data_Load_Item dli = (from d in fid.Data_Load_Item
                                      where d.Load_Item_ID == LDID
                                      select d).First();
                dli.Statistics.Load();
                List<double> DataR = new List<double>(from Statistic d in dli.Statistics.AsEnumerable()
                                                         select Convert.ToDouble( d.Num_Rows_Read  ));
                List<double> DataW = new List<double>(from Statistic d in dli.Statistics.AsEnumerable()
                                                     select Convert.ToDouble(d.Num_Rows_Written ));
                st.DrawAxis();
                st.Plot(DataR,1,10,1,Color.Red );
                st.Plot(DataW, 1, 10, 1, Color.Green );
            }
        }

    }
}

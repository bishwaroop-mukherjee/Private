﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualBasic.PowerPacks;
using System.Windows.Forms;
namespace FI_DataTranformations
{
    public class FtoFConnection:LineShape 
    {
        public TableAdded inForm;
        public TableAdded outForm;
        public FtoFConnection() 
        { 
            BorderWidth = 3; 
            BorderStyle = System.Drawing.Drawing2D.DashStyle.Solid; 
            BorderColor = System.Drawing.Color.FromArgb(150, 150, 150);
            SelectionColor = System.Drawing.Color.Blue;
        }
        public static ShapeContainer GetConContainer(TableAdded src, TableAdded dest)
        {
            ShapeContainer shc = new ShapeContainer();
            FtoFConnection con= new FtoFConnection();

            shc.Shapes.Add(con);
            con.CreateConnection(src, dest);

            return shc;
        }
        public void CreateConnection(TableAdded  src, TableAdded  dest)
        {
            inForm = src;
            outForm = dest;

            if (inForm.tabFrm.Left < outForm.tabFrm.Left)
            {
                this.X1 = inForm.tabFrm.Right;
                this.X2 = outForm.tabFrm.Left;
                this.Y1 = inForm.tabFrm.Top + inForm.tabFrm.Height / 2;
                this.Y2 = outForm.tabFrm.Top + outForm.tabFrm.Height / 2;
            }
            else
            {
                this.X1 = outForm.tabFrm.Right;
                this.X2 = inForm.tabFrm.Left;
                this.Y2 = inForm.tabFrm.Top + inForm.tabFrm.Height / 2;
                this.Y1 = outForm.tabFrm.Top + outForm.tabFrm.Height / 2;
            }
            this.GotFocus += GotFcs ;
            this.LostFocus += LostFcs;
            inForm.tabFrm.Move += frmMove;
            outForm.tabFrm.Move += frmMove;
        }

        public void frmMove(Object sender, EventArgs e)
        {
            if (inForm.tabFrm.Left < outForm.tabFrm.Left)
            {
                this.X1 = inForm.tabFrm.Right;
                this.X2 = outForm.tabFrm.Left;
                this.Y1 = inForm.tabFrm.Top + inForm.tabFrm.Height / 2;
                this.Y2 = outForm.tabFrm.Top + outForm.tabFrm.Height / 2;
            }
            else
            {
                this.X1 = outForm.tabFrm.Right;
                this.X2 = inForm.tabFrm.Left;
                this.Y2 = inForm.tabFrm.Top + inForm.tabFrm.Height / 2;
                this.Y1 = outForm.tabFrm.Top + outForm.tabFrm.Height / 2;
            }
            
        }

        protected void MouseDoubleClick(object sender, EventArgs e)
        {

            //frmPidCid idEntry = new frmPidCid(((IDataSource)jnSrc.Tag).getDataSchema(), ((DataSourceClass)jnDest.Tag).getDataSchema());
            //if (idEntry.generatePidCid(ref Pid, ref Cid, ref jointype) == System.Windows.Forms.DialogResult.OK)
            //{
            //    tablesinjoin.Add(jnSrc, jnDest, (DataSourceClass)jnDest.Tag, Pid, Cid, jointype);

            //}


        }

        protected void GotFcs(Object sender,EventArgs e)
        {
            BorderStyle = System.Drawing.Drawing2D.DashStyle.Solid ;
            BorderColor = System.Drawing.Color.FromArgb(0, 0, 150);
            SelectionColor = System.Drawing.Color.Blue;
        }
        protected void LostFcs(Object sender, EventArgs e)
        {
            BorderStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            BorderColor = System.Drawing.Color.FromArgb(150, 150, 150);
            SelectionColor = System.Drawing.Color.Blue;
        }
    }
}

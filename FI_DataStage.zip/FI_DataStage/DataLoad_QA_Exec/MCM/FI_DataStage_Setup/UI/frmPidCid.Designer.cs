﻿namespace FI_DataTranformations
{
    partial class frmPidCid
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DialogbtGrp = new System.Windows.Forms.GroupBox();
            this.btCancel = new System.Windows.Forms.Button();
            this.btOK = new System.Windows.Forms.Button();
            this.lstParColumn = new System.Windows.Forms.ListBox();
            this.lstChildColumn = new System.Windows.Forms.ListBox();
            this.lblCooseIds = new System.Windows.Forms.Label();
            this.lblParentTable = new System.Windows.Forms.Label();
            this.lblChildTable = new System.Windows.Forms.Label();
            this.lblRelation = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.chkLeft = new System.Windows.Forms.CheckBox();
            this.chkRight = new System.Windows.Forms.CheckBox();
            this.DialogbtGrp.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // DialogbtGrp
            // 
            this.DialogbtGrp.Controls.Add(this.btCancel);
            this.DialogbtGrp.Controls.Add(this.btOK);
            this.DialogbtGrp.Location = new System.Drawing.Point(206, 285);
            this.DialogbtGrp.Name = "DialogbtGrp";
            this.DialogbtGrp.Size = new System.Drawing.Size(172, 39);
            this.DialogbtGrp.TabIndex = 1;
            this.DialogbtGrp.TabStop = false;
            // 
            // btCancel
            // 
            this.btCancel.Location = new System.Drawing.Point(91, 10);
            this.btCancel.Name = "btCancel";
            this.btCancel.Size = new System.Drawing.Size(75, 23);
            this.btCancel.TabIndex = 1;
            this.btCancel.Text = "Cancel";
            this.btCancel.UseVisualStyleBackColor = true;
            this.btCancel.Click += new System.EventHandler(this.btCancel_Click);
            // 
            // btOK
            // 
            this.btOK.Location = new System.Drawing.Point(6, 10);
            this.btOK.Name = "btOK";
            this.btOK.Size = new System.Drawing.Size(75, 23);
            this.btOK.TabIndex = 0;
            this.btOK.Text = "OK";
            this.btOK.UseVisualStyleBackColor = true;
            this.btOK.Click += new System.EventHandler(this.btOK_Click);
            // 
            // lstParColumn
            // 
            this.lstParColumn.FormattingEnabled = true;
            this.lstParColumn.Location = new System.Drawing.Point(23, 85);
            this.lstParColumn.Name = "lstParColumn";
            this.lstParColumn.Size = new System.Drawing.Size(120, 108);
            this.lstParColumn.TabIndex = 2;
            // 
            // lstChildColumn
            // 
            this.lstChildColumn.FormattingEnabled = true;
            this.lstChildColumn.Location = new System.Drawing.Point(258, 85);
            this.lstChildColumn.Name = "lstChildColumn";
            this.lstChildColumn.Size = new System.Drawing.Size(120, 108);
            this.lstChildColumn.TabIndex = 3;
            // 
            // lblCooseIds
            // 
            this.lblCooseIds.AutoSize = true;
            this.lblCooseIds.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCooseIds.Location = new System.Drawing.Point(20, 20);
            this.lblCooseIds.Name = "lblCooseIds";
            this.lblCooseIds.Size = new System.Drawing.Size(104, 14);
            this.lblCooseIds.TabIndex = 4;
            this.lblCooseIds.Text = "Define the join";
            // 
            // lblParentTable
            // 
            this.lblParentTable.AutoSize = true;
            this.lblParentTable.Location = new System.Drawing.Point(20, 51);
            this.lblParentTable.Name = "lblParentTable";
            this.lblParentTable.Size = new System.Drawing.Size(68, 13);
            this.lblParentTable.TabIndex = 5;
            this.lblParentTable.Text = "Parent Table";
            // 
            // lblChildTable
            // 
            this.lblChildTable.AutoSize = true;
            this.lblChildTable.Location = new System.Drawing.Point(255, 51);
            this.lblChildTable.Name = "lblChildTable";
            this.lblChildTable.Size = new System.Drawing.Size(60, 13);
            this.lblChildTable.TabIndex = 6;
            this.lblChildTable.Text = "Child Table";
            // 
            // lblRelation
            // 
            this.lblRelation.AutoSize = true;
            this.lblRelation.Location = new System.Drawing.Point(158, 135);
            this.lblRelation.Name = "lblRelation";
            this.lblRelation.Size = new System.Drawing.Size(85, 13);
            this.lblRelation.TabIndex = 7;
            this.lblRelation.Text = "<---------------------->";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.chkRight);
            this.groupBox1.Controls.Add(this.chkLeft);
            this.groupBox1.Location = new System.Drawing.Point(23, 205);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(355, 74);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Select Join Type";
            // 
            // chkLeft
            // 
            this.chkLeft.Location = new System.Drawing.Point(7, 20);
            this.chkLeft.Name = "chkLeft";
            this.chkLeft.Size = new System.Drawing.Size(306, 24);
            this.chkLeft.TabIndex = 0;
            this.chkLeft.Text = "Select all from Parent Table";
            this.chkLeft.UseVisualStyleBackColor = true;
            this.chkLeft.CheckedChanged += new System.EventHandler(this.chkLeft_CheckedChanged);
            // 
            // chkRight
            // 
            this.chkRight.Location = new System.Drawing.Point(7, 47);
            this.chkRight.Name = "chkRight";
            this.chkRight.Size = new System.Drawing.Size(306, 21);
            this.chkRight.TabIndex = 1;
            this.chkRight.Text = "Select all from Child Table";
            this.chkRight.UseVisualStyleBackColor = true;
            // 
            // frmPidCid
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(397, 339);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lblRelation);
            this.Controls.Add(this.lblChildTable);
            this.Controls.Add(this.lblParentTable);
            this.Controls.Add(this.lblCooseIds);
            this.Controls.Add(this.lstChildColumn);
            this.Controls.Add(this.lstParColumn);
            this.Controls.Add(this.DialogbtGrp);
            this.Name = "frmPidCid";
            this.Text = "frmPidCid";
            this.Load += new System.EventHandler(this.frmPidCid_Load);
            this.DialogbtGrp.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox DialogbtGrp;
        private System.Windows.Forms.Button btCancel;
        private System.Windows.Forms.Button btOK;
        private System.Windows.Forms.ListBox lstParColumn;
        private System.Windows.Forms.ListBox lstChildColumn;
        private System.Windows.Forms.Label lblCooseIds;
        private System.Windows.Forms.Label lblParentTable;
        private System.Windows.Forms.Label lblChildTable;
        private System.Windows.Forms.Label lblRelation;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox chkRight;
        private System.Windows.Forms.CheckBox chkLeft;
    }
}
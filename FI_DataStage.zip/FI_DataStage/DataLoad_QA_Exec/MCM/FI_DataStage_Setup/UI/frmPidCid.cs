﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FI_DataStage;

namespace FI_DataTranformations
{
    public partial class frmPidCid : Form
    {
        IDType ParID, ChildID;
        JoinType jnType;
        List<string> ParSchema, ChildSchema;
        public frmPidCid()
        {
            InitializeComponent();
        }
        public frmPidCid(List<string > PSch, List<string> CSch)
        {
            
            InitializeComponent();
            ParSchema = new List<string>( PSch);
            ChildSchema = new List<string>(CSch);
        }
        public System.Windows.Forms.DialogResult generatePidCid(ref IDType pid, ref IDType cid, ref JoinType jn)
        {
            System.Windows.Forms.DialogResult RetRes;
            if ((RetRes = ShowDialog()) == System.Windows.Forms.DialogResult.OK)
            {
                pid = ParID;
                cid = ChildID;
                jn = jnType;
            }
            else
            {
                pid = null;
                cid = null;
                jn = JoinType.Inner;
            }
            return RetRes;
        }

        private void frmPidCid_Load(object sender, EventArgs e)
        {
            ParID = new IDType(null, typeof(string));
            ChildID = new IDType(null, typeof(string));

            lstParColumn.DataSource = ParSchema;
            lstChildColumn.DataSource = ChildSchema;
        }

        private void btOK_Click(object sender, EventArgs e)
        {
            ParID.ID = lstParColumn.SelectedItem;
            ChildID.ID = lstChildColumn.SelectedItem;
            if (chkLeft.Checked == true && chkRight.Checked == true)
                jnType = JoinType.Outer;
            else if (chkLeft.Checked == true && chkRight.Checked == false)
                jnType = JoinType.LeftOuter;
            else if (chkLeft.Checked == false && chkRight.Checked == true)
                jnType = JoinType.RightOuter;
            else if (chkLeft.Checked == false && chkRight.Checked == false)
                jnType = JoinType.Inner;

            this.DialogResult = System.Windows.Forms.DialogResult.OK ;
            this.Close();
        }

        private void btCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Close();

        }

        private void chkLeft_CheckedChanged(object sender, EventArgs e)
        {
            if(chkLeft.Checked==true && chkRight.Checked == true)
                jnType=JoinType.Outer ;
            else if(chkLeft.Checked==true && chkRight.Checked == false)
                jnType=JoinType.LeftOuter;
            else if(chkLeft.Checked==false && chkRight.Checked == true)
                jnType = JoinType.RightOuter;
            else if(chkLeft.Checked==false && chkRight.Checked == false)
                jnType=JoinType.Inner ;
        }



    }
}

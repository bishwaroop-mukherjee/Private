﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace FI_DataTranformations
{
    public partial class frmTable : Form
    {
        public frmTable()
        {
            InitializeComponent();
            //frmTable frm = new frmTable();
        }
        public void FillSchema(List<string> fields)
        {
            dgFields.DataSource = fields.Select(x => new { Value = x }).ToList();
            dgFields.Columns[0].HeaderText = "Fields";
        }
        private void frmTable_Move(object sender, EventArgs e)
        {
            
        }


        private void dgFields_MouseDown(object sender, MouseEventArgs e)
        {
            frmTransfomationWorkspace frmtemp = (frmTransfomationWorkspace)this.ParentForm;
            if (frmtemp.AddingMode)
            {
                frmtemp.TabClick(this,e);
            }

        }

        private void dgFields_MouseEnter(object sender, EventArgs e)
        {
            frmTransfomationWorkspace frmtemp = (frmTransfomationWorkspace)this.ParentForm;
            if (frmtemp.AddingMode)
            {
                frmtemp.TabOver(this, e);
            }

        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;
using System.Xml.Serialization;
using System.IO;
using FI_DataStage;
using Ionic.Zip;

namespace FI_DataTranformations
{
    public partial class frmTransfomationWorkspace : Form
    {
        public Boolean AddingMode=false;
        frmTable  jnSrc=null;
        frmTable jnDest=null;
        Pen DrawingPen;
        DataTransformations dtTrans;
        TableAdded tblAdded;

        //To maintain the positions of the table Elements
        
        TableAdded tablesinjoin;
        public frmTransfomationWorkspace()
        {
            InitializeComponent();
            tablesinjoin = null;
            SolidBrush drawingbrush = new System.Drawing.SolidBrush(Color.Blue);
            
            DrawingPen = new System.Drawing.Pen(drawingbrush,3);
        }

        private void tEXTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmTable frmTab = new frmTable();
            frmTab.Text = "TableName";
           
            frmTab.MdiParent = this;
            panel1.Controls.Add(frmTab);
            frmTab.MouseEnter += TabOver;
            frmTab.MouseDown  += TabClick;
            //frmTab.Move+= TabMove;
            frmTab.Show();
        }

        private void addJoinToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddingMode=true;
            panel1.Cursor = Cursors.Cross ;
            jnSrc = null;
            jnDest = null;
        }
        public void TabOver(Object sender, EventArgs e)
        {
            frmTable frmTemp = (frmTable)sender;
            
            frmTemp.Activate();
        }
        public void TabClick(Object sender, MouseEventArgs  e)
        {
            IDType Pid=null, Cid=null;
            JoinType jointype = JoinType.Inner;
            if (AddingMode == true)
            {
                if (jnSrc == null)
                {
                    jnSrc = (frmTable)sender;
                    
                    if (tablesinjoin == null)
                    {
                        tablesinjoin = new TableAdded();
                        tablesinjoin.Add(null,jnSrc,(DataSourceClass)jnSrc.Tag,null,null , JoinType.Inner );
                    }
                }
                else
                {
                    jnDest = (frmTable)sender;

                    //Populate DataSource envelope
                    AddingMode = false;
                    panel1.Cursor = Cursors.Arrow;
                    if (tablesinjoin != null)
                    {
                        try
                        { 
                            //Pid/Cid
                            frmPidCid idEntry = new frmPidCid(((IDataSource)jnSrc.Tag).getDataSchema(), ((DataSourceClass)jnDest.Tag).getDataSchema());
                            if (idEntry.generatePidCid(ref Pid,ref Cid, ref jointype ) == System.Windows.Forms.DialogResult.OK)
                            {
                                tablesinjoin.Add(jnSrc, jnDest, (DataSourceClass)jnDest.Tag, Pid, Cid,jointype );

                            }
                            //generatePidCid(ref Pid,ref Cid);
                        }
                        catch(Exception ex)
                        {
                            MessageBox.Show(ex.Message );
                        }
                    }
                    jnSrc = null;
                    jnDest = null;
                }
                Graphics g = panel1.CreateGraphics();
                g.Clear(panel1.BackColor);
                DrawConnections(tablesinjoin, g);
            }
            else
            {
                jnSrc = null;
                jnDest = null;
            }
        
        }

        public void TabMove(Object sender,EventArgs e)
        {
            Graphics g = panel1.CreateGraphics();
            g.Clear(panel1.BackColor );
            DrawConnections(tablesinjoin,g);
        }
        void DrawConnections(TableAdded t, Graphics g)
        {
            if (t == null ) return;
            if (t.JoinedTo != null)
            {
                frmTable left, right;
                foreach (TableAdded tab in t.JoinedTo)
                {
                    if (t.tabFrm.Location.X < tab.tabFrm.Location.X)
                    {
                        left = t.tabFrm;
                        right = tab.tabFrm;
                    }
                    else
                    {
                        left = tab.tabFrm;
                        right = t.tabFrm;
                    }

                    panel1.Controls.Add(FtoFConnection.GetConContainer(t, tab));
                    //cn.CreateConnection(t.tabFrm, tab.tabFrm);
                    /*g.DrawLine(DrawingPen,
                                new Point(left.Location.X + left.Width, left.Location.Y + left.Height / 2),
                                new Point(right.Location.X, right.Location.Y + right.Height / 2));
                    */

                    DrawConnections(tab, g);

                }
            }
        }

        private void addDatasourceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            IDataSource DataSource;
            frmDataSourceProp dsp = new frmDataSourceProp();
            DataSource = dsp.GetDataSource();
            if (DataSource != null)
            {

                frmTable frmTab = new frmTable();
                frmTab.Text = DataSource.TableName ;
                frmTab.FillSchema(DataSource.getDataSchema());
                frmTab.Tag = DataSource;
                frmTab.MdiParent = this;
                panel1.Controls.Add(frmTab);
                frmTab.MouseEnter += TabOver;
                frmTab.MouseDown += TabClick;
                //frmTab.Move += TabMove;
                frmTab.Show();

                trVDs.Nodes["dsroot"].Nodes.Add(DataSource.TableName, DataSource.TableName,1);
            }
        }

        private void frmTransfomationWorkspace_Load(object sender, EventArgs e)
        {
            trVDs.Nodes.Add("dsroot", "Data Sources",0);

        }

        private void btnRun_Click(object sender, EventArgs e)
        {
            DataTable dt;
            dtTrans = new DataTransformations();
            IDType Pid = new IDType(null, typeof(String));
            IDType Cid = new IDType(null,typeof(String));
            tablesinjoin.PrepareJoin(dtTrans.SourceData);

            dt = dtTrans.JoinSource();
            dgDataPreview.DataSource = dt;
            //FI_DataTranformations.Join;

        }

        private void btnCompile_Click(object sender, EventArgs e)
        {
            dtTrans = new DataTransformations();
            IDType Pid = new IDType(tablesinjoin.Pid.ID, tablesinjoin.Pid.DataType), Cid = new IDType(tablesinjoin.Cid.ID, tablesinjoin.Cid.DataType);
            tablesinjoin.PrepareJoin(dtTrans.SourceData);
        }

        private void removeDatasourceToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void tsbSave_Click(object sender, EventArgs e)
        {
            if (dlgSaveTrans.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                dtTrans = null;
                FileInfo finf = new FileInfo(dlgSaveTrans.FileName);
                dtTrans = new DataTransformations();
                tablesinjoin.PrepareJoin(dtTrans.SourceData);
                XmlSerializer xmlS = new XmlSerializer(typeof(DataTransformations));
                XmlSerializer xmlG = new XmlSerializer(typeof(TableAdded));
                FileStream fst = new FileStream(finf.DirectoryName + "\\TransFormations.xml" , FileMode.CreateNew );
                FileStream fst1 = new FileStream(finf.DirectoryName + "\\TrGui.xml", FileMode.CreateNew );
                //FileStream ZipArchst = new FileStream(finf.FullName,FileMode.CreateNew|FileMode.Truncate );
                //Ionic.Zlib.GZipStream ZipArch = new GZipStream(ZipArchst, CompressionMode.Compress);
                
                xmlG.Serialize(fst1, tablesinjoin);
                xmlS.Serialize(fst, dtTrans);

                if(File.Exists(finf.FullName))
                    File.Delete(finf.FullName);

                Ionic.Zip.ZipFile ZipArch = new ZipFile(finf.FullName);
                ZipArch.AddFile(finf.DirectoryName + "\\TransFormations.xml","");
                ZipArch.AddFile(finf.DirectoryName + "\\TrGui.xml","");
                ZipArch.Save();
                fst.Close();
                fst1.Close();
                ZipArch.Dispose();
                File.Delete(finf.DirectoryName + "\\TransFormations.xml");
                File.Delete(finf.DirectoryName + "\\TrGui.xml");
            }
        }


        private void tsbOpen_Click(object sender, EventArgs e)
        {
            if (dlgOpenTrans.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                DataTable dt;
                dtTrans = null;
                tablesinjoin  = null;
                panel1.Controls.Clear();
                Graphics g = panel1.CreateGraphics();
                g.Clear(panel1.BackColor);
                FileInfo finf = new FileInfo(dlgOpenTrans.FileName);
                ZipFile ZipArch = new ZipFile(finf.FullName);
                DirectoryInfo dinf;
                dinf = Directory.CreateDirectory(Application.StartupPath  + "\\" + finf.Name );
                
                ZipArch.ExtractAll(dinf.FullName  );
                XmlSerializer xmlS = new XmlSerializer(typeof(DataTransformations));
                XmlSerializer xmlG = new XmlSerializer(typeof(TableAdded));

                FileStream fst = new FileStream(dinf.FullName +"\\TransFormations.xml", FileMode.Open);
                dtTrans = (DataTransformations)xmlS.Deserialize(fst);

                FileStream fst1 = new FileStream(dinf.FullName + "\\TrGUI.xml", FileMode.Open);
                tablesinjoin  = (TableAdded)xmlG.Deserialize(fst1);

                dt = dtTrans.JoinSource();
                dgDataPreview.DataSource = dt;
                
                tablesinjoin.FillForm(this,ref panel1,ref trVDs );
                DrawConnections(tablesinjoin, g);

                fst.Close();
                fst1.Close();
                ZipArch.Dispose();
                Directory.Delete(dinf.FullName,true );
            }
            
        }
    }
}

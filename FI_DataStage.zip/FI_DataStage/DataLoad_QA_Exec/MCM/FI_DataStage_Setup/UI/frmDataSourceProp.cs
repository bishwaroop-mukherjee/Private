﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FI_DataStage;
using System.Data.OleDb;
using System.Data.Odbc;
using System.Data.Common;

namespace FI_DataTranformations
{
    public partial class frmDataSourceProp : Form
    {
        IDataSource DataSource;
        DataSourceFactory dsFactory;

        public frmDataSourceProp()
        {
            InitializeComponent();
        }

        private void btOK_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void btCancel_Click(object sender, EventArgs e)
        {
            DataSource = null;
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }


        public IDataSource GetDataSource()
        {
            if (ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                if (DataSource != null)
                    return DataSource;
                else
                    throw new DataLoaderException("Data source creation failed", null);
            }
            else 
            { return null; }

        }

        private void tbSourcePath_Validated(object sender, EventArgs e)
        {
            dsFactory = new DataSourceFactory(tbTableName.Text, cbSourceType.Text, tbSourcePath.Text, tbSheetName.Text , "A1", 0, 0, ",", true, false, null);
            DataSource = dsFactory.GetDataSourceInstance();
            dgPreview.DataSource = DataSource.getDataTable();
            dgPreview.Refresh();
        }

        private void cbSourceType_SelectionChangeCommitted(object sender, EventArgs e)
        {
            tbTableName.Enabled = true;
            tbTableName.Text = tbTableName.Text + cbSourceType.SelectedItem ;         
        }

        private void tbHeadSkipRows_Validated(object sender, EventArgs e)
        {
            if (tbHeadSkipRows.Text != "")
            DataSource.HeadSkipRows = Convert.ToInt32(tbHeadSkipRows.Text);
            dgPreview.DataSource = DataSource.getDataTable();
            dgPreview.Refresh();
        }

        private void tbTailSkipRows_Validated(object sender, EventArgs e)
        {
            if(tbTailSkipRows.Text!="")
            DataSource.TailSkipRows  = Convert.ToInt32(tbTailSkipRows.Text);
            dgPreview.DataSource = DataSource.getDataTable();
            dgPreview.Refresh();
        }

        private void cbHeader_Present_CheckedChanged(object sender, EventArgs e)
        {
            DataSource.Header_Present = cbHeader_Present.Checked;
            dgPreview.DataSource = DataSource.getDataTable();
            dgPreview.Refresh();
        }

        private void cbMergeDelim_CheckedChanged(object sender, EventArgs e)
        {
            DataSource.Merge_Delim  = cbMergeDelim.Checked ;
            dgPreview.DataSource = DataSource.getDataTable();
            dgPreview.Refresh();
        }

        private void tbDelimiter_Validated(object sender, EventArgs e)
        {

            if (tbDelimiter.Text.ToUpper() == "TAB")
                DataSource.Delim = "\t";
            else
                DataSource.Delim = tbDelimiter.Text;
            dgPreview.DataSource = DataSource.getDataTable();
            dgPreview.Refresh();

           
        }

        private void btnBrowseSource_Click(object sender, EventArgs e)
        {
            MSDASC.DataLinks dl=new MSDASC.DataLinks();
            ADODB.Connection con;

            if (cbSourceType.Text == "ACCESS" || cbSourceType.Text == "RDBMS")
            {
                
                con = (ADODB.Connection)dl.PromptNew();

                string cons = con.ConnectionString.ToString();
                MessageBox.Show(cons);
            }
            else
            {
                if (dlgFileSource.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    tbSourcePath.Text  = dlgFileSource.FileName;
                    
                    dsFactory = new DataSourceFactory(tbTableName.Text, cbSourceType.Text, tbSourcePath.Text, tbSheetName.Text, "A1", 0, 0, ",", true, false, null);
                    DataSource = dsFactory.GetDataSourceInstance();
                    dgPreview.DataSource = DataSource.getDataTable();
                    dgPreview.Refresh();

                    tbTailSkipRows.Text = "";
                    tbSheetName.Text = "";
                    tbDelimiter.Text = "";
                    tbHeadSkipRows.Text = "";
                    cbHeader_Present.Checked = false;
                    cbMergeDelim.Checked = false;
                    tbDelimiter.Enabled = true;
                    tbSheetName.Enabled = true;
                }
            }
            cbMergeDelim.Enabled = true;
            cbSourceType.Enabled = true;
            tbTailSkipRows.Enabled = true;
            tbHeadSkipRows.Enabled = true;


        }

        private void frmDataSourceProp_Load(object sender, EventArgs e)
        {
            tbTableName.Enabled = false;
            btnBrowseSource.Enabled = false;
            tbSourcePath.Enabled = false;
            cbSourceType.Enabled = true;
            cbHeader_Present.Enabled = false;
            cbMergeDelim.Enabled = false;
            tbTailSkipRows.Enabled = false;
            tbHeadSkipRows.Enabled = false;
            tbSheetName.Enabled = false;
            tbDelimiter.Enabled = false;
        }

        private void tbTableName_Leave(object sender, EventArgs e)
        {
            btnBrowseSource.Enabled = true;
        }



    }
}

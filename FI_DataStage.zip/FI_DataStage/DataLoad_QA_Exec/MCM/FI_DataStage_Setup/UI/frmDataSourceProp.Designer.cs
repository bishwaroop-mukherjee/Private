﻿namespace FI_DataTranformations
{
    partial class frmDataSourceProp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dlgFileSource = new System.Windows.Forms.OpenFileDialog();
            this.DialogbtGrp = new System.Windows.Forms.GroupBox();
            this.btCancel = new System.Windows.Forms.Button();
            this.btOK = new System.Windows.Forms.Button();
            this.sourceType = new System.Windows.Forms.Label();
            this.cbSourceType = new System.Windows.Forms.ComboBox();
            this.tbSourcePath = new System.Windows.Forms.TextBox();
            this.btnBrowseSource = new System.Windows.Forms.Button();
            this.lblHeadSkipRows = new System.Windows.Forms.Label();
            this.lblTailSkipRows = new System.Windows.Forms.Label();
            this.tbHeadSkipRows = new System.Windows.Forms.TextBox();
            this.tbTailSkipRows = new System.Windows.Forms.TextBox();
            this.lblDelimiter = new System.Windows.Forms.Label();
            this.tbDelimiter = new System.Windows.Forms.TextBox();
            this.lblSheetName = new System.Windows.Forms.Label();
            this.tbSheetName = new System.Windows.Forms.TextBox();
            this.gpPreview = new System.Windows.Forms.GroupBox();
            this.dgPreview = new System.Windows.Forms.DataGridView();
            this.tbTableName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cbHeader_Present = new System.Windows.Forms.CheckBox();
            this.cbMergeDelim = new System.Windows.Forms.CheckBox();
            this.DialogbtGrp.SuspendLayout();
            this.gpPreview.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgPreview)).BeginInit();
            this.SuspendLayout();
            // 
            // dlgFileSource
            // 
            this.dlgFileSource.FileName = "dlgFileSource";
            // 
            // DialogbtGrp
            // 
            this.DialogbtGrp.Controls.Add(this.btCancel);
            this.DialogbtGrp.Controls.Add(this.btOK);
            this.DialogbtGrp.Location = new System.Drawing.Point(205, 318);
            this.DialogbtGrp.Name = "DialogbtGrp";
            this.DialogbtGrp.Size = new System.Drawing.Size(172, 39);
            this.DialogbtGrp.TabIndex = 0;
            this.DialogbtGrp.TabStop = false;
            // 
            // btCancel
            // 
            this.btCancel.Location = new System.Drawing.Point(91, 10);
            this.btCancel.Name = "btCancel";
            this.btCancel.Size = new System.Drawing.Size(75, 23);
            this.btCancel.TabIndex = 1;
            this.btCancel.Text = "Cancel";
            this.btCancel.UseVisualStyleBackColor = true;
            this.btCancel.Click += new System.EventHandler(this.btCancel_Click);
            // 
            // btOK
            // 
            this.btOK.Location = new System.Drawing.Point(6, 10);
            this.btOK.Name = "btOK";
            this.btOK.Size = new System.Drawing.Size(75, 23);
            this.btOK.TabIndex = 0;
            this.btOK.Text = "OK";
            this.btOK.UseVisualStyleBackColor = true;
            this.btOK.Click += new System.EventHandler(this.btOK_Click);
            // 
            // sourceType
            // 
            this.sourceType.AutoSize = true;
            this.sourceType.Location = new System.Drawing.Point(8, 67);
            this.sourceType.Name = "sourceType";
            this.sourceType.Size = new System.Drawing.Size(101, 13);
            this.sourceType.TabIndex = 1;
            this.sourceType.Text = "Select Source Type";
            // 
            // cbSourceType
            // 
            this.cbSourceType.FormattingEnabled = true;
            this.cbSourceType.Items.AddRange(new object[] {
            "TEXT",
            "CSV",
            "XML",
            "EXCEL",
            "ACCESS",
            "RDBMS"});
            this.cbSourceType.Location = new System.Drawing.Point(115, 64);
            this.cbSourceType.Name = "cbSourceType";
            this.cbSourceType.Size = new System.Drawing.Size(262, 21);
            this.cbSourceType.TabIndex = 2;
            this.cbSourceType.SelectionChangeCommitted += new System.EventHandler(this.cbSourceType_SelectionChangeCommitted);
            // 
            // tbSourcePath
            // 
            this.tbSourcePath.Enabled = false;
            this.tbSourcePath.Location = new System.Drawing.Point(115, 99);
            this.tbSourcePath.Name = "tbSourcePath";
            this.tbSourcePath.Size = new System.Drawing.Size(262, 20);
            this.tbSourcePath.TabIndex = 3;
            this.tbSourcePath.Validated += new System.EventHandler(this.tbSourcePath_Validated);
            // 
            // btnBrowseSource
            // 
            this.btnBrowseSource.Location = new System.Drawing.Point(279, 135);
            this.btnBrowseSource.Name = "btnBrowseSource";
            this.btnBrowseSource.Size = new System.Drawing.Size(98, 23);
            this.btnBrowseSource.TabIndex = 4;
            this.btnBrowseSource.Text = "Browse Source";
            this.btnBrowseSource.UseVisualStyleBackColor = true;
            this.btnBrowseSource.Click += new System.EventHandler(this.btnBrowseSource_Click);
            // 
            // lblHeadSkipRows
            // 
            this.lblHeadSkipRows.AutoSize = true;
            this.lblHeadSkipRows.Location = new System.Drawing.Point(7, 246);
            this.lblHeadSkipRows.Name = "lblHeadSkipRows";
            this.lblHeadSkipRows.Size = new System.Drawing.Size(87, 13);
            this.lblHeadSkipRows.TabIndex = 5;
            this.lblHeadSkipRows.Text = "Head Skip Rows";
            // 
            // lblTailSkipRows
            // 
            this.lblTailSkipRows.AutoSize = true;
            this.lblTailSkipRows.Location = new System.Drawing.Point(8, 280);
            this.lblTailSkipRows.Name = "lblTailSkipRows";
            this.lblTailSkipRows.Size = new System.Drawing.Size(78, 13);
            this.lblTailSkipRows.TabIndex = 6;
            this.lblTailSkipRows.Text = "Tail Skip Rows";
            // 
            // tbHeadSkipRows
            // 
            this.tbHeadSkipRows.Location = new System.Drawing.Point(100, 239);
            this.tbHeadSkipRows.Name = "tbHeadSkipRows";
            this.tbHeadSkipRows.Size = new System.Drawing.Size(84, 20);
            this.tbHeadSkipRows.TabIndex = 7;
            this.tbHeadSkipRows.Validated += new System.EventHandler(this.tbHeadSkipRows_Validated);
            // 
            // tbTailSkipRows
            // 
            this.tbTailSkipRows.Location = new System.Drawing.Point(100, 277);
            this.tbTailSkipRows.Name = "tbTailSkipRows";
            this.tbTailSkipRows.Size = new System.Drawing.Size(84, 20);
            this.tbTailSkipRows.TabIndex = 8;
            this.tbTailSkipRows.Validated += new System.EventHandler(this.tbTailSkipRows_Validated);
            // 
            // lblDelimiter
            // 
            this.lblDelimiter.AutoSize = true;
            this.lblDelimiter.Location = new System.Drawing.Point(200, 242);
            this.lblDelimiter.Name = "lblDelimiter";
            this.lblDelimiter.Size = new System.Drawing.Size(47, 13);
            this.lblDelimiter.TabIndex = 13;
            this.lblDelimiter.Text = "Delimiter";
            // 
            // tbDelimiter
            // 
            this.tbDelimiter.Location = new System.Drawing.Point(292, 239);
            this.tbDelimiter.Name = "tbDelimiter";
            this.tbDelimiter.Size = new System.Drawing.Size(84, 20);
            this.tbDelimiter.TabIndex = 14;
            this.tbDelimiter.Validated += new System.EventHandler(this.tbDelimiter_Validated);
            // 
            // lblSheetName
            // 
            this.lblSheetName.AutoSize = true;
            this.lblSheetName.Location = new System.Drawing.Point(200, 280);
            this.lblSheetName.Name = "lblSheetName";
            this.lblSheetName.Size = new System.Drawing.Size(66, 13);
            this.lblSheetName.TabIndex = 15;
            this.lblSheetName.Text = "Sheet Name";
            // 
            // tbSheetName
            // 
            this.tbSheetName.Location = new System.Drawing.Point(292, 277);
            this.tbSheetName.Name = "tbSheetName";
            this.tbSheetName.Size = new System.Drawing.Size(84, 20);
            this.tbSheetName.TabIndex = 16;
            // 
            // gpPreview
            // 
            this.gpPreview.Controls.Add(this.dgPreview);
            this.gpPreview.Location = new System.Drawing.Point(417, 13);
            this.gpPreview.Name = "gpPreview";
            this.gpPreview.Size = new System.Drawing.Size(235, 344);
            this.gpPreview.TabIndex = 17;
            this.gpPreview.TabStop = false;
            this.gpPreview.Text = "Preview";
            // 
            // dgPreview
            // 
            this.dgPreview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgPreview.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgPreview.Location = new System.Drawing.Point(3, 16);
            this.dgPreview.Name = "dgPreview";
            this.dgPreview.Size = new System.Drawing.Size(229, 325);
            this.dgPreview.TabIndex = 0;
            // 
            // tbTableName
            // 
            this.tbTableName.Location = new System.Drawing.Point(115, 29);
            this.tbTableName.Name = "tbTableName";
            this.tbTableName.Size = new System.Drawing.Size(262, 20);
            this.tbTableName.TabIndex = 18;
            this.tbTableName.Text = "DataSource";
            this.tbTableName.Leave += new System.EventHandler(this.tbTableName_Leave);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 13);
            this.label1.TabIndex = 19;
            this.label1.Text = "Table Name";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(8, 102);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(101, 32);
            this.label3.TabIndex = 20;
            this.label3.Text = "Source Path / Connection";
            // 
            // cbHeader_Present
            // 
            this.cbHeader_Present.Location = new System.Drawing.Point(12, 184);
            this.cbHeader_Present.Name = "cbHeader_Present";
            this.cbHeader_Present.Size = new System.Drawing.Size(166, 24);
            this.cbHeader_Present.TabIndex = 21;
            this.cbHeader_Present.Text = "Treat First Row as Header";
            this.cbHeader_Present.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.cbHeader_Present.UseVisualStyleBackColor = true;
            this.cbHeader_Present.CheckedChanged += new System.EventHandler(this.cbHeader_Present_CheckedChanged);
            // 
            // cbMergeDelim
            // 
            this.cbMergeDelim.Location = new System.Drawing.Point(205, 184);
            this.cbMergeDelim.Name = "cbMergeDelim";
            this.cbMergeDelim.Size = new System.Drawing.Size(144, 24);
            this.cbMergeDelim.TabIndex = 22;
            this.cbMergeDelim.Text = "Merge Blank Delimiters";
            this.cbMergeDelim.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.cbMergeDelim.UseVisualStyleBackColor = true;
            this.cbMergeDelim.CheckedChanged += new System.EventHandler(this.cbMergeDelim_CheckedChanged);
            // 
            // frmDataSourceProp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(664, 369);
            this.Controls.Add(this.cbMergeDelim);
            this.Controls.Add(this.cbHeader_Present);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbTableName);
            this.Controls.Add(this.gpPreview);
            this.Controls.Add(this.tbSheetName);
            this.Controls.Add(this.lblSheetName);
            this.Controls.Add(this.tbDelimiter);
            this.Controls.Add(this.lblDelimiter);
            this.Controls.Add(this.tbTailSkipRows);
            this.Controls.Add(this.tbHeadSkipRows);
            this.Controls.Add(this.lblTailSkipRows);
            this.Controls.Add(this.lblHeadSkipRows);
            this.Controls.Add(this.btnBrowseSource);
            this.Controls.Add(this.tbSourcePath);
            this.Controls.Add(this.cbSourceType);
            this.Controls.Add(this.sourceType);
            this.Controls.Add(this.DialogbtGrp);
            this.Name = "frmDataSourceProp";
            this.Text = "Data Source Wizard";
            this.Load += new System.EventHandler(this.frmDataSourceProp_Load);
            this.DialogbtGrp.ResumeLayout(false);
            this.gpPreview.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgPreview)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog dlgFileSource;
        private System.Windows.Forms.GroupBox DialogbtGrp;
        private System.Windows.Forms.Button btCancel;
        private System.Windows.Forms.Button btOK;
        private System.Windows.Forms.Label sourceType;
        private System.Windows.Forms.ComboBox cbSourceType;
        private System.Windows.Forms.TextBox tbSourcePath;
        private System.Windows.Forms.Button btnBrowseSource;
        private System.Windows.Forms.Label lblHeadSkipRows;
        private System.Windows.Forms.Label lblTailSkipRows;
        private System.Windows.Forms.TextBox tbHeadSkipRows;
        private System.Windows.Forms.TextBox tbTailSkipRows;
        private System.Windows.Forms.Label lblDelimiter;
        private System.Windows.Forms.TextBox tbDelimiter;
        private System.Windows.Forms.Label lblSheetName;
        private System.Windows.Forms.TextBox tbSheetName;
        private System.Windows.Forms.GroupBox gpPreview;
        private System.Windows.Forms.DataGridView dgPreview;
        private System.Windows.Forms.TextBox tbTableName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox cbHeader_Present;
        private System.Windows.Forms.CheckBox cbMergeDelim;
    }
}
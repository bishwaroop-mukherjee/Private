﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using System.IO;
using FI_DataStage;
using System.Windows.Forms;

namespace FI_DataTranformations
{
    [XmlRoot()]
    public class TableAdded
    {
        public DataSourceClass DataSource;
        public IDType Pid;
        public IDType Cid;
        public JoinType jointype;
        public List<TableAdded> JoinedTo;
        [XmlIgnore()]
        public frmTable tabFrm;
        public TableAdded()
        {
            DataSource = null;
            Pid = Cid = null;
            tabFrm = null;
            JoinedTo = null;
            jointype = JoinType.Inner;
        }
        public void Add(frmTable refTab, frmTable frmTab, DataSourceClass dSrc, IDType pid, IDType cid, JoinType jn)
        {
            if (frmTab == null) return;
            if (frmTab.Equals(tabFrm)) return;
            if (DataSource != null)
                if (frmTab.Text == DataSource.TableName)
                    throw new Exception("The table name already exists");
            if (tabFrm == null)
            {
                tabFrm = frmTab;
                DataSource = dSrc;
                Pid = pid;
                Cid = cid;
                jointype = jn;
                JoinedTo = null;
            }
            else if (tabFrm.Equals(refTab))
            {
                if (JoinedTo == null)
                {
                    JoinedTo = new List<TableAdded>();
                    JoinedTo.Add(new TableAdded());
                    JoinedTo[JoinedTo.Count - 1].tabFrm = frmTab;
                    JoinedTo[JoinedTo.Count - 1].DataSource = dSrc;
                    JoinedTo[JoinedTo.Count - 1].Pid = pid;
                    JoinedTo[JoinedTo.Count - 1].Cid = cid;
                    JoinedTo[JoinedTo.Count - 1].jointype = jn;
                    JoinedTo[JoinedTo.Count - 1].JoinedTo = null;
                }
                else
                {
                    JoinedTo.Add(new TableAdded());
                    JoinedTo[JoinedTo.Count - 1].tabFrm = frmTab;
                    JoinedTo[JoinedTo.Count - 1].DataSource = dSrc;
                    JoinedTo[JoinedTo.Count - 1].Pid = pid;
                    JoinedTo[JoinedTo.Count - 1].Cid = cid;
                    JoinedTo[JoinedTo.Count - 1].jointype = jn;
                    JoinedTo[JoinedTo.Count - 1].JoinedTo = null;
                }
            }
            else
            {
                if (JoinedTo != null)
                    foreach (TableAdded t in JoinedTo)
                        t.Add(refTab, frmTab, dSrc, pid, cid, jn);
            }
        }

        public void PrepareJoin(DataSourceEnvelope dse)
        {
            if (DataSource != null)
            {
                dse.Add(DataSource, Pid, Cid, jointype);
                if (JoinedTo != null)
                {
                    foreach (TableAdded t in JoinedTo)
                    {
                        t.PrepareJoin(dse);
                    }
                }
            }

        }

        public void FillForm(frmTransfomationWorkspace mdiFrm, ref Panel Con, ref TreeView DataSourceTree)
        {
            if (!mdiFrm.IsMdiContainer)
            {
                throw new Exception("The form should be an MDI Container");
            }
            if (DataSource != null && tabFrm == null)
            {
                tabFrm = new frmTable();
                tabFrm.FillSchema(DataSource.getDataSchema());
                tabFrm.MdiParent = mdiFrm;
                tabFrm.Text = DataSource.TableName;
                tabFrm.MouseEnter += mdiFrm.TabOver;
                tabFrm.MouseDown += mdiFrm.TabClick;
                //tabFrm.Move += mdiFrm.TabMove;
                tabFrm.Tag = DataSource;
                Con.Controls.Add(tabFrm);
                DataSourceTree.Nodes[0].Nodes.Add(DataSource.TableName, DataSource.TableName, 1);
                tabFrm.Show();
                if (JoinedTo != null)
                {
                    foreach (TableAdded t in JoinedTo)
                    {
                        t.FillForm(mdiFrm, ref Con, ref DataSourceTree);
                    }
                }
            }

        }
    }
}

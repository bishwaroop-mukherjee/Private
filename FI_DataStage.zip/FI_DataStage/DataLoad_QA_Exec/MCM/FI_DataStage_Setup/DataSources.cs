﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FI_DataStage;

namespace FI_DataTranformations
{
    // Class for storing variables
    public class DataSources : Dictionary<string, IDataSource>
    {
        public IDataSource Add(IDataSource d)
        {
            base.Add(d.TableName, d);
            return base[d.TableName];
        }
    }
}
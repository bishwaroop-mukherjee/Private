﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FI_DataStage
{
    /// <summary>
    /// Represents class to handle exceptions
    /// </summary>
    public class DataLoaderException:DataStageException  
    {
        IDataSource dsrc;
        IDataSource DataSource
        {
            get
            {
                return dsrc;
            }
            set
            {
                dsrc = value;
            }
        }

        /// <summary>
        /// .ctor
        /// </summary>
        /// <param name="message">exception message</param>
        /// <param name="dsc">data source</param>
        public DataLoaderException(string message, IDataSource dsc):base(message)
        {
            DataSource = dsc;
        }

        /// <summary>
        /// Creates log for error condition
        /// </summary>
        /// <returns></returns>
        public override string CreateLog()
        {
            if(dsrc==null)
                return ( Message);
            else
            return (dsrc.ToString() + "\n" + Message);
        }

        /// <summary>
        /// Mails to perticular email ID
        /// </summary>
        /// <param name="a">Mail ID</param>
        /// <returns></returns>
        public override string MailToContact(string a)
        {
            return ("");
        }

        /// <summary>
        /// Converts excetions other than 
        /// </summary>
        /// <param name="ex"></param>
        /// <returns></returns>
        public static DataLoaderException ConvertExceptionToDataStageException(Exception ex)
        {
           return new DataLoaderException(ex.Message, null);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FI_DataStage
{
    public abstract class DataStageException: ApplicationException 
    {
        public DataStageException(string message) : base( message) { }
        public abstract string MailToContact(string a);
        public abstract string CreateLog();
       // public static virtual DataStageException ConvertExceptionToDataStageException(Exception ex);
        
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FI_DataStage;

namespace FI_DataStage
{
    public partial class DataSourceFactory
    {
        
        public string TableName;
        public String SourceType="XXX";
        public List<IDType> ID;
        public String SourceNameValue;
        public string SheetName;
        public int TailSkipRows;
        public int HeadSkipRows;
        public string Delim;
        public bool Header_Present;
        public bool Merge_Delim;
        public string Range;

        public DataSourceFactory (){}
        public DataSourceFactory(string tableName, String sourceType, string sourcePath, string sheetName, 
                                 string range, int tailSkipRows, int headSkipRows, string delim, 
                                 bool mergeDelim, bool headerPresent,List<IDType> IDs)
        {
            TableName = tableName;
            SourceType = sourceType;
            SourceNameValue = sourcePath;
            SheetName = sheetName;
            TailSkipRows = tailSkipRows;
            HeadSkipRows = headSkipRows;
            Merge_Delim = mergeDelim;
            Header_Present = headerPresent;
            Delim = delim;
            ID = IDs;
            Range = range;
        }

        public  DataSourceClass  GetDataSourceInstance()
        {
            DataSourceClass  d;
            if (SourceType == "TEXT")
            {
                d = new FI_DataStage.TextDataSource(SourceNameValue, Delim, Header_Present, Merge_Delim, TailSkipRows, HeadSkipRows);
            }
            else if (SourceType == "CSV")
            {
                d = new FI_DataStage.CSVDataSource(SourceNameValue,Delim, Header_Present,  TailSkipRows, HeadSkipRows);
            }
            else if (SourceType == "XML")
            {
                d = new FI_DataStage.XMLDataSource(SourceNameValue);
            }
            else if (SourceType == "ACCESS")
            {
                d = new FI_DataStage.AccessDataSource(SourceNameValue);
            }
            else if (SourceType == "XLS")
            {
                d = new FI_DataStage.ExcelDataSource(SourceNameValue, SheetName, Range);
            }
            else
            {
                throw new DataLoaderException("Source Type unidentified", null);
            }
            if (ID != null)
                d.ID = new List<IDType>(ID);
            else
                d.ID = null;

            d.TableName = TableName;

            return d;
        }
    }
}

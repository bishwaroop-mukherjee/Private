﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;
using System.Data;
using System.IO;

namespace FI_DataStage
{
    [Serializable]
    public class AccessDataSource : DataSourceClass 
    {
        // variable declarations
        string sConStr = "";
        private string sourceNameValue;
        private string srcTable;
        private string sourceType;
        private string sourceName;

        # region "Constructors"

        public AccessDataSource()
        {
            sourceNameValue = "";
        }

        public AccessDataSource(string sFilePath)
        {
            sourceNameValue = sFilePath;
        }

        #endregion

        #region IDataSource Members
        public override string TableName
        {
            get;
            set;
        }
        public override List<IDType> ID
        {
            get;
            set;
        }

        public string SourceName
        {
            get
            {
                return sourceName;
            }
            set
            {
                sourceName= value;
            }
        }

        public override string SourceNameValue
        {
            get
            {
                return sourceNameValue;
            }
            set
            {
                sourceNameValue = value;
            }
        }

        public override string SourceType
        {
            get
            {
                return sourceType;
            }
            set
            {
                sourceType = value;
            }
        }

        public override int TailSkipRows
        {
            get;
            set;
        }

        public override int HeadSkipRows
        {
            get;
            set;
        }

        public string TextSource
        {
            get;
            set;
        }

        public override string Delim
        {
            get;
            set;
        }

        public override bool Header_Present
        {
            get;
            set;
        }

        public override bool Merge_Delim
        {
            get;
            set;
        }

        public override string SheetName
        {
            get;
            set;
        }

        /// <summary>
        /// Gets data table from source
        /// </summary>
        /// <returns></returns>
        public override System.Data.DataTable getDataTable()
        {
            string sSourceTable = "GFI_industries";

            FileInfo fInf = new FileInfo(sourceNameValue);

            string sFolderName = fInf.DirectoryName;

            string sFileName = fInf.Name;

            return importAccess(sFolderName, sFileName, sSourceTable);
        }

        public override List<string> getDataSchema()
        {
            DataTable dtTab = new DataTable();

            dtTab = getDataTable();

            IEnumerable<string> ColumnNames = from DataColumn d in dtTab.Columns
                                              select d.ColumnName;


            return ColumnNames.ToList();
        }

        /// <summary>
        /// Import data from Access database to data table.
        /// </summary>
        /// <param name="sFolderName">Source folder name</param>
        /// <param name="sFileName">Source file name</param>
        /// <param name="sSourceTable">Source data table</param>
        /// <returns></returns>
        private DataTable importAccess(string sFolderName, string sFileName, string sSourceTable)
        {
            OleDbConnection oleCon;
            string sAccessConString = "";

            sAccessConString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + sFolderName + "\\" + sFileName;
                
            string sSql = "select * from "+ sSourceTable;

            try
            {
                oleCon = new OleDbConnection(sAccessConString);
                oleCon.Open();

                OleDbCommand cmd = new OleDbCommand(sSql,oleCon);
                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);

                oleCon.Close();
                oleCon.Dispose();
                da.Dispose();
                cmd.Dispose();
                return ds.Tables[0];
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion

        public override string ToString()
        {
            return ("Access File: " + sourceNameValue + " ....... Table Name:" + srcTable);
        }
    }
}

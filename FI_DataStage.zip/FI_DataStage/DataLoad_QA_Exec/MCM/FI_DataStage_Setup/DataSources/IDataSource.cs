﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Xml.Serialization;
namespace FI_DataStage
{
    public interface IDataSource
    {
        DataTable getDataTable();
        
        List<string> getDataSchema();

        string TableName
        {
            get;
            set;
        }

        String SourceType
        {
            get;
            set;
        }

        List<IDType> ID
        {
            get;
            set;
        }
        
        String SourceNameValue
        {
            get;

            set;
        }

        string SheetName
        {
            get;
            set;
        }

        int TailSkipRows
        {
            get;
            set;
        }

        int HeadSkipRows
        {
            get;
            set;
        }

        string Delim
        {
            get;
            set;
        }

        bool Header_Present
        {
            get;
            set;
        }

        bool Merge_Delim
        {
            get;
            set;
        }
    }

}

   

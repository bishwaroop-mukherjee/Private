﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;
using System.Data;
using System.IO;

namespace FI_DataStage
{
    [Serializable]
    public class ExcelDataSource:DataSourceClass 
    {
        // declarations
        public static string sConStr = "";
        private string sourceNameValue;
        private string sheetName;
        private string sourceRange;
        private string sourceType;
        private string sourceName;

        /// <summary>
        /// .ctor
        /// </summary>
        public ExcelDataSource()
        {
            sourceNameValue = "";

            sheetName = "";

            sourceRange = "";
        } 

        public ExcelDataSource(string sFilePath, string sSheetName, string range)
        {
            sourceNameValue = sFilePath;

            sheetName = sSheetName;

            sourceRange = range;
        } 

        #region IDataSource Members

        public override string TableName
        {
            get;
            set;
        }
        public override List<IDType> ID
        {
            get;
            set;
        }

        public string SourceName
        {
            get
            {
                return sourceName;
            }
            set
            {
                sourceName= value;
            }
        }

        public override string SourceNameValue
        {
            get
            {
                return sourceNameValue;
            }
            set
            {
                sourceNameValue = value;
            }
        }

        public override string SheetName
        {
            get
            {
                return sheetName;
            }
            set
            {
                sheetName = value;
            }
        }

        public override string SourceType
        {
            get
            {
                return sourceType;
            }
            set
            {
                sourceType = value;
            }
        }

        public override int TailSkipRows
        {
            get;
            set;
        }

        public override int HeadSkipRows
        {
            get;
            set;
        }

        public string TextSource
        {
            get;
            set;
        }

        public override string Delim
        {
            get;
            set;
        }

        public override bool Header_Present
        {
            get;
            set;
        }

        public override bool Merge_Delim
        {
            get;
            set;
        }

        public string SourceRange
        {
            get
            {
                return sourceRange;
            }
            set
            {
                value = sourceRange;
            }
        }

        /// <summary>
        /// Gets data table from source file
        /// </summary>
        /// <returns>Data table</returns>
        public override DataTable getDataTable()
        {
            FileInfo fInf = new FileInfo(sourceNameValue);

            string sFolderName = fInf.DirectoryName;

            string sFileName = fInf.Name;

            return importExcel(sFolderName, sFileName, sheetName);
        }

        public override List<string> getDataSchema()
        {
            DataTable dtTab = new DataTable();

            dtTab = getDataTable();

            IEnumerable<string> ColumnNames = from DataColumn d in dtTab.Columns
                                              select d.ColumnName;

            return ColumnNames.ToList();
        }

        #endregion

        /// <summary>
        /// Import Excel file into the sql server table
        /// </summary>
        /// <param name="sFolderName">Directory path containing xls file to be imported</param>
        /// <param name="sFileName">Excel file name to be imported</param>
        /// <param name="sSheetName">Sheet name to be imported</param>
        /// <param name="sTableName">Sql server table name</param>
        /// <param name="bTruncateTable">Truncate destination table before loading data? Boolean value</param>
        public DataTable importExcel(string sFolderName, string sFileName, string sSheetName)
        {
            //OleDbConnection oleCon = null;
            //string sExcelConString = "";

            //if (bColHeaders == false)
            //{
            //    sExcelConString = @"Provider=Microsoft.JET.OLEDB.4.0;Data Source=" + sFolderName + "\\" + sFileName + ";Extended Properties='Excel 8.0; HDR=NO; IMEX=1'";
            //}
            //else if (bColHeaders == true)
            //{
            //    sExcelConString = @"Provider=Microsoft.JET.OLEDB.4.0;Data Source=" + sFolderName + "\\" + sFileName + ";Extended Properties='Excel 8.0; HDR=YES; IMEX=1'";
            //}
            //string sSql = "select * from [" + sSheetName + "$]";

            try
            {
                object[,] values={};
                Microsoft.Office.Interop.Excel.ApplicationClass xlApp=new Microsoft.Office.Interop.Excel.ApplicationClass();
                Microsoft.Office.Interop.Excel.Workbook xlWb;
                Microsoft.Office.Interop.Excel.Worksheet xlWs;
                xlWb = xlApp.Workbooks.Add(sourceNameValue);
                xlWs= (Microsoft.Office.Interop.Excel.Worksheet) xlWb.Worksheets[1];

                Microsoft.Office.Interop.Excel.Range rng;
                //sourceRange = "A5:M568"; //Make SourceRange property, assign through constructor and remove this line
                rng = xlWs.get_Range(sourceRange );
                values = (object[,])rng.Cells.Value;

                DataSet ds = new DataSet();
                DataTable dt = new DataTable();

                //ds.Tables[0] = values;

                //oleCon = new OleDbConnection(sExcelConString);
                //OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + sFolderName + "\\" + sFileName + ";Extended Properties=Excel 8.0");
                //oleCon.Open();

                //string sSql = "select * from [" + sSheetName + "$]";

                //OleDbCommand cmd = new OleDbCommand(sSql, oleCon);
                //OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                //DataSet ds = new DataSet();
                //da.Fill(ds);
                //oleCon.Close();
                //oleCon.Dispose();
                //da.Dispose();
                //cmd.Dispose();

                return ds.Tables[0];
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public override string ToString()
        {
            return ("Excel File: " + sourceNameValue  + " ....... Sheet:" + sheetName + " ....... Range:" + sourceRange );
        }
    }
}

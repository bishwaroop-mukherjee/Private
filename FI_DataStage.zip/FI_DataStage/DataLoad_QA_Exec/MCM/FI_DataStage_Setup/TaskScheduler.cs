﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using FI_DataStage;
using Microsoft.ApplicationBlocks.Data;
using log4net;
using log4net.Config;
using Scheduler.EntityModel;
using Microsoft.SqlServer.Management.Smo;
using Microsoft.SqlServer.Management.Common;
namespace Scheduler
{
    public class TaskScheduler
    {
        /// <summary>
        /// Declarations
        /// </summary>
        DataTable dt;

        private Byte[] Days_of_Week = new Byte[] { 1, 2, 4, 8, 16, 32, 64 };

        #region "Public Methods"

        /// <summary>
        /// Loads data from data source into datatable
        /// </summary>
        /// <param name="ids">IDatasource instance</param>
        /// <param name="sqlConn">SqlConnection</param>
        /// <param name="tableName">Destination table name</param>
        public void loadData(IDataSource ids,SqlConnection sqlConn, string tableName,bool truncTab,ActivityLog lg,int minNumRows, float tolMinRows,string IDCol)
        {
            string Warning="" ;
            int NumRead, NumWritten;
            try
            {
                if (ids == null)
                    return;

                DataTable dtTemp;
                
                lg.SendToLog("Extraction Started",ActivityLog.LogState.Success ,ActivityLog.LogType.Extraction );

                dtTemp = ids.getDataTable();

                if (dtTemp.Rows.Count < minNumRows* ((100-tolMinRows)/100))
                       throw new DataLoaderException("Row count in file: " +dtTemp.Rows.Count+"\nwhich is less than predefined minimum number of rows: "+minNumRows,ids);

                else if((dtTemp.Rows.Count> minNumRows * ((100-tolMinRows)/100) && dtTemp.Rows.Count < minNumRows))
                {
                    Warning="\n\n  (Please check the validity of the source Data as the number of rows should be around: " + minNumRows + ")";
                }
                else
                {
                    Warning="";
                }
                NumRead = dtTemp.Rows.Count;
                //Capture number of rows extracted(read)
                lg.SendToLog("Extraction Completed", ActivityLog.LogState.Success, ActivityLog.LogType.Extraction);
                lg.SendToLog(dtTemp.Rows.Count.ToString()+  " Rows Extracted" + Warning, ActivityLog.LogState.Success, ActivityLog.LogType.Extraction);
                //Data cleansing logic 
                lg.SendToLog("Load Started",ActivityLog.LogState.Success ,ActivityLog.LogType.Load );
                NumWritten= WriteData(truncTab , sqlConn, tableName, dtTemp, lg, IDCol );
                //Capture number of rows loaded(written)

                lg.SendToStatistics(NumRead, NumWritten);
            }
            catch (DataStageException dsEx)
            {
                if (dsEx.GetType()== typeof(DataLoaderException))
                    lg.SendToLog(dsEx.CreateLog(),ActivityLog.LogState.Failure ,ActivityLog.LogType.Extraction );
                else
                    lg.SendToLog(dsEx.CreateLog(), ActivityLog.LogState.Failure, ActivityLog.LogType.Load);
                
                throw dsEx;
            }
            catch (Exception ex)
            {
                DataStageException dex = DataLoaderException.ConvertExceptionToDataStageException(ex);
                lg.SendToLog(dex.CreateLog(),ActivityLog.LogState.Failure ,ActivityLog.LogType.General );
                throw ex;
            }
        }

        /// <summary>
        /// Writes data to the destination database table
        /// </summary>
        /// <param name="bTruncateTable">Whether to truncate the database table</param>
        /// <param name="sqlCon">Sql Connection</param>
        /// <param name="tableName">Destination database table name</param>
        /// <param name="dt">DataTable</param>
        public int WriteData(bool bTruncateTable, SqlConnection sqlCon, string tableName,DataTable dt, ActivityLog lg,string IDCol)
        {
            try
            {
                DataTable dtRefData=new DataTable();
                
                int priorRowCountExisting = 0;
                int afterRowCountExisting = 0;
                int sparRowCountNew = 0;
                sqlCon.Open();
                // Truncate table
                if (bTruncateTable == true)
                {
                    string sTruncate = "truncate table " + tableName + "";
                    SqlHelper.ExecuteNonQuery(sqlCon, CommandType.Text, sTruncate);
                }
                priorRowCountExisting = (int)SqlHelper.ExecuteScalar(sqlCon, CommandType.Text, "SELECT COUNT(*) FROM " + tableName + "");

                SqlCommand sqlCom = new SqlCommand("SELECT * FROM " + tableName);
                sqlCom.Connection = sqlCon;
                dtRefData.Load(sqlCom.ExecuteReader());

                // Load data into Sql server table
                //sqlCon.Open();
                SqlBulkCopy blkcp = new SqlBulkCopy(sqlCon);

                DataCleansing dc = new DataCleansing();
                sparRowCountNew = dt.Rows.Count;
                dt = dc.cleanseData(dt,dtRefData,IDCol);
                if (bTruncateTable == false )
                {
                    string sTruncate = "truncate table " + tableName + "";
                    SqlHelper.ExecuteNonQuery(sqlCon, CommandType.Text, sTruncate);
                }
                // check if the difference between RowCountExisting and current number of rows equals dt

                blkcp.DestinationTableName = tableName;

                blkcp.WriteToServer(dt);

                afterRowCountExisting = (int)SqlHelper.ExecuteScalar(sqlCon, CommandType.Text, "SELECT COUNT(*) FROM " + tableName + "");

                if ((afterRowCountExisting - priorRowCountExisting) == sparRowCountNew)
                {
                    lg.SendToLog("Data Loaded successfully, " + sparRowCountNew + "  rows updated.", ActivityLog.LogState.Success, ActivityLog.LogType.Load);
                }
                else
                {
                    lg.SendToLog("Data Loaded successfully, " + (afterRowCountExisting - priorRowCountExisting) + "  new rows added.", ActivityLog.LogState.Success, ActivityLog.LogType.Load);
                }
                sqlCon.Close();

                return dt.Rows.Count;
            }
            catch (DataStageException dsEx)
            {
                if (dsEx.GetType() == typeof(DataLoaderException))
                    lg.SendToLog(dsEx.CreateLog(), ActivityLog.LogState.Failure, ActivityLog.LogType.Extraction);
                else
                    lg.SendToLog(dsEx.CreateLog(), ActivityLog.LogState.Failure, ActivityLog.LogType.Load);
                throw dsEx;
                
            }
            catch (Exception ex)
            {
                DataStageException dex = DataLoaderException.ConvertExceptionToDataStageException(ex);
                lg.SendToLog(dex.CreateLog(), ActivityLog.LogState.Failure, ActivityLog.LogType.General);
                throw ex;
            }
            
        }

        /// <summary>
        /// Creates Load Item depending upon data source type
        /// </summary>
        /// <param name="dlI">Data load item</param>
        public void createLoadItem(object  dlI)
        {
            IDataSource d = null;
            Data_Load_Item dI = (Data_Load_Item)dlI;
            ActivityLog log = new ActivityLog(dI);
            try
            {
                if (dI.Data_Source_Type == "TEXT")
                {
                    d = new FI_DataStage.TextDataSource(Data_Load_Item.GetFormattedString(dI.Source_Path_String_Value,dI.FlDt ), dI.Delimiter, (bool)dI.Header_Present, (bool)dI.Merge_Col,(int)dI.TailSkipRows,(int)dI.HeadSkipRows);
                }
                else if (dI.Data_Source_Type == "CSV")
                {
                    d = new FI_DataStage.CSVDataSource(Data_Load_Item.GetFormattedString(dI.Source_Path_String_Value, dI.FlDt), dI.Delimiter, (bool)dI.Header_Present, (int)dI.HeadSkipRows, (int)dI.TailSkipRows);
                }
                else if (dI.Data_Source_Type == "XML")
                {
                    d = new FI_DataStage.XMLDataSource(Data_Load_Item.GetFormattedString(dI.Source_Path_String_Value, dI.FlDt));
                }
                else if (dI.Data_Source_Type == "ACCESS")
                {
                    d = new FI_DataStage.AccessDataSource(Data_Load_Item.GetFormattedString(dI.Source_Path_String_Value, dI.FlDt));
                }
                else if (dI.Data_Source_Type == "XLS")
                {
                    d = new FI_DataStage.ExcelDataSource(Data_Load_Item.GetFormattedString(dI.Source_Path_String_Value, dI.FlDt), dI.SheetName, dI.Range);
                }
                else
                {
                    throw new DataLoaderException("Source Type unidentified", null);
                }
                SqlConnection sqlCon = new SqlConnection(dI.Destination_Con_String);
                loadData(d, sqlCon , dI.Destination_Table_Name, (bool)dI.Truncate_Before_Load, log,(int)dI.Min_Num_Rows, (float)dI.Tolerance_Min_Row_Nums,dI.IDColName );
                CallExternalScript(dI.ExternalScriptFile , sqlCon );
                RunExternalCommand(dI.ExternalCommandBatch );


                log.sendMail(dI,ActivityLog.LogState.Success  );
                
            }
            catch (DataStageException dsEx)
            {
                if (dsEx.GetType()== typeof(DataLoaderException))
                    log.SendToLog("Data Extraction Failed: " + dsEx.CreateLog(),ActivityLog.LogState.Failure ,ActivityLog.LogType.Extraction );
                else 
                    log.SendToLog("Data Load Failed: " +dsEx.CreateLog() ,ActivityLog.LogState.Failure,ActivityLog.LogType.Load );
                
                log.sendMail( dI,ActivityLog.LogState.Failure);
            }
            catch (Exception ex)
            {
                DataStageException dex = DataLoaderException.ConvertExceptionToDataStageException(ex);
                log.SendToLog("Operation failed: " + dex.CreateLog(), ActivityLog.LogState.Failure, ActivityLog.LogType.General);

                log.sendMail(dI, ActivityLog.LogState.Failure);
            }
        }

        public void CallExternalScript(string scrFileName,SqlConnection sqlCon)
        {
            if (scrFileName == null)
                return;
            if (sqlCon.State != ConnectionState.Closed)
            {
                sqlCon.Close();
            }
            try
            {
                sqlCon.Open();
                SqlCommand sqlComm = new SqlCommand();
                System.IO.FileInfo file = new System.IO.FileInfo(scrFileName);
                string script = file.OpenText().ReadToEnd();

                Server server = new Server(new ServerConnection(sqlCon));
                server.ConnectionContext.ExecuteNonQuery(script);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void RunExternalCommand(string batchFileName)
        {
            if (batchFileName == null)
                return;
            try
            {
                System.Diagnostics.Process proc = new System.Diagnostics.Process();
                string targetDir = string.Format(@"C:\");//this is where mybatch.bat lies   
                proc.StartInfo.WorkingDirectory = targetDir;
                proc.StartInfo.FileName = "batu.bat";
                proc.StartInfo.CreateNoWindow = false;
                proc.Start();
                proc.WaitForExit();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Handles schedules of dataload
        /// </summary>
        /// <param name="dateTime">Date, time of data load</param>
        public void schedule(DateTime dateTime)
        {            
            try
            {
                Byte b = Days_of_Week[(int)DateTime.Now.DayOfWeek];
                using (FI_Data_SchedulerEntities3 context = new FI_Data_SchedulerEntities3())
                {
                    List<Data_Scheduler> schItems = new List<Data_Scheduler>(
                        from LoadItem in context.Data_Scheduler
                        where (LoadItem.Day_Of_Week & b) != 0
                        select LoadItem);
                    foreach (Data_Scheduler d in schItems)
                    {
                        System.Threading.Thread th = new System.Threading.Thread(createLoadItem);
                        th.Start(d.Data_Load_Item );
                    }
                }
            }
            catch (DataStageException dsEx)
            {
                dsEx.CreateLog();
            }
            catch (Exception ex)
            {
                DataStageException dex = DataLoaderException.ConvertExceptionToDataStageException(ex);
                dex.CreateLog();
            }
        }

        /// <summary>
        /// Load DataLoad Item
        /// </summary>
        /// <param name="DataLoadName">name of dataload</param>
        public void StaticLoad(string DataLoadName)
        {
            try
            {
                Byte b = Days_of_Week[(int)DateTime.Now.DayOfWeek];
                using (FI_Data_SchedulerEntities3 context = new FI_Data_SchedulerEntities3())
                {
                    List<Data_Load_Item> schItems = new List<Data_Load_Item >(
                        from LoadItem in context.Data_Load_Item 
                        where LoadItem.Load_Item_Name  == DataLoadName 
                        select LoadItem);

                    System.Threading.Thread th = new System.Threading.Thread(createLoadItem);
                        
                    th.Start(schItems[0]);
                }
            }
            catch (DataStageException dsEx)
            {
                dsEx.CreateLog();
            }
            catch (Exception ex)
            {
                DataStageException dex = DataLoaderException.ConvertExceptionToDataStageException(ex);
                dex.CreateLog();
            }
        }

        
        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Scheduler
{
    public partial class Stat : Form
    {
        Graphics gr;
        Double YUBound , YLBound;
        Double XLBound , XUBound ;
        Double OConvYBound;
        public Stat()
        {
            InitializeComponent();
        }

        private void Stat_Load(object sender, EventArgs e)
        {
            GrphBox.VerticalScroll.Enabled = true;
            GrphBox.HorizontalScroll.Enabled = true;
            GrphBox.AutoScroll = true;
        }
        public void DrawAxis()
        {
            YUBound = 0;
            YLBound = 20;
            XLBound = 20;
            XUBound = 0;
            XUBound = Graph.Width - 20;
            YUBound = Graph.Height - YLBound;
            OConvYBound = Graph.Height;
            gr = Graphics.FromImage(Graph.Image);
            gr.Clear(Color.White );
            //Drawing Axis
            gr.DrawLine(new Pen(Brushes.Blue), new PointF((float)XLBound, (float)(OConvYBound - YLBound)), new PointF((float)XLBound, (float)(OConvYBound - YUBound)));
            gr.DrawLine(new Pen(Brushes.Blue), new PointF((float)XLBound, (float)(OConvYBound - YLBound)), new PointF((float)XUBound, (float)(OConvYBound - YLBound)));
        }
        public void Plot(IEnumerable<double> DataSeries, double YScaleFactor,double XScaleFactor,double SmoothFactor, Color clr)
        {
            List<double> DSeries = DataSeries.ToList();
            List<PointF> Points = new List<System.Drawing.PointF>();

            Double MaxData = DSeries.Max();
       
            double X,Y;
            X=0D;

            foreach (Double Data in DSeries)
            {
                Y = (OConvYBound - ((Data * YUBound / MaxData) * YScaleFactor));
                Points.Add(new System.Drawing.PointF((float)(X+XLBound ) , (float)Y));
                X += XScaleFactor;
            }
            //Drawing plot
            gr.DrawCurve(new Pen(new SolidBrush(clr)), Points.ToArray(), (float)SmoothFactor);
        }
    }
}

﻿namespace Scheduler
{
    partial class Stat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Stat));
            this.GrphBox = new System.Windows.Forms.Panel();
            this.Graph = new System.Windows.Forms.PictureBox();
            this.GrphBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Graph)).BeginInit();
            this.SuspendLayout();
            // 
            // GrphBox
            // 
            this.GrphBox.AutoScroll = true;
            this.GrphBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.GrphBox.Controls.Add(this.Graph);
            this.GrphBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.GrphBox.Location = new System.Drawing.Point(0, 0);
            this.GrphBox.Name = "GrphBox";
            this.GrphBox.Size = new System.Drawing.Size(565, 315);
            this.GrphBox.TabIndex = 0;
            // 
            // Graph
            // 
            this.Graph.Dock = System.Windows.Forms.DockStyle.Left;
            this.Graph.Image = ((System.Drawing.Image)(resources.GetObject("Graph.Image")));
            this.Graph.Location = new System.Drawing.Point(0, 0);
            this.Graph.Name = "Graph";
            this.Graph.Size = new System.Drawing.Size(10000, 295);
            this.Graph.TabIndex = 1;
            this.Graph.TabStop = false;
            // 
            // Stat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(565, 315);
            this.Controls.Add(this.GrphBox);
            this.Name = "Stat";
            this.Text = "Stat";
            this.Load += new System.EventHandler(this.Stat_Load);
            this.GrphBox.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Graph)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel GrphBox;
        private System.Windows.Forms.PictureBox Graph;

    }
}
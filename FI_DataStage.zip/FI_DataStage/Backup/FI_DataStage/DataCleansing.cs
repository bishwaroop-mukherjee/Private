﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FI_DataStage
{
    class DataCleansing
    {
        public void cleanseData(IDataSource d)
        {
            
        }
    }
}

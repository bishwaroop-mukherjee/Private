﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.IO;
using System.Data.OleDb;

namespace FI_DataStage
{
    class CSVDataSource:IDataSource
    {
        #region IDataSource Members

        public string SourceType
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }
       
        #region "Internal"

        // Global variables 
        string sourceName;
        string delim;
        bool header_present;
        System.IO.StreamReader txtRdr;
        List<List<string>> Data;
        List<string> Header;

        #endregion

        #region "Properties"

        public string SourceName
        {
            get
            {
                return sourceName;
            }
            set
            {
                sourceName = value;
            }
        }

        public string Delim
        {
            get
            {
                return delim;
            }
            set
            {
                delim = value;
            }
        }
        public bool Header_Present
        {
            get
            {
                return header_present;
            }
            set
            {
                header_present = value;
            }
        }
        #endregion

        #region "Constructors"

        public CSVDataSource()
        {
            delim = ",";
            header_present = true;
            sourceName = "";
        }

        public CSVDataSource(string sourceName)
        {
            delim = ",";
            header_present = true;
            SourceName = sourceName;
        }

        public CSVDataSource(string fileName, string separator)
        {
            sourceName = fileName;
            delim = separator;
            header_present = true;
        }

         public CSVDataSource(string fileName, string separator, bool Hdr_Present)
        {
            sourceName = fileName;
            delim = separator;
            header_present = Hdr_Present;
        }
      
        #endregion

        /// <summary>
        /// Reads data to array 
        /// </summary>
        protected void ReadtoArray()
        {
            txtRdr = System.IO.File.OpenText(sourceName);
            Data = new List<List<string>>();
            string [] adelim= new string[]{delim};
            List<string> line;
            string[] lineArr;
            string Line;

            if (header_present)
            {
                Line = txtRdr.ReadLine();
                lineArr = Line.Split(adelim, StringSplitOptions.RemoveEmptyEntries);
                Header = new List<string>();
                Header.AddRange(lineArr);
            }

            while ((Line = txtRdr.ReadLine()) != null)
            {
                lineArr = Line.Split(adelim, StringSplitOptions.RemoveEmptyEntries);
                line = new List<string>();
                line.AddRange(lineArr);
                Data.Add(line);
            }

            if (!header_present)
            {
                Header = new List<string>();
                for (int cCnt = 0; cCnt < Data[0].Count; cCnt++)
                {
                    Header.Add("Column" + cCnt.ToString());
                }
            }
        }

        /// <summary>
        /// Gets data table 
        /// </summary>
        /// <returns>data table</returns>
        public System.Data.DataTable getDataTable()
        {
            System.Data.DataTable dt= new System.Data.DataTable();
            ReadtoArray();
            foreach (string s in Header)
                dt.Columns.Add(s);
            foreach (List<string> ln in Data)
            {
                dt.Rows.Add(ln.ToArray());
            }            
            return dt;
        }

        // OleDb Approach

        //public DataSet ReadFromCsv(string filePath)
        //{
        //        string connString = string.Format("Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0};Extended Properties=Text;", System.IO.Path.GetDirectoryName(filePath));
        //        string cmdString = string.Format("SELECT * FROM {0}", System.IO.Path.GetFileName(filePath));
        //        OleDbDataAdapter dataAdapter = new OleDbDataAdapter(cmdString, connString);
        //        DataSet dataSet = new DataSet();
        //        dataAdapter.Fill(dataSet);
        //        return dataSet;     
        //}

        #endregion              
    }
}

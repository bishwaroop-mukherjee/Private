﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FI_DataStage
{
    class TextDataSource:IDataSource
    {
        #region IDataSource Members

        public string SourceName
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public string SourceType
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        #endregion

        #region "Internal"

        // Global variables
        string textsource;
        string delim;
        bool header_present;
        bool merge_delim;
        System.IO.StreamReader txtRdr;
        List<List<string>> Data;
        List<string> Header;

        #endregion

        #region "Properties"

        public string textSource
        {
            get
            {
                return textsource;
            }
            set
            {
                textsource = value;
            }
        }

        public string Delim
        {
            get
            {
                return delim;
            }
            set
            {
                delim = value;
            }
        }
        public bool Header_Present
        {
            get
            {
                return header_present;
            }
            set
            {
                header_present = value;
            }
        }
        public bool Merge_Delim
        {
            get
            {
                return merge_delim;
            }
            set
            {
                merge_delim = value;
            }
        }
        #endregion

        #region "Constructors"
        public TextDataSource()
        {
            delim = ",";
            header_present = true;
            merge_delim = false;
            textsource = "";
        }

        public TextDataSource(string TextSource)
        {
            delim = ",";
            header_present = true;
            merge_delim = false;
            textsource = TextSource;
        }
        public TextDataSource(string TxtSource, string delimiter)
        {
            delim = delimiter;
            header_present = true ;
            merge_delim = false;
            textsource = TxtSource;
        }
        public TextDataSource(string TxtSource,string delimiter, bool Hdr_Present)
        {
            delim = delimiter;
            header_present = Hdr_Present;
            merge_delim = false;
            textsource = TxtSource;
        }
        public TextDataSource(string TxtSource, string delimiter, bool Hdr_Present, bool mrg_delim)
        {
            delim = delimiter;
            header_present = Hdr_Present;
            merge_delim = mrg_delim;
            textsource = TxtSource;
        }
        #endregion

        /// <summary>
        /// Reads data to array
        /// </summary>
        protected void ReadtoArray()
        {
            txtRdr = System.IO.File.OpenText(textsource);
            Data = new List<List<string>>();
            string [] adelim= new string[]{delim};
            List<string> line;
            string[] lineArr;
            string Line;

            if (header_present)
            {
                Line = txtRdr.ReadLine();
                lineArr = Line.Split(adelim, StringSplitOptions.RemoveEmptyEntries);
                Header = new List<string>();
                Header.AddRange(lineArr);
            }

            while ((Line = txtRdr.ReadLine()) != null)
            {
                lineArr = Line.Split(adelim, (merge_delim?StringSplitOptions.RemoveEmptyEntries: StringSplitOptions.None));
                line = new List<string>();
                line.AddRange(lineArr);
                Data.Add(line);
            }

            if (!header_present)
            {
                Header = new List<string>();
                for (int cCnt = 0; cCnt < Data[0].Count; cCnt++)
                {
                    Header.Add("Column" + cCnt.ToString());
                }
            }
        }

        /// <summary>
        /// Gets data table
        /// </summary>
        /// <returns>data table</returns>
        public System.Data.DataTable getDataTable()
        {
            
            System.Data.DataTable dt= new System.Data.DataTable();
            //dt.Rows.Add(
            ReadtoArray();
            foreach (string s in Header)
                dt.Columns.Add(s);
            foreach (List<string> ln in Data)
            {
                dt.Rows.Add(ln.ToArray());
            }
            
            return dt;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FI_DataStage
{
    public class AccessDataSource : IDataSource
    {
        #region IDataSource Members

        public System.Data.DataTable getDataTable()
        {
            throw new NotImplementedException();
        }

        public string SourceName
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public string SourceType
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        #endregion
    }
}

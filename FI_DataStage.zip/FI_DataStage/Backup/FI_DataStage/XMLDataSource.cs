﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Sql;
using Microsoft.ApplicationBlocks.Data;
using System.Data.SqlClient;
using System.Xml;
namespace FI_DataStage
{
    public class XMLDataSource:IDataSource
    {
        #region IDataSource Members

        public System.Data.DataTable getDataTable()
        {
            throw new NotImplementedException();
        }

        public string SourceName
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public string SourceType
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        #endregion

        public static string sConStr = "";

        /// <summary>
        /// This function is used to load Gain Loss in DT_FWD_GainLoss table.
        /// </summary>
        /// <returns>Boolean value indicating success or failure</returns>
        public void loadGainLossFromXML()
        {
            try
            {
                // Full path of the XML file
                // string sFilePath = getFieldValue("REX_Settings", "Settings_Value", "Settings_Name = 'FWD_GL_FilePath'");
                string sFilePath = @"\\crenshaw\traders\India\AUTOMATION\PROD_DBs\FI_Exposures_C#\FWD GL Report\ReX_Forward_GL_XML.xml";
                ImportXML(sFilePath, "DT_FWD_GainLoss", true);
            }
            catch (Exception ex)
            {

            }
        }
        public void ImportGenericXML(string sFilePath)
        {
            XmlDocument xld;
            DataTable[] dtTables= new DataTable[0];
            xld = new XmlDocument();
            xld.Load(sFilePath);

            XmlNode nd;
            XmlNode final;
            nd = xld.CloneNode(true);
            GetDeepestNode(nd.ChildNodes[1], ref dtTables );
            //nd = nd;
        }

        public void GetDeepestNode(XmlNode node, ref DataTable[] tbls)
        {
            if (!node.FirstChild.FirstChild.HasChildNodes)
            {
                DataSet dt= new DataSet();
                Array.Resize<DataTable>(ref tbls, tbls.Length + 1);
                dt.Clear();
                dt.Relations.Clear();
                XmlNode nd=node.ParentNode ;
                //XmlAttribute xla = nd.Attributes[0];
                nd.Attributes.RemoveAll();
                System.IO.StringReader str = new System.IO.StringReader(nd.OuterXml);
                //XmlReader xlr = XmlReader.Create(str.
                dt.ReadXml(str);
                dt.Tables[0].TableName = nd.Name;
                tbls[tbls.Length - 1] = dt.Tables[0];
            }
            else
            {
                foreach (XmlNode nd in node.ChildNodes)
                {
                    GetDeepestNode(nd,ref tbls);
                }
                
            }
        }

        /// <summary>
        /// Imports XML file into a sql server table.
        /// </summary>
        /// <param name="sFilePath">Full path of xml file to be loaded</param>
        /// <param name="sTableName">Sql server table name</param>
        /// <param name="bTruncateTable">Boolean value indicating whether to truncate the destination table before importing data</param> 
        /// <summary>
        public void ImportXML(string sFilePath, string sTableName, Boolean bTruncateTable)
        {
            try
            {
                ImportGenericXML(sFilePath);
                // Fetch data from XML file into dataset.
                DataSet ds = new DataSet();
                ds.Clear();
                //ds.ReadXml(

                SqlConnection sqlCon = new SqlConnection(sConStr);
                sqlCon.Open();

                // Truncate table
                if (bTruncateTable == true)
                {
                    string sTruncate = "truncate table " + sTableName + "";
                    SqlHelper.ExecuteNonQuery(sConStr, CommandType.Text, sTruncate);
                }

                // Load data into Sql server table
                SqlBulkCopy blkcp = new SqlBulkCopy(sqlCon);
                blkcp.DestinationTableName = sTableName;
                blkcp.WriteToServer(ds.Tables[1]);

                blkcp.Close();
                ds.Dispose();
                blkcp = null;
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Retrieves field value 
        /// </summary>
        /// <param name="sTableName">data table name</param>
        /// <param name="sFieldName">field name in data table</param>
        /// <param name="sCondition">condition</param>
        /// <returns>string value at specified field</returns>
        public static string getFieldValue(string sTableName, string sFieldName, string sCondition)
        {
            try
            {
                string sSql, sFieldValue;

                if (sCondition == "")
                {
                    sSql = "Select [" + sFieldName + "] From [" + sTableName + "]";
                }
                else
                {
                    sSql = "Select [" + sFieldName + "] From [" + sTableName + "]  Where " + sCondition;
                }

                Object obj = SqlHelper.ExecuteScalar(sConStr, CommandType.Text, sSql);
                sFieldValue = obj.Equals(System.DBNull.Value) == false ? obj.ToString() : "";
                return (obj.ToString());
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
        }
    }
}

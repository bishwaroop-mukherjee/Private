﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Sql;

namespace FI_DataStage
{
    class DataLoad
    {
         public void Load(IDataSource d)
         {
             //DataTable dt = new DataTable();
             //dt.getDataTable();
             //dt.sqlbulkcopy
         }
         public void getDataTable()
         {
             // generic logic to get data table from source file.
         }
    }
}

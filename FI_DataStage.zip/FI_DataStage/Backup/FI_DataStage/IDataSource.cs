﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace FI_DataStage
{
    public interface IDataSource
    {
        DataTable getDataTable();
        
        String SourceName
        {
            get;
            set;
        }
        String SourceType
        {
            get;
            set;
        }
    }
}
   

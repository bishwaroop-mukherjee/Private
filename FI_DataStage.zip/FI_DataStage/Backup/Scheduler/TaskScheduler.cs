﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using FI_DataStage;
using Microsoft.ApplicationBlocks.Data;



namespace Scheduler
{
    public class TaskScheduler
    {
        DataTable dt;

        public void loadData(IDataSource ids,SqlConnection sqlConn, string tableName)
        {
            DataTable dtTemp;
            dtTemp = ids.getDataTable();
            WriteData(true,sqlConn, tableName);
        }

        public void WriteData(bool bTruncateTable, SqlConnection sqlCon, string tableName,DataTable dt)
        {

            // Truncate table
            if (bTruncateTable == true)
            {
                string sTruncate = "truncate table " + tableName + "";
                SqlHelper.ExecuteNonQuery(sqlCon , CommandType.Text, sTruncate);
            }

            // Load data into Sql server table
            SqlBulkCopy blkcp = new SqlBulkCopy(sqlCon);
            blkcp.DestinationTableName = tableName;
            blkcp.WriteToServer(dt);
        }
        public void createLoadItem(int DataLoadItemId)
        {
              IDataSource d;
         //    if (DataSource == "XML")
        //    {
        //        d = new XMLDataSource();
        //    }
            // Thread th = new Thread();
            // th.
        }
       
        public void schedule(DateTime dateTime)
        {
            // day, date, time
            // dt.LoadItems

            foreach (var row in dt.Rows)
            {
            }
        }

        /// <summary>
        /// Retrieves field value 
        /// </summary>
        /// <param name="sTableName">data table name</param>
        /// <param name="sFieldName">field name in data table</param>
        /// <param name="sCondition">condition</param>
        /// <returns>string value at specified field</returns>
        public static string getFieldValue(string sTableName, string sFieldName, string sCondition)
        {
            try
            {
                string sSql, sFieldValue;

                if (sCondition == "")
                {
                    sSql = "Select [" + sFieldName + "] From [" + sTableName + "]";
                }
                else
                {
                    sSql = "Select [" + sFieldName + "] From [" + sTableName + "]  Where " + sCondition;
                }

                Object obj = SqlHelper.ExecuteScalar(sConStr, CommandType.Text, sSql);
                sFieldValue = obj.Equals(System.DBNull.Value) == false ? obj.ToString() : "";
                return (obj.ToString());
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
        }
    }
}

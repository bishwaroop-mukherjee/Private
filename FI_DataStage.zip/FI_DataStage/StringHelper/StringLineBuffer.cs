﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace StringHelper
{
    public class StringLineBuffer
    {
        string Buffer;
        BufferedStream bs;
        Stream DataSourceStream;
        StreamReader DataReader;
        int buffersize;
        int offset;
        int LastOffset;
        public StringLineBuffer(Stream dst)
        {
            if(dst==null)
                return;
            buffersize = 1024;
            DataSourceStream= dst;
            bs = new BufferedStream(DataSourceStream,buffersize);
            
            DataReader = new StreamReader(bs);
            offset = 0;
            LastOffset = 0;
        }

        public string ReadLine()
        {
            byte[] buf= new byte[buffersize];
            byte[] retBuf = new byte[0];
            int numRead;
            
            string strRead;
            int iCnt=0;
            Stack<byte> ParseStack = new Stack<byte>();
            string charRead;
            bool EOLFound = false;
            
            while((numRead = bs.Read(buf, 0, buffersize))>0)
            {
                for (iCnt = 0; iCnt < numRead; iCnt++)
                {
                    charRead = Encoding.UTF8.GetString(buf, iCnt, 1);
                    if (ParseStack.Count == 0)
                    {
                        if (charRead == "\"")
                        {
                            ParseStack.Push(buf[iCnt]);
                        }
                        if (charRead == "\n")
                        {
                            EOLFound = true;
                            iCnt++;
                            break;
                        }
                        if (charRead != "\r")
                        {
                            Array.Resize<byte>(ref retBuf, retBuf.Length + 1);
                            retBuf[retBuf.Length - 1] = buf[iCnt];
                        }
                    }
                    else
                    {
                        if (charRead == "\"")
                        {
                            ParseStack.Pop();
                        }
                        Array.Resize<byte>(ref retBuf, retBuf.Length+1);
                        retBuf[retBuf.Length-1] = buf[iCnt];
                    }

                }
                if (EOLFound)
                {
                    bs.Seek(LastOffset + offset + iCnt, SeekOrigin.Begin);
                    LastOffset = LastOffset + offset + iCnt;
                    offset = 0;
                    break;
                }
                else
                {
                    offset += iCnt;
                }
            }
            if (retBuf.Length < 1)
            {
                return null;
            }
            string Line = Encoding.UTF8.GetString(retBuf);
            return Line;
        }
        public void Release()
        {
            bs.Close();
            DataReader.Close();
            DataSourceStream.Close();
            bs.Dispose();
            DataReader.Dispose();
            DataSourceStream.Dispose();
        }
    }
}

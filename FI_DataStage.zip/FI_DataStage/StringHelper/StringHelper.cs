﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace StringHelper
{
    public static class StringHelper
    {
        static Dictionary<string, string> fnamecoll = new Dictionary<string,string>();
        public static string[] SplitDelim(this string source, string delim, Boolean ConsiderQuotationsForString, Boolean MergeDelim)
        {
            Regex stringmatch;
            if (ConsiderQuotationsForString)
                stringmatch = new Regex("(\"[^\"]*\"" + delim + "?)|([^" + delim + "]*" + delim + ")");
            else
                stringmatch = new Regex("([^" + delim + "]*" + delim + ")");

            List<string> Line = new List<string>();
            string[] sp = stringmatch.Split(source);
            sp.Where(s => s != "").ToList().ForEach(s => Line.Add(stringmatch.Replace(s, new MatchEvaluator(m =>
            {
                string str;
                str = m.Value.Replace("\"", "");
                if (str.EndsWith(delim))
                {
                    return str.Remove(str.Length - 1).Trim();
                }
                else
                    return str.Trim();
            }))));
            try
            {

                if ((sp.Length>=2 && sp[sp.Length - 2].EndsWith(",")) && sp[sp.Length - 1] == "")
                {
                    Line.Add("");
                }
                if (MergeDelim)
                {
                    Line.RemoveAll(s => s == "");
                }
            }
            catch (Exception)
            {
                throw;
            }
            
            return Line.ToArray();
            //Line.AddRange(sp);
            //Line.ToList().ForEach(s => Console.WriteLine(s));
        }
        public static string[] SplitFixedWidth(this string source, int[] Widths)
        {
            Regex stringmatch;
            string Str;
            Str = source;
            List<string> Line = new List<string>();
            Widths.ToList().ForEach(w =>
            {
                Match m;
                if (Str.Length < w) return;
                stringmatch = new Regex(".{" + w.ToString() + "}");
                m = stringmatch.Match(Str, 0);
                Line.Add(m.Value.Trim());
                Str = Str.Substring(w, Str.Length - w); // Replace(Str, new MatchEvaluator(m1 => ""));
            });
            if (!string.IsNullOrEmpty(Str))
                Line.Add(Str.Trim());
            return Line.ToArray();
            //Line.AddRange(sp);
            //Line.ToList().ForEach(s => Console.WriteLine(s));
        }

        public static System.IO.FileStream OpenFileSafeMode(string filepath, System.IO.FileMode fmode)
        {
            System.IO.FileInfo finf = new System.IO.FileInfo(filepath);
            string filename = ".\\Temp\\" + 
                              finf.FullName.Replace("\\","_").Replace(":","_").Replace(finf.Extension,"") + 
                              "_Temp_" + 
                              DateTime.Now.ToString("yyyyMMddhhmmss") + 
                              finf.Extension;
            if (System.IO.File.Exists(filename)) System.IO.File.Delete(filename);
            System.IO.File.Copy(filepath, filename);

            System.IO.FileStream fst = new System.IO.FileStream(filename, System.IO.FileMode.Open);
            return fst;
        }
    }
}

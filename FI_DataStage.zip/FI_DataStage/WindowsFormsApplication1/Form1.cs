using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WindowsFormsApplication1.ServiceReference1;
namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ServiceReference1.DataStageETLServiceClient dsCl = new ServiceReference1.DataStageETLServiceClient();
            ServiceReference1.DataSourceProxy ds = new ServiceReference1.DataSourceProxy()
                                                    {
                                                        Delim = " ",
                                                        Header_Present = true,
                                                        SourceType = "TEXT",
                                                        SourceNameValue = @"C:\Users\bishwaroopm\Desktop\Text Files\RollClass.txt",
                                                        TableName = "RollClass",
                                                        HeadSkipRows = 0,
                                                        TailSkipRows = 0,
                                                        Merge_Delim = true,
                                                        TreatLeadingBlankAsData = false

                                                    };
            ServiceReference1.DataSourceProxy ds1 = new ServiceReference1.DataSourceProxy()
                {
                    Delim = " ",
                    Header_Present = true,
                    SourceType = "TEXT",
                    SourceNameValue = @"C:\Users\bishwaroopm\Desktop\Text Files\Students.txt",
                    TableName = "Students",
                    HeadSkipRows = 0,
                    TailSkipRows = 0,
                    Merge_Delim = true,
                    TreatLeadingBlankAsData = false

                };
            ServiceReference1.DataSourceEnvelopeProxy dsep = new ServiceReference1.DataSourceEnvelopeProxy();
            ServiceReference1.TransformationProxy trans = new ServiceReference1.TransformationProxy();
            DataTable dt;
            //dsCl.AddData(
            try
            {

                dsep = new ServiceReference1.DataSourceEnvelopeProxy() { };
                dsep.Destination = new ServiceReference1.ColumnSetProxy() { Columns = new ServiceReference1.ColumnProxy[] { new ServiceReference1.ColumnProxy() { ColumnName = "Roll", ColExpr = "RollClass_Roll_No", MapCol = "Roll_No" }, new ServiceReference1.ColumnProxy() { ColumnName = "Name", ColExpr = "Students_Name", MapCol = "SName" } } };
                dsep.ColumnTypes = new ServiceReference1.ColTypeProxy[] { new ServiceReference1.ColTypeProxy() { ColName = "RollClass_Roll_No", ColumnType = typeof(string).FullName }, new ServiceReference1.ColTypeProxy() { ColName = "Students_Name", ColumnType = typeof(string).FullName } };
                dsCl.AddData(dsep, "DSE1");
                //dynamic ret = dsCl.GetData();

                dsCl.AddFirstDataSourcetoEnvelope(ds, "DSE1");
                dsCl.AddDataSourcetoEnvelope(ds1, "DSE1", "RollClass", new ServiceReference1.IDTypeProxy() { ID = "RollClass_Roll_No" }, new ServiceReference1.IDTypeProxy() { ID = "Students_Roll_No" }, ServiceReference1.JoinType.Inner);
                //dsCl.AddTransformation(new ServiceReference1.TransformationContainerProxy(){TransActor}
                dt = dsCl.GetTransformationData();
                dgv.DataSource = dt;
            }
            catch (Exception ex)
            {
                ex = ex;
            }

        }
    }
}

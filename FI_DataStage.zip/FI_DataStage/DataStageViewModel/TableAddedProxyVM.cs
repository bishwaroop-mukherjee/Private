﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FI_DataTranformations.UI;
using FI_DataTranformations;
using FI_DataStage;
using System.ComponentModel;
using System.Collections.ObjectModel;


namespace DataStageViewModel
{
    public class TableAddedProxyVM //:INotifyPropertyChanged
    {
        TableAdded tableTree;
        public DataSourceClass DataSource
        {
            get { return tableTree.DataSource; }
            set { tableTree.DataSource = value; }
        }
        public IDType Pid
        {
            get { return tableTree.Pid; }
            set { tableTree.Pid = value; }
        }
        public IDType Cid
        {
            get { return tableTree.Cid; }
            set { tableTree.Cid = value; }
        }
        public JoinType jointype
        {
            get { return tableTree.jointype; }
            set { tableTree.jointype = value; }
        }
        public ObservableCollection<TableAddedProxyVM> JoinedTo;
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FI_DataTranformations;
using FI_DataTranformations.UI;
using System.Windows.Controls;
using System.ComponentModel;
namespace DataStageViewModel
{
    public class JoinPanelViewModel //:INotifyPropertyChanged
    {
        JoinPanel jPanel;
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace ExpressionBuilder.Expressions
{
    public partial class LeftValueExpression : ValueExpression
    {
        #region .ctors

        public LeftValueExpression(Expression parent)
            : base(parent)
        {
        }

        #endregion .ctors
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;

namespace ExpressionBuilder.Expressions
{
    public partial class LogicalExpression : Expression
    {
        #region .ctors

        public LogicalExpression(Expression parent)
            : this(parent, null)
        {
        }

        public LogicalExpression(Expression parent, params Expression[] operands)
            : base(parent)
        {
            if (operands != null)
            {
                Operands = new ObservableCollection<Expression>(operands.Where(t => t != null));
            }
            else
            {
                Operands = new ObservableCollection<Expression>();
            }
        }

        #endregion .ctors

        #region Properties

        /// <summary>
        /// Gets/sets Type.
        /// </summary>
        public LogicalOperatorType Type
        {
            [System.Diagnostics.DebuggerStepThrough]
            get { return p_Type; }
            [System.Diagnostics.DebuggerStepThrough]
            set
            {
                if (p_Type != value)
                {
                    p_Type = value;
                    OnPropertyChanged("Type");
                    OnTypeChanged();
                }
            }
        }
        private LogicalOperatorType p_Type;
        partial void OnTypeChanged();

        /// <summary>
        /// Gets/sets Operands.
        /// </summary>
        public ObservableCollection<Expression> Operands
        {
            [System.Diagnostics.DebuggerStepThrough]
            get { return p_Operands; }
            [System.Diagnostics.DebuggerStepThrough]
            private set
            {
                if (p_Operands != value)
                {
                    p_Operands = value;
                    OnPropertyChanged("Operands");
                    OnOperandsChanged();
                }
            }
        }
        private ObservableCollection<Expression> p_Operands;
        partial void OnOperandsChanged();

        #endregion Properties

        #region Methods

        public override void Foreach(Action<string, Expression> action, string name)
        {
            ObservableCollection<Expressions.Expression> TEMP = new ObservableCollection<Expression>(Operands.Reverse());
            foreach (var item in TEMP)
            {
                item.Foreach(action, string.Format("Operand {0}", Operands.IndexOf(item) + 1));
            }
            base.Foreach(action, name);
        }

        public static LogicalExpression And(Expression operand)
        {
            var lExp = new LogicalExpression(null) { Type = LogicalOperatorType.And, Operands = new ObservableCollection<Expression>() { operand } };
            operand.Parent = lExp;
            return lExp;
        }

        public static LogicalExpression Or(Expression operand)
        {
            var lExp = new LogicalExpression(null) { Type = LogicalOperatorType.Or, Operands = new ObservableCollection<Expression>() { operand } };
            operand.Parent = lExp;
            return lExp;
        }

        #endregion Methods
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExpressionBuilder.Expressions
{
    public partial class ComparisionExpression : Expression
    {
        #region .ctors

        public ComparisionExpression(Expression parent)
            : this(null, null, null)
        {
        }

        public ComparisionExpression(Expression parent, object left, object right)
            : base(parent)
        {
            Left = new LeftValueExpression(this) { Value = left };
            Right = new RightValueExpression(this) { Value = right };
        }

        #endregion .ctors

        #region Properties

        /// <summary>
        /// Gets/sets Type.
        /// </summary>
        public ComparisionType Type
        {
            [System.Diagnostics.DebuggerStepThrough]
            get { return p_Type; }
            [System.Diagnostics.DebuggerStepThrough]
            set
            {
                if (p_Type != value)
                {
                    p_Type = value;
                    OnPropertyChanged("Type");
                    OnTypeChanged();
                }
            }
        }
        private ComparisionType p_Type;
        partial void OnTypeChanged();

        /// <summary>
        /// Gets/sets Left.
        /// </summary>
        public LeftValueExpression Left
        {
            [System.Diagnostics.DebuggerStepThrough]
            get { return p_Left; }
            [System.Diagnostics.DebuggerStepThrough]
            private set
            {
                if (p_Left != value)
                {
                    p_Left = value;
                    OnPropertyChanged("Left");
                    OnLeftChanged();
                }
            }
        }
        private LeftValueExpression p_Left;
        partial void OnLeftChanged();

        /// <summary>
        /// Gets/sets Right.
        /// </summary>
        public RightValueExpression Right
        {
            [System.Diagnostics.DebuggerStepThrough]
            get { return p_Right; }
            [System.Diagnostics.DebuggerStepThrough]
            private set
            {
                if (p_Right != value)
                {
                    p_Right = value;
                    OnPropertyChanged("Right");
                    OnRightChanged();
                }
            }
        }
        private RightValueExpression p_Right;
        partial void OnRightChanged();

        #endregion Properties

        #region Methods

        public override void Foreach(Action<string, Expression> action, string name)
        {
            Right.Foreach(action, "Right");
            Left.Foreach(action, "Left");
            base.Foreach(action, name);
        }

        //public override void ValidateCore()
        //{
        //    Left.ValidateCore();
        //    Check("Left", () => Left.Error == null, string.Format("Left: {0}", Left.Error));

        //    Right.ValidateCore();
        //    Check("Right", () => Right.Error == null, string.Format("Right: {0}", Right.Error));
        //}

        #endregion Methods
    }
}

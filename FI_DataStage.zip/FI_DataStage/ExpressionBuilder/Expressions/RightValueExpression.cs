﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace ExpressionBuilder.Expressions
{
    public partial class RightValueExpression : ValueExpression
    {
        #region .ctors

        public RightValueExpression(Expression parent)
            : base(parent)
        {
        }

        #endregion .ctors
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Media;
using ExpressionBuilder.Expressions;

namespace ExpressionBuilder.BaseTypes
{
    public static class Extensions
    {
        #region Methods

        public static ObservableCollection<T> ToObservable<T>(this IEnumerable<T> list)
        {
            return new ObservableCollection<T>(list);
        }

        public static T GetParent<T>(this DependencyObject obj)
            where T : class
        {
            return LookUp(obj, d => d is T) as T;
        }

        public static DependencyObject LookUp(this DependencyObject obj, Predicate<DependencyObject> check)
        {
            var t = obj;
            while (t != null && !check(t = VisualTreeHelper.GetParent(t))) ;
            return t;
        }
        public static string GetComparisionOperatorString(this Expressions.ComparisionExpression ce)
        {
            string Op = "";
            switch (ce.Type)
            {
                case ComparisionType.Equal:
                    Op = "=";
                    break;
                case ComparisionType.GreaterOrEqual:
                    Op = ">=";
                    break;
                case ComparisionType.Less:
                    Op = "<";
                    break;
                case ComparisionType.LessOrEqual:
                    Op = "<=";
                    break;
                case ComparisionType.Like:
                    Op = "LIKE";
                    break;
                case ComparisionType.NotEqual:
                    Op = "<>";
                    break;
                case ComparisionType.NotLike:
                    Op = "NOT_LIKE";
                    break;
            }
            return Op;
        }

        public static string GetLogicalOperatorString(this Expressions.LogicalExpression ce)
        {
            string Op = "";
            switch (ce.Type)
            {
                case LogicalOperatorType.And:
                    Op = "AND";
                    break;
                case LogicalOperatorType.Or:
                    Op = "OR";
                    break;
            }
            return Op;
        }
        static string Lft = "", Rgt = "", Op = "", cmdStr = "";
        static Stack<ExpressionBuilder.Expressions.Expression> ExpressionStack;
        public static string ConverttoInfixString<TINP>(this ExpressionBuilder.Expressions.Expression exp, string name, Func<TINP, string> f)
        {
            string ResultString = string.Empty;
            string intermediateString = String.Empty;
            if (ExpressionStack == null)
                ExpressionStack = new Stack<Expressions.Expression>();
            else
                ExpressionStack.Clear();
            exp.Foreach((s, ex) =>
            {
                if (ex.GetType() == typeof(ComparisionExpression))
                {

                    ComparisionExpression ce = (ComparisionExpression)ex;
                    LeftValueExpression leInt = new LeftValueExpression(ce);
                    leInt.Value = ExpressionStack.GetStringFromExpStack<TINP>(ce.GetComparisionOperatorString(), f);
                    ExpressionStack.Push(leInt);
                }
                else if (ex.GetType() == typeof(LogicalExpression))
                {
                    LogicalExpression ce = (LogicalExpression)ex;
                    LeftValueExpression leInt = new LeftValueExpression(ce);
                    leInt.Value = ExpressionStack.GetStringFromExpStack<TINP>(ce.GetLogicalOperatorString(), f);
                    ExpressionStack.Push(leInt);
                }
                else if (ex.GetType() == typeof(LeftValueExpression) && s == "Left")
                {
                    LeftValueExpression le = (LeftValueExpression)ex;

                    if (le != null && le.Value != null)
                        ExpressionStack.Push(le);
                }
                else if (ex.GetType() == typeof(RightValueExpression) && s == "Right")
                {
                    RightValueExpression re = (RightValueExpression)ex;
                    if (re != null && re.Value != null)
                        ExpressionStack.Push(re);
                }
            }, name);
            ResultString = ExpressionStack.GetStringFromExpStack<TINP>("", f);
            return ResultString;
        }
        private static string GetStringFromExpStack<TINP>(this Stack<Expressions.Expression> exst, string Op, Func<TINP, string> f)
        {
            string result = string.Empty;
            string op;
            Expressions.Expression ex;
            while (exst.Count > 0)
            {
                ex = exst.Pop();
                if (ex.GetType() == typeof(LeftValueExpression))
                {
                    if (((LeftValueExpression)ex).Value.GetType() == typeof(TINP))
                        result += f((TINP)((LeftValueExpression)ex).Value);
                    else if (((LeftValueExpression)ex).Value.GetType() == typeof(string))
                        result += ((LeftValueExpression)ex).Value;

                    if ((!string.IsNullOrEmpty(Op)) && exst.Count > 0)
                        result += " " + Op + " ";
                }

                if (ex.GetType() == typeof(RightValueExpression))
                {
                    if (((RightValueExpression)ex).Value.GetType() == typeof(TINP))
                        result += f((TINP)((RightValueExpression)ex).Value);
                    else if (((RightValueExpression)ex).Value.GetType() == typeof(string))
                        result += ((RightValueExpression)ex).Value;
                    if (exst.Count > 0)
                    {
                        Expressions.Expression eTemp = exst.Peek();
                        if (eTemp.GetType() == typeof(LeftValueExpression))
                        {
                            return "(" + result + ")";
                        }
                    }
                }

            }

            return "(" + result + ")";
        }
        #endregion Methods
    }
}
